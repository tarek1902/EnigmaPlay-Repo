# -*- coding: utf-8 -*-
"""
Messages from the store (sent from the admin console) shown on the TV.

The box asks GET /v1/announcements a little after boot, then every few hours, and also when the
store opens or a wake-up arrives from the phone channel. Each message is shown once per box:
the server remembers it after POST /v1/announcements/<id>/seen and we also keep the ids locally.
"""
from __future__ import print_function, unicode_literals, absolute_import, division
import io
import json
import threading
import time

from . import account
try:
    from .i18n import _
except Exception:
    _ = lambda t: t

SEEN_FILE = "/etc/enigma2/enigmaplay/seen_announcements.json"
FIRST_CHECK_MS = 120 * 1000
CHECK_EVERY_MS = 3 * 3600 * 1000
MIN_GAP = 60                          # seconds between two checks
AGENT = None

try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote


def _log(msg):
    try:
        with io.open("/tmp/enigmaplay_announce.log", "a", encoding="utf-8") as f:
            f.write("%s %s\n" % (time.strftime("%H:%M:%S"), msg))
    except Exception:
        pass


def enabled():
    try:
        from . import settings
        return bool(settings.get("show_announcements"))
    except Exception:
        return True


def _load_seen():
    try:
        with io.open(SEEN_FILE, "r", encoding="utf-8") as f:
            return [int(x) for x in json.load(f)]
    except Exception:
        return []


def _save_seen(ids):
    try:
        with io.open(SEEN_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(sorted(set(ids))[-300:]))
    except Exception:
        pass


def fetch():
    """List of new messages for this box (runs in a worker thread)."""
    info = account.device_info()
    path = "/v1/announcements?device=%s&image=%s&model=%s&v=%s" % (
        quote(account.device_id()), quote(info.get("image", "") or ""), quote(info.get("model", "") or ""),
        quote(info.get("plugin_version", "") or ""))
    s = account.load_session()
    try:
        d = account.request("GET", path, token=s["token"] if s else None)
    except account.ApiError as e:
        if e.status != 401 or not s:
            raise
        d = account.request("GET", path)             # expired login: still get the public ones
    seen = set(_load_seen())
    return [a for a in d.get("announcements", []) if int(a.get("id", 0)) not in seen]


HISTORY_FILE = "/etc/enigma2/enigmaplay/messages.json"
HISTORY_MAX = 15


def history():
    """Store messages received on this box, newest first: [{id, title, body, level, ts, read}]."""
    try:
        with io.open(HISTORY_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
        return [m for m in d if isinstance(m, dict) and "id" in m]
    except Exception:
        return []


def _save_history(items):
    try:
        with io.open(HISTORY_FILE, "w", encoding="utf-8") as f:
            f.write(json.dumps(items[:HISTORY_MAX], ensure_ascii=False))
    except Exception:
        pass


def remember(msgs):
    items = history()
    known = set(int(m["id"]) for m in items)
    new = []
    for a in msgs:
        try:
            if int(a.get("id", 0)) in known:
                continue
            new.append({"id": int(a["id"]), "title": a.get("title", ""), "body": a.get("body", ""),
                        "level": a.get("level", "info"), "ts": int(time.time()), "read": False})
        except Exception:
            continue
    if new:
        _save_history(new + items)


def mark_read(ann_id):
    items = history()
    for m in items:
        if int(m["id"]) == int(ann_id):
            m["read"] = True
    _save_history(items)


def unread_count():
    return sum(1 for m in history() if not m.get("read"))


def mark_seen(ann_id):
    mark_read(ann_id)
    _save_seen(_load_seen() + [int(ann_id)])

    def run():
        try:
            account.request("POST", "/v1/announcements/%d/seen" % int(ann_id), {"device": account.device_id()})
        except Exception as e:
            _log("seen failed: %r" % e)
    t = threading.Thread(target=run)
    t.daemon = True
    t.start()


def poke():
    if AGENT is not None:
        AGENT.request_check()


class Announcer(object):
    def __init__(self, session, open_store=None):
        from enigma import eTimer
        self.session = session
        self.open_store = open_store
        self.lock = threading.Lock()
        self.result = None
        self.busy = False
        self.showing = False
        self.queue = []
        self.last_check = 0
        self.want = False
        self.timer = eTimer()
        self.timer.callback.append(self.start_check)
        self.timer.start(FIRST_CHECK_MS, True)
        self.poll_timer = eTimer()
        self.poll_timer.callback.append(self.poll)
        self.poll_timer.start(3000, False)

    def request_check(self):
        with self.lock:
            self.want = True

    def start_check(self):
        self.timer.start(CHECK_EVERY_MS, True)
        self.request_check()

    def worker(self):
        try:
            res = fetch()
        except Exception as e:
            _log("fetch failed: %r" % e)
            res = []
        with self.lock:
            self.result = res

    def poll(self):
        with self.lock:
            res, self.result = self.result, None
            want = self.want
        if res is not None:
            self.busy = False
            known = set(int(a["id"]) for a in self.queue)
            self.queue += [a for a in res if int(a["id"]) not in known]
            remember(res)
            if res:
                _log("received %d message(s)" % len(res))
        if want and not self.busy and enabled() and time.time() - self.last_check >= MIN_GAP:
            with self.lock:
                self.want = False
            self.busy = True
            self.last_check = time.time()
            t = threading.Thread(target=self.worker)
            t.daemon = True
            t.start()
        elif want and not enabled():
            with self.lock:
                self.want = False
        if self.queue and not self.showing:
            self.show(self.queue.pop(0))

    def show(self, a):
        try:
            from Tools import Notifications
        except Exception as e:
            _log("no notifications: %r" % e)
            return
        level = a.get("level", "info")
        self.showing = True
        ann_id = a.get("id")

        def done(answer=None):
            self.showing = False
            mark_seen(ann_id)
            if level == "update" and answer and self.open_store:
                try:
                    self.open_store()
                except Exception as e:
                    _log("open store failed: %r" % e)
        try:
            Notifications.AddNotificationWithCallback(done, AnnouncementBox, a.get("title", ""), a.get("body", ""), level)
        except Exception as e:
            _log("custom box failed (%r), using MessageBox" % e)
            try:
                from Screens.MessageBox import MessageBox
                text = rtl_text(a.get("title", "")) + "\n\n" + rtl_text(a.get("body", ""))
                if level == "update":
                    text += "\n\n" + rtl_text(_("فتح المتجر الآن؟"))
                    Notifications.AddNotificationWithCallback(done, MessageBox, text, MessageBox.TYPE_YESNO)
                else:
                    Notifications.AddNotificationWithCallback(done, MessageBox, text, MessageBox.TYPE_INFO)
            except Exception as e2:
                self.showing = False
                _log("show failed: %r" % e2)


# ---------------------------------------------------------------- the message window
RLM = ""      # direction marks are drawn as boxes (and reorder lines) on some images
LRM = ""


def _is_rtl(s):
    for ch in s:
        o = ord(ch)
        if 0x0590 <= o <= 0x08FF or 0xFB1D <= o <= 0xFEFC:
            return True
        if ch.isalpha():
            return False
    return False


def wrap_lines(text, width):
    """Break every paragraph ourselves at word boundaries: the image's own wrapping
    reorders mixed Arabic / Latin text (EnigmaPlay inside an Arabic sentence)."""
    out = []
    for para in (text or "").replace("\r", "").split("\n"):
        para = para.strip()
        if not para:
            out.append("")
            continue
        line = ""
        for w in para.split(" "):
            if not w:
                continue
            if line and len(line) + 1 + len(w) > width:
                out.append(line)
                line = w
            else:
                line = (line + " " + w) if line else w
        if line:
            out.append(line)
    return out


def rtl_text(text, width=58):
    """Each line gets its own direction mark, so a line that starts with a Latin word or a
    bullet is still laid out right-to-left."""
    lines = wrap_lines(text, width)
    rtl = _is_rtl(text or "")
    return "\n".join(lines)


try:
    from Screens.Screen import Screen as _E2Screen
    from Components.Label import Label as _E2Label
    from Components.ActionMap import ActionMap as _E2ActionMap
except Exception:            # outside Enigma2 (tests)
    _E2Screen = object
    _E2Label = None
    _E2ActionMap = None
try:
    from Components.Pixmap import Pixmap as _E2Pixmap
except Exception:
    _E2Pixmap = None

import re as _re
_URL_RE = _re.compile(r"https?://[^\s]+")


def qr_file(link):
    """PNG with a QR code of link (public QR service, cached in /tmp); None when offline."""
    import hashlib
    import os
    target = "/tmp/enigmaplay/qr_ann_%s.png" % hashlib.md5(link.encode("utf-8")).hexdigest()[:12]
    if os.path.isfile(target):
        return target
    try:
        if not os.path.isdir("/tmp/enigmaplay"):
            os.makedirs("/tmp/enigmaplay")
        url = "https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=10&data=" + quote(link, safe="")
        try:
            try:
                from urllib.request import urlopen
            except ImportError:
                from urllib2 import urlopen
            data = urlopen(url, timeout=10).read()
        except Exception:
            import subprocess
            data = subprocess.Popen(["curl", "-s", "-k", "-m", "10", url], stdout=subprocess.PIPE).communicate()[0]
        if not data or not data.startswith(b"\x89PNG"):
            return None
        with open(target, "wb") as f:
            f.write(data)
        return target
    except Exception as e:
        _log("qr failed: %r" % e)
        return None


LEVEL_COLORS = {"update": "#1a73e8", "warning": "#e37400", "info": "#188038"}


_FONTS_DONE = []


def _register_fonts():
    """The message can pop up before the store was ever opened: register our fonts here too."""
    if _FONTS_DONE:
        return
    _FONTS_DONE.append(1)
    try:
        from enigma import addFont
        from . import i18n
        reg, med, bld = i18n.font_files()
        addFont(reg, "TajawalRegular", 100, 0)
        addFont(med, "TajawalMedium", 100, 0)
        addFont(bld, "TajawalBold", 100, 0)
    except Exception as e:
        _log("fonts: %r" % e)


class AnnouncementBox(_E2Screen):
    """Store message on top of whatever is on screen: card with a coloured header, Arabic text laid
    out right-to-left, OK / EXIT buttons in Arabic."""

    def __init__(self, session, title, body, level="info", ok_text=None):
        try:
            from enigma import getDesktop
            f = getDesktop(0).size().width() / 1920.0
        except Exception:
            f = 1.0

        def p(v):
            return int(round(v * f))

        try:
            from .i18n import plain
            title, body = plain(title or ""), plain(body or "")
        except Exception:
            pass
        is_update = level == "update"
        rtl = _is_rtl((title or "") + (body or ""))
        halign = "right" if rtl else "left"
        # a link in the message gets a QR code next to the text (scan it with the phone camera)
        m = _URL_RE.search(body or "") if _E2Pixmap else None
        self.qr_link = m.group(0).rstrip(".,،)") if m else None
        QR = 250 if self.qr_link else 0
        lines = wrap_lines(body, 64 if not QR else 52)
        line_h = 44
        body_h = max(QR + 10, max(1, len(lines)) * line_h + 10)
        W = 1100 + (QR + 30 if QR else 0)
        H = 96 + 24 + body_h + 30 + 70 + 30
        X = (1920 - W) // 2
        Y = max(40, (1080 - H) // 2)
        color = LEVEL_COLORS.get(level, LEVEL_COLORS["info"])
        bx = 40
        bw = 300 if is_update else 0
        ok_x = (W - bx - 300) if rtl else bx
        later_x = (ok_x - 320) if rtl else (bx + 320)
        if not is_update:
            ok_x = (W - 300) // 2
        self.skin = (
            '<screen name="EnigmaPlayAnnouncement" position="%d,%d" size="%d,%d" flags="wfNoBorder" backgroundColor="#ffffff">'
            '<eLabel position="0,0" size="%d,%d" backgroundColor="%s" zPosition="1" />'
            '<widget name="title" position="%d,%d" size="%d,%d" font="TajawalBold;%d" halign="%s" valign="center" foregroundColor="#ffffff" backgroundColor="%s" transparent="1" zPosition="2" />'
            '<widget name="body" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" valign="top" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" zPosition="2" />'
            '%s'
            '<eLabel position="%d,%d" size="%d,%d" backgroundColor="#dadce0" zPosition="1" />'
            '<widget name="ok" position="%d,%d" size="%d,%d" font="TajawalBold;%d" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="%s" zPosition="2" />'
            '%s'
            '</screen>'
        ) % (
            p(X), p(Y), p(W), p(H),
            p(W), p(96), color,
            p(36), p(8), p(W - 72), p(80), p(34), halign, color,
            p(44 + (QR + 30 if (QR and rtl) else 0)), p(96 + 24), p(W - 88 - (QR + 30 if QR else 0)), p(body_h), p(28), halign,
            ('<widget name="qr" position="%d,%d" size="%d,%d" alphatest="off" zPosition="3" />'
             % (p(44 if rtl else W - 44 - QR), p(96 + 24), p(QR), p(QR))) if QR else "",
            p(0), p(96 + 24 + body_h + 20), p(W), p(2),
            p(ok_x), p(H - 30 - 70), p(300), p(70), p(28), color,
            ('<widget name="later" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="center" valign="center" foregroundColor="#3c4043" backgroundColor="#f1f3f4" zPosition="2" />'
             % (p(later_x), p(H - 30 - 70), p(300), p(70), p(28))) if is_update else "",
        )
        _register_fonts()
        _E2Screen.__init__(self, session)
        mark = RLM if rtl else LRM
        self["title"] = _E2Label(mark + (title or "EnigmaPlay"))
        self["body"] = _E2Label("\n".join((mark + l) if l else l for l in lines))
        self["ok"] = _E2Label(ok_text or (_("فتح المتجر") if is_update else _("موافق")))
        if is_update:
            self["later"] = _E2Label(_("لاحقاً"))
        self.is_update = is_update
        if self.qr_link:
            self["qr"] = _E2Pixmap()
            self._qr_path = None
            self.onLayoutFinish.append(self._start_qr)
        self["actions"] = _E2ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.accept,
            "green": self.accept,
            "cancel": self.reject,
            "red": self.reject,
        }, -1)

    def _start_qr(self):
        try:
            from enigma import eTimer
            self._qr_timer = eTimer()
            try:
                self._qr_timer.callback.append(self._show_qr)
            except AttributeError:
                self._qr_conn = self._qr_timer.timeout.connect(self._show_qr)
            def work():
                self._qr_path = qr_file(self.qr_link) or ""
            threading.Thread(target=work).start()
            self._qr_timer.start(300, False)
        except Exception as e:
            _log("qr start failed: %r" % e)

    def _show_qr(self):
        if self._qr_path is None:
            return                                   # still downloading
        try:
            self._qr_timer.stop()
            if self._qr_path:
                from enigma import loadPNG
                pix = loadPNG(self._qr_path)
                if pix and self["qr"].instance:
                    self["qr"].instance.setPixmap(pix)
        except Exception as e:
            _log("qr show failed: %r" % e)

    def _stop_qr(self):
        try:
            self._qr_timer.stop()
        except Exception:
            pass

    def accept(self):
        self._stop_qr()
        self.close(True)

    def reject(self):
        self._stop_qr()
        self.close(False)


def start(session, open_store=None):
    global AGENT
    if AGENT is None:
        AGENT = Announcer(session, open_store)
    return AGENT


# ---------------------------------------------------------------- privacy policy / terms on the TV
def fetch_legal(kind):
    """-> (title, text) from the server (/privacy or /terms as JSON) in the box language."""
    lang = "ar"
    try:
        from .i18n import LANG
        lang = "ar" if LANG == "ar" else "en"
    except Exception:
        pass
    d = account.request("GET", "/%s?format=json&lang=%s" % ("terms" if kind == "terms" else "privacy", lang))
    return d.get("title", ""), d.get("text", ""), d.get("updated", "")


try:
    from Components.ScrollLabel import ScrollLabel as _E2ScrollLabel
except Exception:
    _E2ScrollLabel = None


class LegalBox(_E2Screen):
    """Long text (privacy policy / terms) in a scrollable card; UP/DOWN/CH+/CH- scroll, OK/EXIT close."""

    WRAP = 92

    def __init__(self, session, kind="privacy"):
        try:
            from enigma import getDesktop, eTimer
            f = getDesktop(0).size().width() / 1920.0
        except Exception:
            f = 1.0
            eTimer = None

        def p(v):
            return int(round(v * f))
        W, H = 1500, 900
        X, Y = (1920 - W) // 2, (1080 - H) // 2
        halign = "right" if _is_rtl(_("سياسة الخصوصية")) else "left"
        self.skin = (
            '<screen name="EnigmaPlayLegal" position="%d,%d" size="%d,%d" flags="wfNoBorder" backgroundColor="#ffffff">'
            '<eLabel position="0,0" size="%d,%d" backgroundColor="#01875f" zPosition="1" />'
            '<widget name="title" position="%d,%d" size="%d,%d" font="TajawalBold;%d" halign="%s" valign="center" foregroundColor="#ffffff" backgroundColor="#01875f" transparent="1" zPosition="2" />'
            '<widget name="text" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="%s" foregroundColor="#202124" backgroundColor="#ffffff" zPosition="2" />'
            '<eLabel position="0,%d" size="%d,%d" backgroundColor="#dadce0" zPosition="1" />'
            '<widget name="hint" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" halign="center" valign="center" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" zPosition="2" />'
            '</screen>'
        ) % (p(X), p(Y), p(W), p(H),
             p(W), p(90),
             p(36), p(5), p(W - 72), p(80), p(34), halign,
             p(40), p(110), p(W - 80), p(H - 110 - 80), p(27), halign,
             p(H - 72), p(W), p(2),
             p(20), p(H - 68), p(W - 40), p(60), p(24))
        _register_fonts()
        _E2Screen.__init__(self, session)
        self.kind = kind
        self["title"] = _E2Label(RLM + (_("شروط الاستخدام") if kind == "terms" else _("سياسة الخصوصية")))
        self["text"] = _E2ScrollLabel(_("جاري التحميل…"))
        self["hint"] = _E2Label(_("▲▼ للتمرير  ·  OK أو EXIT للإغلاق"))
        self["actions"] = _E2ActionMap(["OkCancelActions", "DirectionActions", "ChannelSelectBaseActions"], {
            "ok": self.close, "cancel": self.close,
            "up": self["text"].pageUp, "down": self["text"].pageDown,
            "left": self["text"].pageUp, "right": self["text"].pageDown,
            "nextBouquet": self["text"].pageUp, "prevBouquet": self["text"].pageDown,
        }, -1)
        self._result = None
        self._lock = threading.Lock()
        t = threading.Thread(target=self._load)
        t.daemon = True
        t.start()
        self._timer = eTimer() if eTimer else None
        if self._timer:
            self._timer.callback.append(self._poll)
            self._timer.start(250, False)

    def _load(self):
        try:
            res = fetch_legal(self.kind)
        except Exception as e:
            _log("legal fetch failed: %r" % e)
            res = None
        with self._lock:
            self._result = res if res else ("", "", "")

    def _poll(self):
        with self._lock:
            res = self._result
        if res is None:
            return
        self._timer.stop()
        title, text, updated = res
        try:
            from .i18n import plain
            title, text = plain(title), plain(text)
        except Exception:
            pass
        if not text:
            text = _("تعذر التحميل. يمكنك قراءتها على: %s") % (account.API_BASE.replace("https://", "") + "/" + self.kind)
        if title:
            self["title"].setText(RLM + title)
        rtl = _is_rtl(text)
        mark = RLM if rtl else LRM
        lines = wrap_lines(text, self.WRAP)
        if updated:
            lines = [(_("آخر تحديث: %s") % updated), ""] + lines
        self["text"].setText("\n".join((mark + l) if l else l for l in lines))
