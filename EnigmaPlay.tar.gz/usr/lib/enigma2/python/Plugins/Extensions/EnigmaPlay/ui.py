# -*- coding: utf-8 -*-
"""
EnigmaPlay UI Engine (Prompt 7 - Details Fixes & Categories Tab)
================================================================
Fixes implemented:
- D1: If version is empty or "N/A", show "—" (no "v" prefix) in stats, info card, and lists. Never "vN/A".
- D2: Sub-category line shows only source if sub-category name equals category name.
- D3: "ما الجديد" entries format: "date · version". If no version, date ONLY. Never item name as version.
- D4: "معلومات إضافية" card: All values in ONE column right-aligned at fixed x, 180 design px to left of
      card's inner right edge. All 4 borders and rounded corners drawn with exact height.
- D5: Focus ring on sections wraps WHOLE section: header + card/text, full content width, 4px offset.
- D6: Content scroll clamped: max_offset = max(0, content_height - viewport_height). Last element sits
      at bottom with 30px padding, no big white area.
- Part C: Categories tab ("التصنيفات"):
      * C1: Top bar tabs focusable (UP from content, LEFT/RIGHT between tabs & search pill, OK switches tab).
            Active tab green with 4px underline.
      * C2: Chips row (.chips) from CATEGORIES map in specified order from right, horizontal auto-scrolling,
            OK selects and keeps focus on chip.
      * C3: Sub-filter row shown when category has >= 2 sub-codes ("الكل" + sorted by count descending).
      * C4: List rows (.li) with 64px category icon + letter, title 21px, meta line, status pill (تثبيت/فتح/تحديث).
            OK opens details, RED/BACK restores state. Sorted by updated date first (newest first) then by name.
      * C5: Performance: render ONLY viewport rows (+2 above/below). PAGE UP / PAGE DOWN jumps 5 rows.
      * C6: Empty result shows: "لا توجد عناصر في هذا القسم."
"""

from __future__ import print_function, unicode_literals, absolute_import, division
import os
import sys
import math
import re
from datetime import datetime
from collections import Counter
from PIL import Image, ImageDraw, ImageFont

# Enigma2 imports (guarded)
try:
    from enigma import ePoint, eSize, gFont, getDesktop, eTimer, eLabel
    from Screens.Screen import Screen
    from Components.Label import Label
    from Components.Pixmap import Pixmap as _E2Pixmap
    if hasattr(_E2Pixmap, "setPixmap"):
        Pixmap = _E2Pixmap
    else:
        # EGAMI (and some other images) have no Pixmap.setPixmap(): set it on the widget instance
        class Pixmap(_E2Pixmap):
            def setPixmap(self, pm):
                if self.instance is not None and pm is not None:
                    self.instance.setPixmap(pm)
    from Components.ActionMap import ActionMap
    from skin import parseColor
    from Screens.Standby import TryQuitMainloop
    HAS_E2 = True
except ImportError:
    HAS_E2 = False
    class MockInstance(object):
        def move(self, *a): pass
        def resize(self, *a): pass
        def setForegroundColor(self, *a): pass
        def setFont(self, *a): pass
        def setHAlign(self, *a): pass
        def setVAlign(self, *a): pass
        def setTransparent(self, *a): pass
        def setAlphatest(self, *a): pass
    class Screen(dict):
        def __init__(self, *args, **kwargs):
            super(Screen, self).__init__()
            self.onLayoutFinish = []
    class Label(object):
        def __init__(self, *args, **kwargs):
            self.instance = MockInstance()
        def setText(self, *a): pass
        def hide(self): pass
        def show(self): pass
    class Pixmap(object):
        def __init__(self, *args, **kwargs):
            self.instance = MockInstance()
        def setPixmap(self, *a): pass
        def hide(self): pass
        def show(self): pass
    class ActionMap(object):
        def __init__(self, *args, **kwargs): pass
    class eLabel(object):
        alignCenter = 1
        alignRight = 2
        alignLeft = 0
    def parseColor(c): return c
    def gFont(n, s): return (n, s)
    def ePoint(x, y): return (x, y)
    def eSize(w, h): return (w, h)

from json import dumps as json_dumps, loads as json_loads
import threading
import time
from . import account
from . import backup as ep_backup
from . import settings
from .i18n import _, IS_RTL, LANG
from .theme import C, SURFACE, PAGE_BG, img_path, theme_xml, DARK, save_image
from . import theme as _theme
from .catalog import CATEGORIES, SUBCODES
from . import catalog as ep_catalog
from . import installer

# ---------------------------------------------------------------------------
# CONSTANTS & SCALING
# ---------------------------------------------------------------------------
SCREEN_W = 1920
SCREEN_H = 1080
SCALE_FACTOR = 1.5

def px(v):
    return int(round(v * SCALE_FACTOR))

PLUGIN_PATH = os.path.dirname(__file__)
IMAGES_DIR = os.path.join(PLUGIN_PATH, "images", "fhd")
FONTS_DIR = os.path.join(PLUGIN_PATH, "fonts")
from . import i18n as _i18n
_FONT_REG, _FONT_MED, _FONT_BLD = _i18n.font_files()
TTF_PATH = _FONT_REG
# Latin languages use DejaVu; its bold is clearly wider than the regular, so measure with the bold
# one there (text is cut a little earlier instead of wrapping onto a hidden second line).
TTF_MEASURE = _FONT_REG if _i18n.IS_RTL else _FONT_BLD

if HAS_E2:
    try:
        from enigma import addFont
        # isReplacement=0: keep the image's own fallback font for scripts our fonts lack
        addFont(_FONT_REG, "TajawalRegular", 100, 0)
        addFont(_FONT_MED, "TajawalMedium", 100, 0)
        addFont(_FONT_BLD, "TajawalBold", 100, 0)
    except Exception:
        pass

# ---------------------------------------------------------------------------
# RTL / LTR: the UI is designed right-to-left (Arabic). For left-to-right languages every
# widget is mirrored horizontally and the LEFT/RIGHT keys are swapped, so all layout and
# navigation code stays the same.
# ---------------------------------------------------------------------------
MIRROR = not IS_RTL


def place(widget, x_px, y_px, w_px, h_px):
    """Move + resize a widget (pixel units), mirrored for left-to-right languages."""
    if MIRROR:
        x_px = SCREEN_W - x_px - w_px
    widget.instance.move(ePoint(x_px, y_px))
    widget.instance.resize(eSize(w_px, h_px))


def arrow_icon():
    """'More' arrow: points left in RTL, right in LTR."""
    src = img_path("arrow_left.png")
    if not MIRROR:
        return src
    out = os.path.join(_theme.GEN_DIR, "arrow_right.png")
    if not os.path.exists(out):
        try:
            out = save_image(Image.open(src).transpose(Image.FLIP_LEFT_RIGHT), out)
        except Exception:
            return src
    return out


def mirror_skin_xml(xml):
    if not MIRROR:
        return xml

    def fix(m):
        tag = m.group(0)
        pm = re.search(r'position="(-?\d+),(-?\d+)"', tag)
        sm = re.search(r'size="(\d+),(\d+)"', tag)
        if pm and sm:
            x, y, w = int(pm.group(1)), int(pm.group(2)), int(sm.group(1))
            if w > 1:
                tag = tag.replace(pm.group(0), 'position="%d,%d"' % (SCREEN_W - x - w, y), 1)
        if 'halign="right"' in tag:
            tag = tag.replace('halign="right"', 'halign="left"')
        return tag
    return re.sub(r'<(widget|eLabel)[^>]*/>', fix, xml)


# Layer pool sizes
POOL_BG = 70      # Layer 1: background shapes
POOL_IMG = 70     # Layer 2: icons / images
POOL_LBL = 140    # Layer 3: text labels

CATEGORY_COLORS = {
}

# C2: Chips order from the RIGHT (one per category from CATEGORIES map)
CAT_CHIPS = [
    ("all", _("الكل")),
]

_PIXMAP_CACHE = {}

def get_cached_pixmap(path):
    if not HAS_E2 or not path:
        return None
    if path not in _PIXMAP_CACHE:
        try:
            from enigma import loadPNG
            pix = loadPNG(path)
            if pix:
                _PIXMAP_CACHE[path] = pix
        except Exception:
            return None
    return _PIXMAP_CACHE.get(path)

def measure_text_width(text, font_size_px):
    try:
        if os.path.exists(TTF_MEASURE):
            font = ImageFont.truetype(TTF_MEASURE, font_size_px)
            bbox = font.getbbox(text)
            return bbox[2] - bbox[0]
    except Exception:
        pass
    return int(len(text) * font_size_px * 0.58)

def one_line(text, w_design, size_design):
    """Cut text with an ellipsis so it fits on one line of w_design (design units)."""
    text = " ".join((text or "").split())
    max_px = px(w_design) - px(4)
    fs = px(size_design)
    if measure_text_width(text, fs) <= max_px:
        return text
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if measure_text_width(text[:mid].rstrip() + "…", fs) <= max_px:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo].rstrip() + "…"

# Wget progress noise filter regex
WGET_NOISE_RE = re.compile(r"^\s*\d+K[ .]+\d+%", re.IGNORECASE)

# ---------------------------------------------------------------------------
# HELPERS FOR D1, D4, D5, C2, C4
# ---------------------------------------------------------------------------
def clean_version(v):
    if not v:
        return ""
    v_str = str(v).strip()
    if v_str.upper() in ("N/A", "NA", "NONE", "NULL", "—", "-"):
        return ""
    return v_str

def format_version_display(v, prefix_v=True):
    cv = clean_version(v)
    if not cv:
        return "—"
    if prefix_v:
        if cv.lower().startswith("v"):
            return cv
        return "v" + cv
    return cv

def get_card_bg_pixmap(w_design, h_design, radius_design=14, stroke_color=None, fill_color=None):
    stroke_color = C(stroke_color or "#dadce0")
    fill_color = SURFACE if (fill_color is None or fill_color == "#ffffff") else C(fill_color)
    w_px = px(w_design)
    h_px = px(h_design)
    r_px = px(radius_design)
    cache_key = "card_bg_%d_%d_%s_%s" % (w_px, h_px, stroke_color.replace("#", ""), fill_color.replace("#", ""))
    cache_path = os.path.join(_theme.GEN_DIR, cache_key + ".png")
    if not os.path.exists(cache_path):
        st = max(1, px(1))
        im = Image.new("RGBA", (w_px, h_px), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([0, 0, w_px - 1, h_px - 1], radius=r_px, fill=fill_color, outline=stroke_color, width=st)
        cache_path = save_image(im, cache_path)
    return cache_path

def get_focus_ring_pixmap(w_design, h_design, radius_design=18, stroke_color="#01875f", stroke_w_design=3):
    w_px = px(w_design)
    h_px = px(h_design)
    r_px = px(radius_design)
    st = max(2, px(stroke_w_design))
    cache_key = "focus_ring_%d_%d_%d_%d" % (w_px, h_px, st, r_px)
    cache_path = os.path.join(_theme.GEN_DIR, cache_key + ".png")
    if not os.path.exists(cache_path):
        im = Image.new("RGBA", (w_px, h_px), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([st // 2, st // 2, w_px - 1 - st // 2, h_px - 1 - st // 2], radius=r_px, outline=stroke_color, width=st)
        cache_path = save_image(im, cache_path)
    return cache_path

def get_avatar_pixmap(size_design=42):
    """The user's profile picture as a round PNG (or the default E2 avatar)."""
    src = account.avatar_file()
    if not src:
        return img_path("avatar.png")
    s_px = px(size_design)
    out = os.path.join(_theme.GEN_DIR, "avatar_user_%d_%d.png" % (account.avatar_version(), s_px))
    if not os.path.exists(out):
        try:
            k = 4
            im = Image.open(src).convert("RGB")
            m = min(im.size)
            im = im.crop(((im.width - m) // 2, (im.height - m) // 2, (im.width + m) // 2, (im.height + m) // 2))
            im = im.resize((s_px * k, s_px * k), Image.LANCZOS)
            mask = Image.new("L", (s_px * k, s_px * k), 0)
            ImageDraw.Draw(mask).ellipse([0, 0, s_px * k - 1, s_px * k - 1], fill=255)
            res = Image.new("RGBA", (s_px * k, s_px * k), (0, 0, 0, 0))
            res.paste(im, (0, 0), mask)
            out = save_image(res.resize((s_px, s_px), Image.LANCZOS), out, "PNG")
        except Exception:
            return img_path("avatar.png")
    return out


BELL_X, BELL_Y, BELL_SZ = 420, 14, 48


def get_bell_pixmap(count=0, size_design=BELL_SZ, color="#5f6368"):
    """Notification bell (Google Play style) with a red badge holding the count (9+ above nine)."""
    color = C(color)
    s_px = px(size_design)
    badge = "" if count <= 0 else ("9+" if count > 9 else str(count))
    cache_path = os.path.join(_theme.GEN_DIR, "bell_%d_%s_%s.png" % (s_px, color.strip("#"), badge or "0"))
    if not os.path.exists(cache_path):
        k = 4
        n = s_px * k
        im = Image.new("RGBA", (n, n), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        cx = n * 0.46
        top = n * 0.20
        bw = n * 0.50                    # bell width at the rim
        rim_y = n * 0.70
        d.ellipse([cx - n * 0.045, top - n * 0.065, cx + n * 0.045, top + n * 0.025], fill=color)       # knob
        d.chord([cx - bw * 0.36, top, cx + bw * 0.36, top + bw * 0.62], 180, 360, fill=color)           # dome
        d.polygon([(cx - bw * 0.36, top + bw * 0.31), (cx + bw * 0.36, top + bw * 0.31),
                   (cx + bw * 0.50, rim_y), (cx - bw * 0.50, rim_y)], fill=color)                          # body
        d.rounded_rectangle([cx - bw * 0.58, rim_y - n * 0.01, cx + bw * 0.58, rim_y + n * 0.06],
                            radius=n * 0.03, fill=color)                                                     # rim
        d.ellipse([cx - n * 0.07, rim_y + n * 0.06, cx + n * 0.07, rim_y + n * 0.17], fill=color)       # clapper
        if badge:
            r = n * (0.20 if len(badge) == 1 else 0.23)
            bx, by = n * 0.74, n * 0.24
            d.ellipse([bx - r - n * 0.03, by - r - n * 0.03, bx + r + n * 0.03, by + r + n * 0.03], fill=C("#ffffff"))
            d.ellipse([bx - r, by - r, bx + r, by + r], fill="#d93025")
            try:
                f = ImageFont.truetype(_FONT_BLD, int(r * (1.25 if len(badge) == 1 else 1.0)))
            except Exception:
                f = ImageFont.load_default()
            try:
                l, tp, rr, bt = d.textbbox((0, 0), badge, font=f)
                tw, th = rr - l, bt - tp
                d.text((bx - tw / 2.0 - l, by - th / 2.0 - tp), badge, fill="#ffffff", font=f)
            except Exception:
                d.text((bx - r / 2, by - r / 2), badge, fill="#ffffff", font=f)
        cache_path = save_image(im.resize((s_px, s_px), Image.LANCZOS), cache_path)
    return cache_path


def get_star_pixmap(size_design, filled=True, color="#01875f"):
    """Five-point star (filled or outline), antialiased, cached."""
    import math
    color = C(color) if not filled else color
    s_px = px(size_design)
    cache_path = os.path.join(_theme.GEN_DIR, "star_%d_%s_%s.png" % (s_px, "f" if filled else "o", color.replace("#", "")))
    if not os.path.exists(cache_path):
        k = 4
        n = s_px * k
        im = Image.new("RGBA", (n, n), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        cx = cy = n / 2.0
        ro = n * 0.48
        ri = ro * 0.42
        pts = []
        for i in range(10):
            r = ro if i % 2 == 0 else ri
            a = math.pi / 2 + i * math.pi / 5
            pts.append((cx + r * math.cos(a), cy - r * math.sin(a) + n * 0.04))
        if filled:
            d.polygon(pts, fill=color)
        else:
            d.line(pts + [pts[0]], fill=color, width=max(2, int(n * 0.07)), joint="curve")
        im = im.resize((s_px, s_px), Image.LANCZOS)
        cache_path = save_image(im, cache_path, "PNG")
    return cache_path


def format_count(n):
    """Google-Play style download count: 7, 10+, 50+, 100+, 1K+, 5K+, 10K+, ..."""
    try:
        n = int(n)
    except Exception:
        return "0"
    if n < 10:
        return str(n)
    for step, div, suf in ((1000000, 1000000, "M"), (1000, 1000, "K"), (1, 1, "")):
        if n >= step:
            v = n // div
            for b in (500, 100, 50, 10, 5, 1):
                if v >= b:
                    return "%d%s+" % (b, suf)
    return str(n)


def format_rating(r):
    try:
        return "%.1f" % float(r)
    except Exception:
        return "—"


# ---------------------------------------------------------------------------
# ACCOUNT MENU (opened from the E2 avatar, Google-Play style)
# ---------------------------------------------------------------------------
ACC_MENU_X = 34
ACC_MENU_Y = 72
ACC_MENU_W = 360
ACC_HEADER_H = 92
ACC_ITEM_H = 42
ACC_GROUP_GAP = 17
ACC_SHADOW = 12

ACC_MAX_ITEMS = 14            # widgets created per item; the settings page has 12


def acc_menu_groups(page, logged_in):
    """Groups of (action_id, label, icon); a divider is drawn between groups."""
    if page == "settings":
        return [
            [("set:%s" % k, settings.label(k), "settings") for k in settings.ORDER],
            [("clear_cache", _("مسح الكاش"), "trash"),
             ("back", _("رجوع"), "logout")],
        ]
    if page == "about":
        return [
            [("legal:privacy", _("سياسة الخصوصية"), "info"),
             ("legal:terms", _("شروط الاستخدام"), "info")],
            [("back", _("رجوع"), "logout")],
        ]
    if page == "login":
        return [
            [("pair", _("ربط من الجوال (رمز)"), "sync"),
             ("userpass", _("اسم المستخدم وكلمة المرور"), "account"),
             ("register", _("إنشاء حساب جديد"), "account"),
             ("forgot", _("نسيت كلمة المرور"), "settings")],
            [("back", _("رجوع"), "logout")],
        ]
    top = ([("restore", _("استعادة بلاجيناتي"), "restore"),
            ("sync", _("مزامنة بلاجيناتي"), "sync")] if logged_in
           else [("login", _("تسجيل الدخول"), "account")])
    tail = ([("logout", _("تسجيل الخروج"), "logout"), ("exit", _("خروج"), "exit")] if logged_in
            else [("exit", _("خروج"), "exit")])
    return [
        top,
        [("mine", _("بلاجيناتي"), "library"),
         ("updates", _("التحديثات المتوفرة"), "updates"),
         ("history", _("سجل التثبيت"), "history")],
        [("reload", _("تحديث القائمة"), "refresh")],
        [("settings", _("الإعدادات"), "settings"),
         ("about", _("حول EnigmaPlay"), "info")],
        tail,
    ]


def acc_menu_layout(groups):
    """Return (items_with_y, divider_ys, total_h) in design units, relative to menu top."""
    y = ACC_HEADER_H
    dividers = [y]
    y += 8
    items = []
    for gi, grp in enumerate(groups):
        for it in grp:
            items.append((it, y))
            y += ACC_ITEM_H
        if gi < len(groups) - 1:
            y += 8
            dividers.append(y)
            y += ACC_GROUP_GAP - 8
    y += 8
    return items, dividers, y


def get_acc_menu_card_pixmap(groups, w_design=ACC_MENU_W):
    """White rounded card + soft shadow + group dividers, cached as PNG."""
    _items, dividers, total_h = acc_menu_layout(groups)
    w_px, h_px, sh = px(w_design), px(total_h), px(ACC_SHADOW)
    sig = "_".join(str(px(d)) for d in dividers)
    cache_path = os.path.join(_theme.GEN_DIR, "acc_menu_card_%d_%d_%s.png" % (w_px, h_px, sig))
    if not os.path.exists(cache_path):
        from PIL import ImageFilter
        W, H = w_px + sh * 2, h_px + sh * 2
        shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ds = ImageDraw.Draw(shadow)
        ds.rounded_rectangle([sh, sh + px(3), sh + w_px - 1, sh + h_px - 1 + px(3)], radius=px(16), fill=(0, 0, 0, 70))
        shadow = shadow.filter(ImageFilter.GaussianBlur(px(7)))
        d = ImageDraw.Draw(shadow)
        d.rounded_rectangle([sh, sh, sh + w_px - 1, sh + h_px - 1], radius=px(16), fill=SURFACE, outline=C("#dadce0"), width=max(1, px(1)))
        for dy in dividers:
            y = sh + px(dy)
            d.line([sh + 1, y, sh + w_px - 2, y], fill=C("#e3e3e3"), width=max(1, px(1)))
        cache_path = save_image(shadow, cache_path)
    return cache_path, total_h


def get_round_box_pixmap(w_design, h_design, radius_design=28, fill=None):
    fill = fill or SURFACE
    cache_path = os.path.join(_theme.GEN_DIR, "round_box_%d_%d_%d_%s.png" % (px(w_design), px(h_design), px(radius_design), fill.strip("#")))
    if not os.path.exists(cache_path):
        im = Image.new("RGBA", (px(w_design), px(h_design)), (0, 0, 0, 0))
        ImageDraw.Draw(im).rounded_rectangle([0, 0, px(w_design) - 1, px(h_design) - 1], radius=px(radius_design), fill=fill)
        cache_path = save_image(im, cache_path)
    return cache_path


def get_acc_focus_pixmap(w_design, h_design):
    cache_path = os.path.join(_theme.GEN_DIR, "acc_focus_%d_%d.png" % (px(w_design), px(h_design)))
    if not os.path.exists(cache_path):
        im = Image.new("RGBA", (px(w_design), px(h_design)), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([0, 0, px(w_design) - 1, px(h_design) - 1], radius=px(10), fill=C("#e6f4ea"), outline="#01875f", width=max(2, px(2)))
        cache_path = save_image(im, cache_path)
    return cache_path


def get_device_summary():
    """(title, subtitle) describing this receiver, best effort on any image."""
    model, distro, version = "", "", ""
    try:
        from boxbranding import getMachineName, getImageDistro, getImageVersion
        model, distro, version = getMachineName(), getImageDistro(), getImageVersion()
    except Exception:
        pass
    if not model:
        for f in ("/proc/stb/info/vumodel", "/proc/stb/info/model", "/proc/stb/info/boxtype", "/etc/hostname"):
            try:
                with open(f) as fh:
                    model = fh.read().strip()
                if model:
                    break
            except Exception:
                continue
    if not distro:
        try:
            with open("/etc/issue") as fh:
                distro = fh.readline().replace("\\n", "").replace("\\l", "").strip()
        except Exception:
            pass
    ip = ""
    try:
        import socket
        sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sk.settimeout(0.5)
        sk.connect(("8.8.8.8", 80))
        ip = sk.getsockname()[0]
        sk.close()
    except Exception:
        pass
    title = (model or "Enigma2").upper() if model and len(model) <= 12 else (model or "Enigma2")
    sub = " ".join(x for x in (distro, version) if x)
    if ip:
        sub = (sub + "  ·  " if sub else "") + ip
    return title, sub or "Enigma2"


def get_tab_line_pixmap(w_design, h_design=4, color="#01875f"):
    """Solid underline pixmap sized exactly to the active tab (Pixmap widgets don't stretch)."""
    w_px = px(w_design)
    h_px = max(2, px(h_design))
    cache_path = os.path.join(_theme.GEN_DIR, "tab_line_%d_%d.png" % (w_px, h_px))
    if not os.path.exists(cache_path):
        im = Image.new("RGBA", (w_px, h_px), color)
        cache_path = save_image(im, cache_path)
    return cache_path

def get_chip_bg_pixmap(w_design, selected=False):
    w_px = px(w_design)
    h_px = px(38)
    r_px = px(10)
    st = max(1, px(1))
    cache_key = "chip_%s_%d" % ("on" if selected else "off", w_px)
    cache_path = os.path.join(_theme.GEN_DIR, cache_key + ".png")
    if not os.path.exists(cache_path):
        fill = C("#e6f4ee") if selected else SURFACE
        outline = "#01875f" if selected else C("#dadce0")
        im = Image.new("RGBA", (w_px, h_px), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle([0, 0, w_px - 1, h_px - 1], radius=r_px, fill=fill, outline=outline, width=st)
        cache_path = save_image(im, cache_path)
    return cache_path

def sort_catalog_items(items):
    from . import catalog as cat_mod
    def sort_key(it):
        dt = cat_mod._parse_date(it.updated) if hasattr(it, "updated") and it.updated else (0, 0, 0)
        has_date = 0 if dt != (0, 0, 0) else 1
        date_tuple = (-dt[0], -dt[1], -dt[2])
        return (has_date, date_tuple, (it.name or "").lower())
    return sorted(items, key=sort_key)


def sort_search_results(items, query):
    from . import catalog as cat_mod
    q_low = (query or "").lower().strip()
    norm_q = cat_mod._normalize_search(query) if hasattr(cat_mod, "_normalize_search") else ""

    def sort_key(it):
        name_low = (it.name or "").lower()
        name_norm = cat_mod._normalize_search(it.name or "") if hasattr(cat_mod, "_normalize_search") else ""

        if name_low == q_low or (norm_q and name_norm == norm_q):
            match_score = 0
        elif name_low.startswith(q_low) or (norm_q and name_norm.startswith(norm_q)):
            match_score = 1
        elif q_low in name_low or (norm_q and norm_q in name_norm):
            match_score = 2
        else:
            match_score = 3

        dt = cat_mod._parse_date(it.updated) if hasattr(it, "updated") and it.updated else (0, 0, 0)
        has_date = 0 if dt != (0, 0, 0) else 1
        date_tuple = (-dt[0], -dt[1], -dt[2])
        return (match_score, has_date, date_tuple, name_low)

    return sorted(items, key=sort_key)


ICON_VARIANT_SIZES = {"card": 150, "128": 128, "64": 64}
FIT_ICON_DIR = "/tmp/enigmaplay/icons_fit"


def fit_icon(path, size_design):
    """
    Return a square PNG (px(size_design)) made from any icon (wide logos, big PNGs...).
    Pixmap widgets don't scale, so every non-standard icon goes through here.
    Non-square logos are centred on a rounded tile filled with the logo's edge colour.
    """
    try:
        import hashlib
        st = os.stat(path)
        key = hashlib.md5(("%s|%s|%s" % (path, st.st_mtime, st.st_size)).encode("utf-8")).hexdigest()[:16]
        out_px = px(size_design)
        out = os.path.join(FIT_ICON_DIR, "%s_%d.png" % (key, out_px))
        if os.path.exists(out):
            return out
        if not os.path.isdir(FIT_ICON_DIR):
            os.makedirs(FIT_ICON_DIR)
        src = Image.open(path).convert("RGBA")
        w, h = src.size
        ratio = float(w) / max(1, h)
        if 0.9 <= ratio <= 1.1:
            im = src.resize((out_px, out_px), Image.LANCZOS)
        else:
            bg = src.getpixel((w // 2, max(0, min(h - 1, int(h * 0.1)))))
            if len(bg) == 4 and bg[3] < 200:
                bg = (255, 255, 255, 255)
            im = Image.new("RGBA", (out_px, out_px), (0, 0, 0, 0))
            mask = Image.new("L", (out_px, out_px), 0)
            ImageDraw.Draw(mask).rounded_rectangle([0, 0, out_px - 1, out_px - 1], radius=int(out_px * 0.19), fill=255)
            im.paste(Image.new("RGBA", (out_px, out_px), bg), (0, 0), mask)
            # drop the logo's own outer border, then fit 90% of the tile width
            c = src.crop((int(w * 0.04), int(h * 0.08), int(w * 0.96), int(h * 0.92)))
            tw = int(out_px * 0.9)
            th = max(1, int(c.size[1] * tw / float(c.size[0])))
            if th > tw:
                th = tw
                tw = max(1, int(c.size[0] * th / float(c.size[1])))
            c = c.resize((tw, th), Image.LANCZOS)
            im.paste(c, ((out_px - tw) // 2, (out_px - th) // 2), c)
        tmp = save_image(im, out + ".tmp", "PNG")
        out = tmp[:-4]
        os.rename(tmp, out)
        return out
    except Exception:
        return None


def fit_image_box(path, w_design, h_design, radius_design=12, bg=C("#f1f3f4")):
    """Scale an image to fit (contain) a WxH box; pads with bg and rounds the corners. Cached."""
    try:
        import hashlib
        st = os.stat(path)
        wp, hp = px(w_design), px(h_design)
        key = hashlib.md5(("%s|%s|%s|%s" % (path, st.st_mtime, st.st_size, bg)).encode("utf-8")).hexdigest()[:16]
        out = os.path.join(FIT_ICON_DIR, "box_%s_%dx%d.png" % (key, wp, hp))
        if os.path.exists(out):
            return out
        if not os.path.isdir(FIT_ICON_DIR):
            os.makedirs(FIT_ICON_DIR)
        src = Image.open(path).convert("RGBA")
        sw, sh = src.size
        scale = min(float(wp) / sw, float(hp) / sh)
        nw, nh = max(1, int(sw * scale)), max(1, int(sh * scale))
        src = src.resize((nw, nh), Image.LANCZOS)
        canvas = Image.new("RGBA", (wp, hp), bg if bg else (0, 0, 0, 0))
        canvas.paste(src, ((wp - nw) // 2, (hp - nh) // 2), src)
        if radius_design:
            mask = Image.new("L", (wp, hp), 0)
            ImageDraw.Draw(mask).rounded_rectangle([0, 0, wp - 1, hp - 1], radius=px(radius_design), fill=255)
            final = Image.new("RGBA", (wp, hp), (0, 0, 0, 0))
            final.paste(canvas, (0, 0), mask)
            canvas = final
        tmp = save_image(canvas, out + ".tmp", "PNG")
        out = tmp[:-4]
        os.rename(tmp, out)
        return out
    except Exception:
        return None


FEAT_W, FEAT_H, FEAT_GAP = 392, 262, 18
FEAT_HERO = (16, 14, 360, 120)            # x, y, w, h inside the card (design units)
FEAT_BG = (12, 17, 16, 255)
FEAT_GLOW = (29, 233, 182)


def get_feature_card_pixmap(item_key, hero_path, icon_path, state):
    """Google Play style featured card (dark, glowing framed artwork, install pill).
    Text is drawn by Enigma2 on top (Arabic shaping), so only shapes and images are baked in.
    hero_path: a screenshot (cover-cropped) or None -> big icon on a dark gradient."""
    try:
        import hashlib
        from PIL import ImageFilter
        w, h = px(FEAT_W), px(FEAT_H)
        sig = "%s|%s|%s|%s|%s|%s" % (item_key, hero_path, os.path.getmtime(hero_path) if hero_path else 0,
                                     icon_path, state, MIRROR)
        out = os.path.join(_theme.GEN_DIR, "feat_%s_%dx%d.png" % (hashlib.md5(sig.encode("utf-8")).hexdigest()[:16], w, h))
        if os.path.exists(out):
            return out
        card = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        base = Image.new("RGBA", (w, h), FEAT_BG)
        mask = Image.new("L", (w, h), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=px(18), fill=255)
        card.paste(base, (0, 0), mask)

        hx, hy, hw, hh = [px(v) for v in FEAT_HERO]
        # artwork
        if hero_path:
            src = Image.open(hero_path).convert("RGBA")
            sw, sh = src.size
            sc = max(float(hw) / sw, float(hh) / sh)          # cover
            src = src.resize((max(1, int(sw * sc)), max(1, int(sh * sc))), Image.LANCZOS)
            l, t = (src.size[0] - hw) // 2, (src.size[1] - hh) // 2
            art = src.crop((l, t, l + hw, t + hh))
        else:
            art = Image.new("RGBA", (hw, hh), (0, 0, 0, 255))
            g = ImageDraw.Draw(art)
            for yy in range(hh):                               # teal -> dark vertical gradient
                k = yy / float(max(1, hh - 1))
                g.line([(0, yy), (hw, yy)], fill=(int(8 + 10 * (1 - k)), int(70 * (1 - k) + 25), int(60 * (1 - k) + 24), 255))
            if icon_path and os.path.exists(icon_path):
                ic = Image.open(icon_path).convert("RGBA")
                isz = int(hh * 0.62)
                ic = ic.resize((isz, isz), Image.LANCZOS)
                art.paste(ic, ((hw - isz) // 2, (hh - isz) // 2), ic)
        amask = Image.new("L", (hw, hh), 0)
        ImageDraw.Draw(amask).rounded_rectangle([0, 0, hw - 1, hh - 1], radius=px(10), fill=255)
        # soft glow around the frame
        glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        ImageDraw.Draw(glow).rounded_rectangle([hx - px(2), hy - px(2), hx + hw + px(1), hy + hh + px(1)],
                                               radius=px(12), outline=FEAT_GLOW + (200,), width=px(5))
        glow = glow.filter(ImageFilter.GaussianBlur(px(7)))
        card = Image.alpha_composite(card, glow)
        card.paste(art, (hx, hy), amask)
        ImageDraw.Draw(card).rounded_rectangle([hx - 1, hy - 1, hx + hw, hy + hh], radius=px(11),
                                               outline=FEAT_GLOW + (255,), width=max(2, px(2)))
        # fade the bottom of the artwork into the card (headline sits there)
        fade = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        fd = ImageDraw.Draw(fade)
        fh = px(26)
        for i in range(fh):
            a = int(150 * (i / float(fh)))
            fd.line([(hx, hy + hh - fh + i), (hx + hw, hy + hh - fh + i)], fill=FEAT_BG[:3] + (a,))
        card = Image.alpha_composite(card, fade)
        # install pill: left in RTL; the widgets on top are mirrored for LTR languages, so the pill
        # baked into this picture moves to the right there too
        bx, by, bw, bh = px(16), px(208), px(108), px(38)
        if MIRROR:
            bx = w - bx - bw
        pill = {"install": FEAT_GLOW + (255,), "update": (251, 188, 4, 255)}.get(state, (60, 64, 67, 255))
        ImageDraw.Draw(card).rounded_rectangle([bx, by, bx + bw, by + bh], radius=bh // 2, fill=pill)
        card.paste(Image.new("RGBA", (w, h), (0, 0, 0, 0)), (0, 0), Image.eval(mask, lambda v: 255 - v))
        if not os.path.isdir(_theme.GEN_DIR):
            os.makedirs(_theme.GEN_DIR)
        tmp = save_image(card, out + ".tmp", "PNG")
        out = tmp[:-4]
        os.rename(tmp, out)
        return out
    except Exception:
        return None


def get_details_hero_pixmap(shot_path, w_design=1212, h_design=240):
    """Plugin page header art (Google Play style): the screenshot on the left, fading into the
    page colour toward the title (right) and the bottom."""
    try:
        import hashlib
        w, h = px(w_design), px(h_design)
        sig = "%s|%s|%s|%dx%d|%s" % (shot_path, os.path.getmtime(shot_path), PAGE_BG, w, h, MIRROR)
        out = os.path.join(_theme.GEN_DIR, "hero_%s.png" % hashlib.md5(sig.encode("utf-8")).hexdigest()[:16])
        if os.path.exists(out):
            return out
        aw = int(w * 0.58)
        src = Image.open(shot_path).convert("RGBA")
        sw, sh = src.size
        sc = max(float(aw) / sw, float(h) / sh)
        src = src.resize((max(1, int(sw * sc)), max(1, int(sh * sc))), Image.LANCZOS)
        l, t = (src.size[0] - aw) // 2, (src.size[1] - h) // 2
        art = src.crop((l, t, l + aw, t + h))
        # alpha: full on the left half, fading out to the right and toward the bottom/top edges
        mask = Image.new("L", (aw, h), 0)
        md = mask.load()
        for x in range(aw):
            fx = x / float(aw)
            ax = 1.0 if fx < 0.40 else max(0.0, 1.0 - (fx - 0.40) / 0.60)
            if fx < 0.04:
                ax *= fx / 0.04
            for y in range(h):
                fy = y / float(h)
                ay = 1.0 if 0.06 < fy < 0.45 else (fy / 0.06 if fy <= 0.06 else max(0.0, 1.0 - (fy - 0.45) / 0.40))
                md[x, y] = int(255 * 0.8 * ax * ay)
        canvas = Image.new("RGBA", (w, h), PAGE_BG)
        if MIRROR:
            # LTR: the title is on the left, so the picture sits right and fades toward the left
            # (only the fade is flipped, never the screenshot itself)
            canvas.paste(art, (w - aw, 0), mask.transpose(Image.FLIP_LEFT_RIGHT))
        else:
            canvas.paste(art, (0, 0), mask)
        if not os.path.isdir(_theme.GEN_DIR):
            os.makedirs(_theme.GEN_DIR)
        tmp = save_image(canvas.convert("RGB"), out + ".tmp", "PNG")
        out = tmp[:-4]
        os.rename(tmp, out)
        return out
    except Exception:
        return None


def get_item_icon(item, variant="64"):
    """
    Determines the best functional icon for a plugin item based on its purpose:
    - variant: "card" (150 design px = 225 FHD), "128" (128 design px = 192 FHD), "64" (64 design px = 96 FHD)
    Returns: (icon_path, has_custom_glyph)
    """
    if not item:
        fallback = img_path("icon_%s_extensions.png" % variant if variant != "card" else "card_icon_extensions.png")
        return fallback, False

    name = (getattr(item, "name", "") or "").lower()
    key = (getattr(item, "key", "") or "").lower()
    sub = (getattr(item, "subcode", "") or "").lower()
    category = (getattr(item, "category", "") or "").lower()
    desc = (getattr(item, "description", "") or "").lower()
    combined = "%s %s %s" % (name, key, desc)

    size_design = ICON_VARIANT_SIZES.get(variant, 64)

    # 0. Icon published in EnigmaPlay-Repo (downloaded in background, cached)
    icon_url = getattr(item, "icon_url", None)
    if icon_url:
        try:
            local_icon = ep_catalog.get_cached_icon(icon_url, getattr(item, "key", "") or "icon")
        except Exception:
            local_icon = None
        if local_icon:
            fitted = fit_icon(local_icon, size_design)
            if fitted:
                return fitted, True

    # 1. Check local installed plugin.png if installed
    installed_dirs = [
        os.path.join("/usr/lib/enigma2/python/Plugins/Extensions", getattr(item, "key", "") or ""),
        os.path.join("/usr/lib/enigma2/python/Plugins/Extensions", getattr(item, "name", "") or ""),
    ]
    for d in installed_dirs:
        p_icon = os.path.join(d, "plugin.png")
        if os.path.exists(p_icon):
            fitted = fit_icon(p_icon, size_design)
            if fitted:
                return fitted, True

    # 2. Specialized Functional Classification
    itype = None
    if "youtube" in combined:
        itype = "youtube"
    elif "ajpanel" in combined:
        itype = "ajpanel"
    elif any(x in combined for x in ["xstreamity", "bouquetmaker", "jedimaker", "customiptv", "xcplugin"]):
        itype = "iptv_box"
    elif any(x in combined for x in ["e2iplayer", "e2player", "tsiplayer", "cinema", "vod", "movie"]):
        itype = "video_player"
    elif any(x in combined for x in ["footonsat", "livefoot", "footscore", "livematch", "total90", "sport", "match"]) or sub == "spo":
        itype = "sports"
    elif any(x in combined for x in ["subssupport", "subtitle", "translate", "aisubtitles"]) or sub == "sub":
        itype = "subtitles"
    elif any(x in combined for x in ["quran", "athan", "azkar", "athkar", "muslim", "islam", "ansite"]) or sub == "qur":
        itype = "quran"
    elif any(x in combined for x in ["weather", "foreca", "oaweather"]) or sub == "wea":
        itype = "weather"
    elif any(x in combined for x in ["ipaudio", "audiomerge", "audioshift", "radio", "sound"]) or sub in ("aud", "rad"):
        itype = "audio"
    elif any(x in combined for x in ["chocholousek", "piconizer", "picon"]) or category == "picons" or sub == "pic":
        itype = "picons"
    elif any(x in combined for x in ["neoboot", "barryallen", "openmultiboot", "egamiboot", "multiboot"]) or sub == "mul":
        itype = "multiboot"
    elif "epg" in combined or sub == "epg":
        itype = "epg"
    elif any(x in combined for x in ["backup", "restore", "fullbackup"]) or sub == "bac":
        itype = "backup"
    elif any(x in combined for x in ["game", "battleship", "chess", "dame", "connectfour"]) or sub == "games":
        itype = "games"
    elif any(x in combined for x in ["oscam", "ncam", "cccam", "softcam", "biss", "key", "dcw", "suptv", "novacam", "ultracam", "freeserver", "xline", "hasbahca"]) or category == "softcams" or sub == "enc":
        itype = "softcams"
    elif "ciefp" in combined or category == "ciefp":
        itype = "ciefp"
    elif category == "settings" or sub == "set" or any(x in combined for x in ["vhannibal", "channel", "motor", "satellit", "setting", "lamedb"]):
        itype = "settings"
    elif category == "skins" or "skin" in combined:
        itype = "skins"
    elif category == "panels" or sub == "pan" or any(x in combined for x in ["panel", "dreamsat", "linuxsat", "levi45", "store"]):
        itype = "panels"
    elif sub == "ipt" or any(x in combined for x in ["iptv", "stream", "tvplus", "filmon", "pluto", "rakuten", "vavoo", "tvgarden", "tv", "sat"]):
        itype = "iptv"
    elif category == "display" or any(x in combined for x in ["bootlogo", "display", "lcd"]):
        itype = "display"
    elif category == "imagesd" or any(x in combined for x in ["image", "flash", "firmware"]):
        itype = "imagesd"
    elif category == "feeds" or any(x in combined for x in ["feed", "repo", "repository"]):
        itype = "feeds"
    elif category == "allinone" or any(x in combined for x in ["repair", "fix", "aio"]):
        itype = "allinone"
    elif any(x in combined for x in ["network", "vpn", "wireguard", "zerotier", "transmission", "webcam", "airnet", "cam"]):
        itype = "network"
    elif sub == "sys" or any(x in combined for x in ["system", "font", "driver"]):
        itype = "system"
    elif sub == "uti" or any(x in combined for x in ["tool", "manager", "clean", "calc", "swapper", "helper", "search"]):
        itype = "utilities"
    else:
        itype = category or "extensions"

    if variant == "card":
        fname = "card_icon_%s.png" % itype
        fb_fname = "card_icon_extensions.png"
    elif variant == "128":
        fname = "icon_128_%s.png" % itype
        fb_fname = "icon_128_extensions.png"
    else:
        fname = "icon_64_%s.png" % itype
        fb_fname = "icon_64_extensions.png"

    path = img_path(fname)
    if os.path.exists(path):
        return path, True

    fb_path = img_path(fb_fname)
    if os.path.exists(fb_path):
        return fb_path, True

    return fb_path, False




# ---------------------------------------------------------------------------
# SKIN XML BUILDER
# ---------------------------------------------------------------------------
def _tab_layout():
    """Top tabs sized to their (translated) text, laid out right-to-left from x=1021."""
    out, right = {}, (1032 if MIRROR else 1021)
    for key, label, base in (("tab_home", "لك", 65), ("tab_cats", "التصنيفات", 126), ("tab_mine", "بلاجيناتي", 113)):
        try:
            w = int(measure_text_width(_(label), px(20)) / SCALE_FACTOR) + 32
        except Exception:
            w = base
        w = max(base if not MIRROR else 60, w)
        out[key] = (right - w, w)
        right = right - w - 6
    return out


TABS = _tab_layout()


def build_skin_xml():
    xml = [
        '<screen name="EnigmaPlayScreen" position="0,0" size="%d,%d" title="EnigmaPlay" flags="wfNoBorder" backgroundColor="#ffffff">' % (SCREEN_W, SCREEN_H),
        '  <!-- Background Canvas (Pure White #ffffff) -->',
        '  <eLabel position="0,0" size="%d,%d" backgroundColor="#ffffff" zPosition="0" />' % (SCREEN_W, SCREEN_H),
    ]

    # Layer 1 - Background shapes (zPosition 10)
    for i in range(POOL_BG):
        xml.append('  <widget name="bg%d" position="0,0" size="1,1" zPosition="10" alphatest="blend" />' % i)

    # Layer 2 - Icons and images (zPosition 15)
    for i in range(POOL_IMG):
        xml.append('  <widget name="img%d" position="0,0" size="1,1" zPosition="15" alphatest="blend" />' % i)

    # Layer 3 - Text labels (zPosition 20)
    for i in range(POOL_LBL):
        xml.append('  <widget name="lbl%d" position="0,0" size="1,1" zPosition="20" transparent="1" />' % i)

    # Layer 4 - Focus ring (always on top of content, zPosition 25)
    xml.append('  <widget name="focus_ring" position="0,0" size="1,1" zPosition="25" alphatest="blend" />')
    # Top bar focus ring must sit ABOVE the top bar background (zPosition 30-36)
    xml.append('  <widget name="top_focus_ring" position="0,0" size="1,1" zPosition="37" alphatest="blend" />')

    # Fixed Top Bar (zPosition 30 - 36)
    xml.extend([
        '  <!-- TOP BAR BACKGROUND (#ffffff, zPosition 30) -->',
        '  <eLabel position="0,0" size="%d,%d" backgroundColor="#ffffff" zPosition="30" />' % (SCREEN_W, px(76)),
        '  <!-- TOP BAR BOTTOM BORDER (#dadce0, zPosition 31) -->',
        '  <eLabel position="0,%d" size="%d,%d" backgroundColor="#dadce0" zPosition="31" />' % (px(75), SCREEN_W, max(1, px(1))),
        '  <!-- Top Bar Fixed Widgets (zPosition 35) -->',
        '  <widget name="top_logo" position="%d,%d" size="%d,%d" zPosition="35" alphatest="blend" />' % (px(1212), px(21), px(34), px(34)),
        '  <widget name="top_title" position="%d,%d" size="%d,%d" font="TajawalMedium;%d" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="35" />' % ((px(1040), px(12), px(166), px(52), px(22)) if MIRROR else (px(1055), px(12), px(150), px(52), px(26))),
        '  <widget name="tab_home" position="%d,%d" size="%d,%d" font="TajawalBold;%d" foregroundColor="#01875f" backgroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="35" />' % (px(TABS["tab_home"][0]), px(14), px(TABS["tab_home"][1]), px(48), px(20)),
        '  <widget name="tab_line" position="%d,%d" size="%d,%d" zPosition="36" alphatest="blend" />' % (px(TABS["tab_home"][0]), px(72), px(TABS["tab_home"][1]), px(4)),
        '  <widget name="tab_cats" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="35" />' % (px(TABS["tab_cats"][0]), px(14), px(TABS["tab_cats"][1]), px(48), px(20)),
        '  <widget name="tab_mine" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="35" />' % (px(TABS["tab_mine"][0]), px(14), px(TABS["tab_mine"][1]), px(48), px(20)),
        '  <widget name="search_pill" position="%d,%d" size="%d,%d" zPosition="35" alphatest="blend" />' % (px(102), px(15), px(300), px(46)),
        '  <widget name="search_icon" position="%d,%d" size="%d,%d" zPosition="36" alphatest="blend" />' % (px(366), px(28), px(20), px(20)),
        '  <widget name="search_text" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="36" />' % (px(120), px(15), px(236), px(46), px(16)),
        '  <widget name="avatar" position="%d,%d" size="%d,%d" zPosition="35" alphatest="blend" />' % (px(34), px(17), px(42), px(42)),
        '  <widget name="bell" position="%d,%d" size="%d,%d" zPosition="35" alphatest="blend" />' % (px(BELL_X), px(BELL_Y), px(BELL_SZ), px(BELL_SZ)),
    ])

    # Fixed Keys Bar (zPosition 30 - 35)
    ky = 674
    xml.extend([
        '  <!-- KEYS BAR BACKGROUND (#f1f3f4, zPosition 30) -->',
        '  <eLabel position="0,%d" size="%d,%d" backgroundColor="#f1f3f4" zPosition="30" />' % (px(ky), SCREEN_W, px(46)),
        '  <!-- KEYS BAR TOP BORDER (#dadce0, zPosition 31) -->',
        '  <eLabel position="0,%d" size="%d,%d" backgroundColor="#dadce0" zPosition="31" />' % (px(ky), SCREEN_W, max(1, px(1))),
        '  <!-- Keys Bar Items (zPosition 35) -->',
        '  <widget name="dot_red" position="%d,%d" size="%d,%d" zPosition="35" alphatest="blend" />' % (px(1232), px(ky + 16), px(14), px(14)),
        '  <widget name="lbl_red" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#f1f3f4" transparent="1" halign="right" valign="center" zPosition="35" />' % (px(1054), px(ky + 6), px(170), px(34), px(16)),
        '  <widget name="dot_green" position="%d,%d" size="%d,%d" zPosition="35" alphatest="blend" />' % (px(1017), px(ky + 16), px(14), px(14)),
        '  <widget name="lbl_green" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#f1f3f4" transparent="1" halign="right" valign="center" zPosition="35" />' % (px(839), px(ky + 6), px(170), px(34), px(16)),
        '  <widget name="dot_yellow" position="%d,%d" size="%d,%d" zPosition="35" alphatest="blend" />' % (px(802), px(ky + 16), px(14), px(14)),
        '  <widget name="lbl_yellow" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#f1f3f4" transparent="1" halign="right" valign="center" zPosition="35" />' % (px(624), px(ky + 6), px(170), px(34), px(16)),
        '  <widget name="dot_blue" position="%d,%d" size="%d,%d" zPosition="35" alphatest="blend" />' % (px(587), px(ky + 16), px(14), px(14)),
        '  <widget name="lbl_blue" position="%d,%d" size="%d,%d" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#f1f3f4" transparent="1" halign="right" valign="center" zPosition="35" />' % (px(409), px(ky + 6), px(170), px(34), px(16)),
    ])

    # Account Menu (zPosition 60 - 63): above content & top bar, below dialogs/toasts
    xml.append('  <widget name="acc_card" position="0,0" size="1,1" zPosition="60" alphatest="blend" />')
    xml.append('  <widget name="acc_focus" position="0,0" size="1,1" zPosition="61" alphatest="blend" />')
    xml.append('  <widget name="acc_avatar" position="0,0" size="1,1" zPosition="62" alphatest="blend" />')
    xml.append('  <widget name="acc_name" position="0,0" size="1,1" font="TajawalBold;%d" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="62" />' % px(19))
    xml.append('  <widget name="acc_sub" position="0,0" size="1,1" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="62" />' % px(15))
    for i in range(ACC_MAX_ITEMS):
        xml.append('  <widget name="acc_icon%d" position="0,0" size="1,1" zPosition="62" alphatest="blend" />' % i)
        xml.append('  <widget name="acc_lbl%d" position="0,0" size="1,1" font="TajawalRegular;%d" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="62" />' % (i, px(18)))

    # Full-screen screenshot viewer (zPosition 90 - 93)
    xml.append('  <widget name="shot_dim" position="0,0" size="%d,%d" zPosition="90" alphatest="blend" />' % (SCREEN_W, SCREEN_H))
    xml.append('  <widget name="shot_full" position="0,0" size="1,1" zPosition="91" alphatest="blend" />')
    xml.append('  <widget name="shot_counter" position="0,0" size="1,1" font="TajawalMedium;%d" foregroundColor="#ffffff" backgroundColor="#000000" transparent="1" halign="center" valign="center" zPosition="92" />' % px(20))

    # Phone pairing panel (zPosition 94 - 98)
    xml.append('  <widget name="pair_dim" position="0,0" size="%d,%d" zPosition="94" alphatest="blend" />' % (SCREEN_W, SCREEN_H))
    xml.append('  <widget name="pair_box" position="0,0" size="1,1" zPosition="95" alphatest="blend" />')
    xml.append('  <widget name="pair_qr" position="0,0" size="1,1" zPosition="96" alphatest="blend" />')
    xml.append('  <widget name="pair_title" position="0,0" size="1,1" font="TajawalBold;%d" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="97" />' % px(28))
    xml.append('  <widget name="pair_text" position="0,0" size="1,1" font="TajawalRegular;%d" foregroundColor="#3c4043" backgroundColor="#ffffff" transparent="1" halign="right" valign="top" zPosition="97" />' % px(18))
    xml.append('  <widget name="pair_code" position="0,0" size="1,1" font="TajawalBold;%d" foregroundColor="#01875f" backgroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="97" />' % px(58))
    xml.append('  <widget name="pair_status" position="0,0" size="1,1" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="97" />' % px(17))

    # Modal Dialog Widgets (zPosition 100 - 120)
    xml.extend([
        '  <!-- DIALOG OVERLAY (zPosition 100) -->',
        '  <widget name="dlg_overlay" position="0,0" size="%d,%d" zPosition="100" alphatest="blend" />' % (SCREEN_W, SCREEN_H),
        '  <!-- DIALOG BOX (zPosition 105) -->',
        '  <widget name="dlg_box" position="0,0" size="1,1" zPosition="105" alphatest="blend" />',
        '  <!-- DIALOG TITLE & TEXT (zPosition 110) -->',
        '  <widget name="dlg_title" position="0,0" size="1,1" font="TajawalMedium;%d" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" halign="right" valign="center" zPosition="110" />' % px(26),
        '  <widget name="dlg_text" position="0,0" size="1,1" font="TajawalRegular;%d" foregroundColor="#5f6368" backgroundColor="#ffffff" transparent="1" halign="right" valign="top" zPosition="110" />' % px(19),
        '  <!-- DIALOG BUTTONS (zPosition 110-115) -->',
        '  <widget name="dlg_btn_ok" position="0,0" size="1,1" zPosition="110" alphatest="blend" />',
        '  <widget name="dlg_lbl_ok" position="0,0" size="1,1" font="TajawalBold;%d" foregroundColor="#ffffff" backgroundColor="#01875f" transparent="1" halign="center" valign="center" zPosition="115" />' % px(19),
        '  <widget name="dlg_btn_cancel" position="0,0" size="1,1" zPosition="110" alphatest="blend" />',
        '  <widget name="dlg_lbl_cancel" position="0,0" size="1,1" font="TajawalRegular;%d" foregroundColor="#202124" backgroundColor="#ffffff" transparent="1" halign="center" valign="center" zPosition="115" />' % px(19),
        '  <widget name="dlg_focus_ring" position="0,0" size="1,1" zPosition="120" alphatest="blend" />',
    ])

    # Toast Notification Widgets (zPosition 150 - 155)
    xml.extend([
        '  <widget name="toast_bg" position="0,0" size="1,1" zPosition="150" alphatest="blend" />',
        '  <widget name="toast_text" position="0,0" size="1,1" font="TajawalRegular;%d" foregroundColor="#ffffff" backgroundColor="#323232" transparent="1" halign="center" valign="center" zPosition="155" />' % px(19),
    ])

    xml.append('</screen>')
    return theme_xml(mirror_skin_xml("\n".join(xml)))


# ---------------------------------------------------------------------------
# MAIN SCREEN CLASS
# ---------------------------------------------------------------------------
class EnigmaPlayScreen(Screen):
    skin = build_skin_xml()

    def __init__(self, session, catalog_instance, start_view=None):
        Screen.__init__(self, session)
        self.session = session
        self.start_view = start_view
        self.catalog = catalog_instance
        self._sync_categories()

        # Layered Widget Pools
        self.bg_pool = []
        for i in range(POOL_BG):
            name = "bg%d" % i
            self[name] = Pixmap()
            self.bg_pool.append(self[name])

        self.img_pool = []
        for i in range(POOL_IMG):
            name = "img%d" % i
            self[name] = Pixmap()
            self.img_pool.append(self[name])

        self.lbl_pool = []
        for i in range(POOL_LBL):
            name = "lbl%d" % i
            self[name] = Label("")
            self.lbl_pool.append(self[name])

        self["focus_ring"] = Pixmap()
        self["top_focus_ring"] = Pixmap()

        # Fixed top bar widgets
        self["top_logo"] = Pixmap()
        self["top_title"] = Label("Enigma Play")
        self["tab_home"] = Label(_("لك"))
        self["tab_line"] = Pixmap()
        self["tab_cats"] = Label(_("التصنيفات"))
        self["tab_mine"] = Label(_("بلاجيناتي"))
        self["search_pill"] = Pixmap()
        self["search_icon"] = Pixmap()
        self["search_text"] = Label(_("ابحث عن بلجنات"))
        self["avatar"] = Pixmap()
        self["bell"] = Pixmap()
        self.bell_count = -1

        # Fixed keys bar widgets
        self["dot_red"] = Pixmap()
        self["lbl_red"] = Label(_("رجوع"))
        self["dot_green"] = Pixmap()
        self["lbl_green"] = Label(_("تثبيت / فتح"))
        self["dot_yellow"] = Pixmap()
        self["lbl_yellow"] = Label(_("تحديث الكل"))
        self["dot_blue"] = Pixmap()
        self["lbl_blue"] = Label(_("بحث"))

        # Modal dialog widgets
        self["dlg_overlay"] = Pixmap()
        self["dlg_box"] = Pixmap()
        self["dlg_title"] = Label("")
        self["dlg_text"] = Label("")
        self["dlg_btn_ok"] = Pixmap()
        self["dlg_lbl_ok"] = Label("")
        self["dlg_btn_cancel"] = Pixmap()
        self["dlg_lbl_cancel"] = Label("")
        self["dlg_focus_ring"] = Pixmap()

        # Screenshot viewer widgets
        self["shot_dim"] = Pixmap()
        self["shot_full"] = Pixmap()
        self["shot_counter"] = Label("")
        self.viewer_visible = False
        self.viewer_idx = 0
        self.shots_first = 0
        self.shots_refresh_left = 0
        self.shots_timer = eTimer() if HAS_E2 else None
        if self.shots_timer:
            self.shots_timer.callback.append(self._on_shots_timer)

        # Account menu widgets
        self["acc_card"] = Pixmap()
        self["acc_focus"] = Pixmap()
        self["acc_avatar"] = Pixmap()
        self["acc_name"] = Label("")
        self["acc_sub"] = Label("")
        for i in range(ACC_MAX_ITEMS):
            self["acc_icon%d" % i] = Pixmap()
            self["acc_lbl%d" % i] = Label("")
        self.menu_visible = False
        self.menu_idx = 0
        self.menu_page = "main"
        self.menu_groups = acc_menu_groups("main", account.is_logged_in())

        # Phone pairing panel
        for n in ("pair_dim", "pair_box", "pair_qr"):
            self[n] = Pixmap()
        for n in ("pair_title", "pair_text", "pair_code", "pair_status"):
            self[n] = Label("")
        self.pair_visible = False
        self.pair_data = None
        self.pair_expired = False
        self.pair_timer = eTimer() if HAS_E2 else None
        if self.pair_timer:
            self.pair_timer.callback.append(self._pair_poll_tick)

        # Download counts & ratings (cached locally, refreshed from the server)
        self.stats, _age = account.cached_stats()
        self.my_ratings = account.cached_my_ratings()
        self.works_cache = {}
        self._works_asked_this_session = False
        self._apply_hidden()

        # Background network calls -> results delivered on the UI thread
        self._async_results = []
        self._async_pending = 0
        self._async_lock = threading.Lock()
        self.async_timer = eTimer() if HAS_E2 else None
        if self.async_timer:
            self.async_timer.callback.append(self._async_dispatch)

        # Toast notification widgets
        self["toast_bg"] = Pixmap()
        self["toast_text"] = Label("")

        # Dialog and Toast state
        self.dialog_visible = False
        self.dialog_data = None
        self.dialog_focus = "ok"
        self.toast_timer = eTimer() if HAS_E2 else None
        if self.toast_timer:
            self.toast_timer.callback.append(self._hide_toast)

        # State management
        self.view_state = "home" # "home", "cats", or "details"
        self.history_stack = []
        self.scroll_y = 0
        self.max_scroll_y = 0
        self.row_scrolls = {} # row_id -> horizontal scroll offset
        self.focused_idx = 0
        self.current_elements = []
        self.details_item = None

        # Categories state (Part C)
        self.cats_selected_cat = "all"
        self.cats_selected_subcode = "all"
        self.cats_focused_level = "rows" # "tabs", "chips", "subchips", "rows"
        self.cats_focused_chip_idx = 0
        self.cats_focused_subchip_idx = 0
        self.cats_focused_row_idx = 0
        self.cats_chips_scroll_x = 0
        self.cats_subchips_scroll_x = 0
        self.cats_list_scroll_y = 0
        self.top_bar_focus = "tab_cats" # "tab_home", "tab_cats", "tab_mine", "search_pill"
        self.cats_filtered_items = []
        self.search_query = ""
        self.search_results = []
        self.search_focused_row_idx = 0
        self.search_list_scroll_y = 0
        self.list_mode = "search"  # "search" | "updates" (both use the list view)

        # Update-all queue
        self.update_queue = []
        self.update_queue_total = 0
        self.update_queue_restart = False
        self.queue_timer = eTimer() if HAS_E2 else None
        if self.queue_timer:
            self.queue_timer.callback.append(self._run_next_update)

        # Installer integration & Per-Item Log Tracking
        self.installer_job = None
        self.last_logs_by_item = {}

        # Action map with Channel +/- and Page Up/Down support (C5)
        self["actions"] = ActionMap(
            [
                "OkCancelActions",
                "ColorActions",
                "DirectionActions",
                "NavigationActions",
                "ChannelSelectBaseActions",
                "InfobarChannelSelection",
            ],
            {
                "cancel": self.key_cancel,
                "red": self.key_red,
                "green": self.key_green,
                "yellow": self.key_yellow,
                "blue": self.key_blue,
                "ok": self.key_ok,
                "left": self.key_right if MIRROR else self.key_left,
                "right": self.key_left if MIRROR else self.key_right,
                "up": self.key_up,
                "down": self.key_down,
                "pageUp": self.key_page_up,
                "pageDown": self.key_page_down,
                "prevPage": self.key_page_up,
                "nextPage": self.key_page_down,
                "channelUp": self.key_page_up,
                "channelDown": self.key_page_down,
            },
            -1,
        )

        self.onLayoutFinish.append(self._on_layout_finish)

    def _on_layout_finish(self):
        self["top_logo"].setPixmap(get_cached_pixmap(img_path("logo.png")))
        self["tab_line"].setPixmap(get_cached_pixmap(img_path("tab_line_green.png")))
        self["search_pill"].setPixmap(get_cached_pixmap(img_path("search_pill.png")))
        self["search_icon"].setPixmap(get_cached_pixmap(img_path("search_icon.png")))
        self["avatar"].setPixmap(get_cached_pixmap(get_avatar_pixmap(42)))
        self._bell_ready = True
        self._refresh_bell()

        self["dot_red"].setPixmap(get_cached_pixmap(img_path("dot_red.png")))
        self["dot_green"].setPixmap(get_cached_pixmap(img_path("dot_green.png")))
        self["dot_yellow"].setPixmap(get_cached_pixmap(img_path("dot_yellow.png")))
        self["dot_blue"].setPixmap(get_cached_pixmap(img_path("dot_blue.png")))

        self["dlg_overlay"].setPixmap(get_cached_pixmap(img_path("dim_overlay.png")))
        self["dlg_btn_ok"].setPixmap(get_cached_pixmap(img_path("btn_dlg_green.png")))
        self["dlg_btn_cancel"].setPixmap(get_cached_pixmap(img_path("btn_dlg_outline.png")))
        self["dlg_focus_ring"].setPixmap(get_cached_pixmap(img_path("focus_dlg_btn.png")))

        self._hide_dialog_widgets()
        self._hide_acc_menu_widgets()
        self._hide_pair_widgets()
        self._hide_viewer_widgets()
        self._hide_toast()
        self._check_startup_recovery()
        if getattr(self.catalog, "is_offline", False):
            msg = getattr(self.catalog, "offline_message", "") or _("تعذر الاتصال بالإنترنت. تم استخدام النسخة المخزنة مؤقتاً.")
            self.show_toast(msg)
        self.render_ui()
        if self.view_state == "home" and not self.current_elements:
            self._focus_top_bar("tab_home")
        self._check_pending_update_queue()
        self._refresh_stats()
        self._refresh_avatar()
        self._run_async(account.ping_daily, lambda ok, v: None)
        if getattr(self.catalog, "needs_refresh", False):
            self.catalog.needs_refresh = False
            self._run_async(ep_catalog.fetch_remote_index, self._on_background_index)
        if account.is_logged_in() and settings.get("auto_sync"):
            self.backup_settings()
        try:
            from . import remote
            remote.poke()                    # pick up anything sent from the phone
        except Exception:
            pass
        try:
            from . import announcements
            announcements.poke()             # messages from the store
        except Exception:
            pass
        if self.start_view == "updates" and not self.dialog_visible:
            self.open_updates()

    # ---- download counts & ratings ----
    def _refresh_stats(self, force=False):
        flag = "/etc/enigma2/enigmaplay/installs_reported"
        if not os.path.exists(flag):
            # first run of this version: count plugins installed earlier from the store (once)
            ids = []
            for it in self.catalog.items:
                try:
                    if installer.get_item_state(it)[0] != "none":
                        ids.append(it.key)
                except Exception:
                    continue

            def report_all(ids):
                for k in ids:
                    account.report_install(k)
                try:
                    open(flag, "w").close()
                except Exception:
                    pass
                return account.fetch_stats()
            self._run_async(report_all, self._on_stats, ids)
            return
        _st, age = account.cached_stats()
        if force or age is None or age > account.STATS_TTL:
            self._run_async(account.fetch_stats, self._on_stats)

    def _on_stats(self, ok, val):
        if not ok or not isinstance(val, dict):
            return
        self.stats = val
        self.my_ratings = account.cached_my_ratings()
        self._apply_hidden()
        self._maybe_ask_works()
        if self.view_state in ("home", "details") and not self.dialog_visible \
                and not getattr(self, "menu_visible", False) and not getattr(self, "viewer_visible", False) \
                and not getattr(self, "pair_visible", False):
            self.render_ui()

    def _apply_hidden(self):
        """Hide plugins the store flagged (crash a lot / most users say they do not work),
        except the ones installed on this box."""
        try:
            keep = list(installer.load_installed_registry().keys())
        except Exception:
            keep = []
        ep_catalog.set_hidden(account.cached_hidden(), keep)

    # ---- "works on my image": ask once, some time after an install
    def _maybe_ask_works(self):
        if self._works_asked_this_session or self.view_state != "home" or self.dialog_visible \
                or getattr(self, "menu_visible", False) or getattr(self, "pair_visible", False) \
                or getattr(self, "viewer_visible", False) or self.installer_job or self.update_queue:
            return
        nxt = account.works_next()
        if not nxt:
            return
        key, version = nxt
        item = next((it for it in self.catalog.items if it.key == key), None)
        try:
            still = item is not None and installer.get_item_state(item)[0] != "none"
        except Exception:
            still = False
        if not still:
            account.works_done(key)
            return
        self._works_asked_this_session = True
        fam = account.image_family()

        def answer(works):
            account.works_done(key)
            self.works_cache.pop(key, None)
            self._run_async(account.report_works, lambda ok, v: None, key, works, version)
            self.show_toast(_("شكراً! رأيك يساعد غيرك"))
            self.render_ui()

        def skip():
            account.works_done(key)
            self.render_ui()
        self.show_dialog(
            _("هل يعمل %s عندك؟") % one_line(item.name, 300, 22),
            _("ثبّتّه قبل فترة على صورة %s. جوابك يظهر لغيرك قبل التثبيت.") % fam,
            ok_label=_("يعمل"), on_ok=lambda: answer(True),
            cancel_label=_("لا يعمل"), on_cancel=lambda: answer(False), on_back=skip)

    def _load_works(self, item):
        key = item.key
        if key in self.works_cache:
            return

        def done(ok, val):
            self.works_cache[key] = val if ok and isinstance(val, dict) else {}
            if self.view_state == "details" and self.details_item is not None and self.details_item.key == key \
                    and not self.dialog_visible:
                self.render_ui()
        self.works_cache[key] = None            # loading
        self._run_async(account.fetch_works, done, key)

    def _works_line(self, item):
        """'يعمل على 92% من أجهزة openatv (25 رأي)' or None when there are too few answers."""
        w = self.works_cache.get(item.key) or {}
        imgs = w.get("images") or {}
        fam = account.image_family()
        mine = imgs.get(fam) or {}
        n = (mine.get("yes", 0) + mine.get("no", 0))
        if n >= 3:
            return _("يعمل على %d%% من أجهزة %s (%d رأي)") % (int(round(100.0 * mine.get("yes", 0) / n)), fam, n), \
                100.0 * mine.get("yes", 0) / n
        tot = w.get("total") or {}
        n = tot.get("yes", 0) + tot.get("no", 0)
        if n >= 3:
            return _("يعمل عند %d%% من المستخدمين (%d رأي)") % (int(round(100.0 * tot.get("yes", 0) / n)), n), \
                100.0 * tot.get("yes", 0) / n
        # no answers yet: how many receivers installed it (server counts installs per image family)
        inst = w.get("installed") or {}
        n = int(inst.get(fam, 0) or 0)
        if n >= 3:
            return _("مثبّت على %s رسيفر بصورة %s") % (format_count(n), fam), 100.0
        n = sum(int(v or 0) for v in inst.values())
        if n >= 3:
            return _("مثبّت على %s رسيفر") % format_count(n), 100.0
        return None

    def _stat(self, item):
        return self.stats.get(item.key, {}) if item else {}

    def popular_items(self, n=12):
        ranked = [(self._stat(it).get("installs", 0), it) for it in self.catalog.items if ep_catalog._is_visible(it)]
        ranked = [(c, it) for c, it in ranked if c > 0]
        ranked.sort(key=lambda x: -x[0])
        return [it for c, it in ranked[:n]]

    def trending_items(self, n=12):
        """Most installs in the last 7 days (server field "week", recomputed hourly)."""
        ranked = [(self._stat(it).get("week", 0), it) for it in self.catalog.items if ep_catalog._is_visible(it)]
        ranked = [(c, it) for c, it in ranked if c > 0]
        ranked.sort(key=lambda x: -x[0])
        return [it for c, it in ranked[:n]]

    def _rate_item(self, item, stars):
        if not account.is_logged_in():
            self.show_dialog(_("تسجيل الدخول"), _("سجّل الدخول بحسابك لتقييم البلجنات."),
                             ok_label=_("تسجيل الدخول"), on_ok=lambda: self.open_acc_menu("login"))
            return

        def done(ok, val):
            if ok:
                st = self.stats.setdefault(item.key, {"installs": 0})
                st["rating"] = val.get("rating", 0)
                st["votes"] = val.get("votes", 0)
                self.my_ratings[item.key] = stars
                self.show_toast(_("شكراً! تم حفظ تقييمك (%d من 5)") % stars)
            else:
                self.show_toast(self._err_text(val))
            self.render_ui()
        self.show_toast(_("جاري حفظ التقييم…"))
        self._run_async(account.rate, done, item.key, stars)

    def _check_startup_recovery(self):
        try:
            pending = installer.load_pending()
            if not pending:
                return
            item_id = pending.get("id")
            item_name = pending.get("name", item_id)
            rc_path = pending.get("rc_path")
            pid = pending.get("pid", 0)

            if rc_path and os.path.exists(rc_path):
                try:
                    with open(rc_path, "r", encoding="utf-8") as f:
                        rc = int(f.read().strip())
                except Exception:
                    rc = -1
                if rc == 0:
                    installer.save_installed_record(item_id, item_name, pending.get("version", ""), rc=0)
                    installer.clear_pending()
                    self.show_toast(_("تم تثبيت %s") % item_name)
                else:
                    installer.clear_pending()
                    self.show_toast(_("فشل تثبيت %s") % item_name)
                return

            script_path = pending.get("script_path", "")
            expected_sha = pending.get("sha256")
            if expected_sha and script_path and os.path.exists(script_path):
                cur_sha = installer.calc_file_sha256(script_path)
                if cur_sha != expected_sha:
                    installer.log_security_event("RECOVERY_TAMPERING", "Pending script hash altered for %s: got %s, expected %s" % (item_id, cur_sha, expected_sha))
                    installer.clear_pending()
                    self.show_toast(_("فشل أمني: تم رصد تعديل على السكربت المعلق."))
                    return

            is_running = False
            if pid > 0 and installer.is_pid_alive(pid):
                is_running = True
            elif script_path:
                try:
                    import subprocess
                    res = subprocess.run(["pgrep", "-f", script_path], stdout=subprocess.PIPE)
                    if res.returncode == 0 and res.stdout.strip():
                        is_running = True
                except Exception:
                    pass

            if is_running:
                for it in self.catalog.items:
                    if it.key == item_id:
                        self.open_details(it)
                        self.installer_job = installer.InstallJob(
                            it,
                            on_log_update=self._on_installer_log,
                            on_finish=self._on_installer_finish,
                            on_unverified=self._on_unverified_script
                        )
                        self.installer_job.phase = "install"
                        self.installer_job.script_path = script_path
                        self.installer_job.log_path = pending.get("log_path")
                        self.installer_job.rc_path = rc_path
                        self.installer_job._start_polling()
                        return
            else:
                installer.clear_pending()
                self.show_toast(_("فشل تثبيت %s") % item_name)
        except Exception as e:
            installer.log_debug("Startup recovery error: %s" % e)

    def _hide_dialog_widgets(self):
        self["dlg_overlay"].hide()
        self["dlg_box"].hide()
        self["dlg_title"].hide()
        self["dlg_text"].hide()
        self["dlg_btn_ok"].hide()
        self["dlg_lbl_ok"].hide()
        self["dlg_btn_cancel"].hide()
        self["dlg_lbl_cancel"].hide()
        self["dlg_focus_ring"].hide()

    # -----------------------------------------------------------------------
    # ACCOUNT MENU
    # -----------------------------------------------------------------------
    def _hide_acc_menu_widgets(self):
        for n in ("acc_card", "acc_focus", "acc_avatar", "acc_name", "acc_sub"):
            self[n].hide()
        for i in range(ACC_MAX_ITEMS):
            self["acc_icon%d" % i].hide()
            self["acc_lbl%d" % i].hide()

    def _menu_items(self):
        return [it for grp in self.menu_groups for it in grp]

    # -----------------------------------------------------------------------
    # NOTIFICATIONS (bell in the top bar, like Google Play: updates + store messages)
    # -----------------------------------------------------------------------
    def _count_updates(self):
        try:
            return len(self.get_available_updates())
        except Exception:
            return 0

    def _refresh_bell(self):
        if not getattr(self, "_bell_ready", False):
            return
        try:
            from . import announcements
            unread = announcements.unread_count()
        except Exception:
            unread = 0
        self.updates_count = self._count_updates()
        n = self.updates_count + unread
        if n != self.bell_count:
            self.bell_count = n
            try:
                self["bell"].setPixmap(get_cached_pixmap(get_bell_pixmap(n)))
                self["bell"].show()
            except Exception:
                pass

    def _notif_groups(self):
        n = self._count_updates()
        self.updates_count = n
        if n:
            g1 = [("notif_updates", _("تحديثات متوفرة (%d)") % n, "updates"),
                  ("notif_update_all", _("تحديث الكل"), "refresh")]
            # one line per update: opens "what's new" before updating.
            # The menu must fit the screen: at most 11 rows in total with the messages below.
            try:
                from . import announcements as _ann
                n_msgs = min(6, len(_ann.history()))
            except Exception:
                n_msgs = 0
            for it in self.get_available_updates()[:max(0, min(5, 9 - n_msgs))]:
                nm = it.name if len(it.name) <= 24 else it.name[:23] + "…"
                g1.append(("upd:" + it.key, _("ما الجديد: %s") % nm, "info"))
        else:
            g1 = [("notif_none", _("كل بلجيناتك محدّثة"), "updates")]
        msgs = []
        try:
            from . import announcements
            for m in announcements.history()[:6]:
                title = (m.get("title") or _("رسالة من المتجر")).strip()
                if len(title) > 30:
                    title = title[:29] + "…"
                msgs.append(("msg:%d" % int(m["id"]), ("● " if not m.get("read") else "") + title, "info"))
        except Exception:
            pass
        groups = [g1]
        if msgs:
            groups.append(msgs)
        return groups

    def _open_message(self, ann_id):
        try:
            from . import announcements
            m = next((x for x in announcements.history() if int(x["id"]) == ann_id), None)
            if not m:
                return
            announcements.mark_read(ann_id)
            self._refresh_bell()

            def done(answer=None):
                if answer and m.get("level") == "update":
                    self.open_updates()
            self.session.openWithCallback(done, announcements.AnnouncementBox,
                                          m.get("title", ""), m.get("body", ""), m.get("level", "info"))
        except Exception as e:
            installer.log_debug("open message failed: %r" % e)

    def _changelog_lines(self, item, limit=5):
        out = []
        for entry in (getattr(item, "changelog", None) or [])[:limit]:
            if isinstance(entry, dict):
                head = " · ".join(x for x in (str(entry.get("version") or "").strip(), str(entry.get("date") or "").strip()) if x)
                text = str(entry.get("text") or "").strip()
            elif isinstance(entry, (list, tuple)):
                head = " · ".join(str(x).strip() for x in entry[:2] if x)
                text = " ".join(str(x).strip() for x in entry[2:] if x)
            else:
                head, text = "", str(entry).strip()
            if len(text) > 150:
                text = text[:149] + "…"
            line = (head + ": " + text) if (head and text) else (text or head)
            if line:
                out.append("- " + line)
        return out

    def _open_whats_new(self, key):
        """Bell -> one update: show its changelog, OK = update just this plugin."""
        item = next((it for it in self.catalog.items if it.key == key), None)
        if not item:
            return
        try:
            inst_v = installer.get_item_state(item)[1] or ""
        except Exception:
            inst_v = ""
        lines = self._changelog_lines(item)
        body = _("الإصدار المثبّت: %s\nالإصدار الجديد: %s") % (inst_v or "—", item.version or "—")
        body += "\n\n" + ("\n".join(lines) if lines else _("المطوّر لم يكتب ملاحظات لهذا الإصدار."))
        try:
            from . import announcements
        except Exception:
            return

        def done(answer=None):
            if not answer:
                return
            if self.installer_job or self.update_queue:
                self.show_toast(_("يوجد تثبيت قيد التنفيذ"))
                return
            self._start_update_queue([item.key])
        self.session.openWithCallback(done, announcements.AnnouncementBox,
                                      _("ما الجديد في %s") % item.name, body, "update", _("تحديث الآن"))

    # ---- install this plugin on the account's other receivers
    def _install_on_other_boxes(self, item):
        if not account.is_logged_in():
            self.show_dialog(_("تسجيل الدخول"), _("سجّل الدخول بحسابك لترى رسيفراتك الأخرى وتثبّت عليها."),
                             ok_label=_("تسجيل الدخول"), on_ok=lambda: self.open_acc_menu("login"))
            return

        def got(ok, boxes):
            if not ok:
                self.show_toast(self._err_text(boxes))
                return
            if not boxes:
                self.show_dialog(_("لا يوجد رسيفر آخر"),
                                 _("سجّل الدخول بنفس الحساب (%s) على الرسيفر الثاني، وبعدها يظهر هنا.") % account.username())
                return
            self.boxes_for = item
            self.boxes_list = boxes[:8]
            self.open_acc_menu("boxes")
        self.show_toast(_("جاري تحميل أجهزتك…"))
        self._run_async(account.other_boxes, got)

    def _boxes_groups(self):
        rows = []
        bl = getattr(self, "boxes_list", []) or []
        for b in bl:
            seen = time.time() - (b.get("last_seen") or 0)
            state = _("متصل الآن") if seen < 900 else _("غير متصل")
            rows.append(("box:" + b["id"], _("رسيفر %s  ·  %s") % ((b.get("model") or "?").upper(), state), "sync"))
        groups = []
        if len(bl) > 1:
            groups.append([("box:all", _("كل أجهزتي (%d)") % len(bl), "updates")])
        groups.append(rows)
        return groups

    def _boxes_choose(self, aid):
        item = getattr(self, "boxes_for", None)
        bl = getattr(self, "boxes_list", []) or []
        ids = [b["id"] for b in bl] if aid == "box:all" else [aid[4:]]
        if not item or not ids:
            return

        def done(ok, val):
            sent, err = (val if ok else (0, self._err_text(val)))
            if sent:
                self.show_toast(_("تم الإرسال إلى %d رسيفر، يبدأ التثبيت خلال ثوانٍ") % sent)
            else:
                self.show_toast(err or _("تعذر الإرسال"))
        self._run_async(account.remote_install, done, ids, item.key)

    def open_acc_menu(self, page="main"):
        self.menu_visible = True
        self.menu_page = page
        if page == "boxes":
            self.menu_groups = self._boxes_groups()
        else:
            self.menu_groups = self._notif_groups() if page == "notif" else acc_menu_groups(page, account.is_logged_in())
        self.menu_idx = 0
        self._hide_acc_menu_widgets()
        self._render_acc_menu(full=True)

    def close_acc_menu(self):
        self.menu_visible = False
        self._hide_acc_menu_widgets()
        if getattr(self, "menu_page", "") == "boxes":
            self._update_focus_ring()           # back to the plugin page
            return
        self._focus_top_bar("bell" if getattr(self, "menu_page", "") == "notif" else "avatar")

    def _render_acc_menu(self, full=False):
        mx, my = ACC_MENU_X, ACC_MENU_Y
        if self.menu_page == "notif":
            mx = BELL_X + BELL_SZ - ACC_MENU_W + 20       # drops down under the bell
        mw = 540 if self.menu_page == "settings" else ACC_MENU_W
        items, _divs, total_h = acc_menu_layout(self.menu_groups)
        if full:
            card_path, _sz = get_acc_menu_card_pixmap(self.menu_groups, mw)
            sh = ACC_SHADOW
            self["acc_card"].setPixmap(get_cached_pixmap(card_path))
            place(self["acc_card"], px(mx - sh), px(my - sh), px(mw + sh * 2), px(total_h + sh * 2))
            self["acc_card"].show()

            av = 48
            av_x = mx + mw - 20 - av
            av_path = get_bell_pixmap(0, 42) if self.menu_page == "notif" else get_avatar_pixmap(42)
            self["acc_avatar"].setPixmap(get_cached_pixmap(av_path))
            place(self["acc_avatar"], px(av_x + 3), px(my + 22 + 3), px(42), px(42))
            self["acc_avatar"].show()

            dev_title, dev_sub = get_device_summary()
            if self.menu_page == "about":
                title = _("حول EnigmaPlay")
                sub = _("الإصدار %s") % getattr(self, "about_version", "")
            elif self.menu_page == "boxes":
                title = _("التثبيت على أجهزة أخرى")
                sub = getattr(getattr(self, "boxes_for", None), "name", "")
            elif self.menu_page == "notif":
                n = getattr(self, "updates_count", 0)
                title = _("الإشعارات")
                sub = (_("%d تحديث متوفر") % n) if n else _("لا توجد تحديثات جديدة")
            elif self.menu_page == "login":
                title, sub = _("تسجيل الدخول"), _("احفظ بلجيناتك واستعدها على أي صورة")
            elif self.menu_page == "settings":
                title, sub = _("الإعدادات"), _("OK لتغيير القيمة")
            elif account.is_logged_in():
                title, sub = account.username(), _("متصل  ·  %s") % dev_title
            else:
                title, sub = dev_title, _("غير مسجّل الدخول")
            tx = mx + 20
            tw = av_x - 12 - tx
            self["acc_name"].setText(title)
            place(self["acc_name"], px(tx), px(my + 20), px(tw), px(28))
            self["acc_name"].show()
            self["acc_sub"].setText(sub)
            place(self["acc_sub"], px(tx), px(my + 50), px(tw), px(22))
            self["acc_sub"].show()

        icon_sz = 24
        for i, ((aid, alabel, aicon), iy) in enumerate(items[:ACC_MAX_ITEMS]):
            y = my + iy
            ix = mx + mw - 24 - icon_sz
            focused = (i == self.menu_idx)
            if full:
                self["acc_icon%d" % i].setPixmap(get_cached_pixmap(img_path("menu_%s.png" % aicon)))
                place(self["acc_icon%d" % i], px(ix), px(y + (ACC_ITEM_H - icon_sz) // 2), px(icon_sz), px(icon_sz))
                self["acc_icon%d" % i].show()
                place(self["acc_lbl%d" % i], px(mx + 24), px(y), px(ix - 16 - (mx + 24)), px(ACC_ITEM_H))
                self["acc_lbl%d" % i].show()
            lbl = self["acc_lbl%d" % i].instance
            lbl.setForegroundColor(parseColor("#01875f" if focused else C("#202124")))
            lbl.setFont(gFont("TajawalBold" if focused else "TajawalRegular", px(18)))
            if focused:
                fw, fh = mw - 16, ACC_ITEM_H - 4
                self["acc_focus"].setPixmap(get_cached_pixmap(get_acc_focus_pixmap(fw, fh)))
                place(self["acc_focus"], px(mx + 8), px(y + 2), px(fw), px(fh))
                self["acc_focus"].show()
            self["acc_lbl%d" % i].setText(alabel)

    def _acc_menu_key(self, key):
        items = self._menu_items()
        n = len(items)
        if key == "up":
            self.menu_idx = (self.menu_idx - 1) % n
            self._render_acc_menu()
        elif key == "down":
            self.menu_idx = (self.menu_idx + 1) % n
            self._render_acc_menu()
        elif key == "ok":
            self._acc_menu_action(items[self.menu_idx][0])
        elif key in ("left", "right") and self.menu_page == "settings":
            aid = items[self.menu_idx][0]
            if aid.startswith("set:"):
                phys = {"left": "right", "right": "left"}[key] if MIRROR else key
                self._change_setting(aid[4:], 1 if phys == "right" else -1)
        elif key == "cancel":
            if self.menu_page == "settings" and self._leave_settings():
                return
            if self.menu_page in ("login", "settings", "about"):
                self.open_acc_menu("main")
            else:
                self.close_acc_menu()

    def _change_setting(self, key, step=1):
        settings.cycle(key, step)
        keep = self.menu_idx
        self.menu_groups = acc_menu_groups("settings", account.is_logged_in())
        self.menu_idx = keep
        self._render_acc_menu(full=True)
        if key == "show_incompatible":
            self._reload_from_cache()
        elif key in ("theme", "language"):
            # restart is asked once, when leaving the settings page
            self.restart_pending = True

    def _leave_settings(self):
        """If language/theme changed, ask for the GUI restart. True when the dialog was shown."""
        if not getattr(self, "restart_pending", False):
            return False
        self.restart_pending = False
        self.close_acc_menu()
        self.show_dialog(_("إعادة تشغيل الواجهة"),
                         _("يلزم إعادة تشغيل الواجهة لتطبيق التغيير. إعادة التشغيل الآن؟"),
                         ok_label=_("إعادة التشغيل الآن"), on_ok=self._do_restart_gui)
        return True

    def _acc_menu_action(self, aid):
        if self.menu_page == "boxes":
            self.close_acc_menu()
            if aid.startswith("box:"):
                self._boxes_choose(aid)
            return
        if self.menu_page == "notif":
            if aid == "notif_none":
                return
            self.close_acc_menu()
            if aid == "notif_updates":
                self.open_updates()
            elif aid == "notif_update_all":
                self.update_all()
            elif aid.startswith("msg:"):
                self._open_message(int(aid[4:]))
            elif aid.startswith("upd:"):
                self._open_whats_new(aid[4:])
            return
        if aid == "exit":
            self.close()
            return
        if aid == "login":
            self.open_acc_menu("login")
            return
        if aid.startswith("legal:"):
            try:
                from . import announcements
                self.session.open(announcements.LegalBox, aid[6:])
            except Exception as e:
                installer.log_debug("legal box failed: %r" % e)
            return
        if aid == "back":
            if self.menu_page == "settings" and self._leave_settings():
                return
            self.open_acc_menu("main")
            return
        if aid == "settings":
            self.open_acc_menu("settings")
            return
        if aid.startswith("set:"):
            self._change_setting(aid[4:], 1)
            return
        if aid == "clear_cache" and self.menu_page == "settings":
            self._clear_cache()
            return
        self.close_acc_menu()
        if aid == "reload":
            self._reload_catalog()
        elif aid == "clear_cache":
            self._clear_cache()
        elif aid == "about":
            try:
                from . import __version__ as ep_ver
            except Exception:
                ep_ver = "1.0.0"
            self.about_version = ep_ver
            self.open_acc_menu("about")
        elif aid == "mine":
            self.open_mine()
        elif aid == "history":
            self.open_history()
        elif aid == "updates":
            self.open_updates()
        elif aid == "pair":
            self.open_pairing()
        elif aid == "userpass":
            self._ask_credentials(register=False)
        elif aid == "register":
            self._ask_credentials(register=True)
        elif aid == "forgot":
            self._forgot_password()
        elif aid == "restore":
            self.restore_plugins()
        elif aid == "sync":
            self.sync_all_plugins(announce=True)
        elif aid == "logout":
            self.show_dialog(_("تسجيل الخروج"), _("هل تريد تسجيل الخروج من حساب %s على هذا الجهاز؟") % account.username(),
                             ok_label=_("تسجيل الخروج"), on_ok=self._do_logout)

    # -----------------------------------------------------------------------
    # BACKGROUND CALLS (network never blocks the remote control)
    # -----------------------------------------------------------------------
    def _run_async(self, fn, callback, *args):
        def worker():
            try:
                res = (True, fn(*args))
            except Exception as e:
                res = (False, e)
            with self._async_lock:
                self._async_results.append((callback, res))
        self._async_pending += 1
        t = threading.Thread(target=worker)
        t.daemon = True
        t.start()
        if self.async_timer and not self.async_timer.isActive():
            self.async_timer.start(150, False)

    def _async_dispatch(self):
        with self._async_lock:
            ready, self._async_results = self._async_results, []
        for cb, (ok, val) in ready:
            self._async_pending -= 1
            try:
                cb(ok, val)
            except Exception as e:
                installer.log_debug("async callback error: %s" % e)
        if self._async_pending <= 0 and self.async_timer:
            self._async_pending = 0
            self.async_timer.stop()

    API_ERRORS = {
        "bad_credentials": "اسم المستخدم أو كلمة المرور غير صحيحة",
        "exists": "اسم المستخدم مستخدم مسبقاً",
        "invalid": "اسم المستخدم 3-32 حرفاً إنجليزياً أو رقماً، وكلمة المرور 6 أحرف على الأقل",
        "rate_limited": "محاولات كثيرة، حاول بعد 15 دقيقة",
        "unauthorized": "انتهت الجلسة، سجّل الدخول من جديد",
        "bad_code": "الرمز غير صحيح أو انتهت صلاحيته",
        "box_not_linked": "هذا الرسيفر غير مربوط بحساب. استعادة كلمة المرور تعمل فقط على الرسيفر الذي سجّلت الدخول عليه من قبل.",
    }

    @staticmethod
    def _err_text(e):
        if isinstance(e, account.ApiError):
            local = EnigmaPlayScreen.API_ERRORS.get(e.code)
            return _(local) if local else e.message
        return _("تعذر الاتصال بالخادم. تأكد من اتصال الجهاز بالإنترنت.")

    # -----------------------------------------------------------------------
    # LOGIN (username / password with the on-screen keyboard)
    # -----------------------------------------------------------------------
    def _ask_credentials(self, register=False):
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
        except Exception:
            self.show_toast(_("تعذر فتح لوحة المفاتيح"))
            return
        title_user = _("اسم المستخدم الجديد (حروف إنجليزية وأرقام)") if register else _("اسم المستخدم")

        def got_user(user):
            if not user or not user.strip():
                return
            user = user.strip()
            self.session.openWithCallback(lambda pw: got_pass(user, pw), VirtualKeyBoard,
                                          title=_("كلمة المرور (6 أحرف على الأقل)") if register else _("كلمة المرور"), text="")

        def got_pass(user, pw):
            if not pw:
                return
            self.show_toast(_("جاري إنشاء الحساب…") if register else _("جاري تسجيل الدخول…"))
            fn = account.register if register else account.login
            self._run_async(fn, self._on_login_result, user, pw)

        self.session.openWithCallback(got_user, VirtualKeyBoard, title=title_user, text="")

    def _forgot_password(self):
        """New password set from this receiver (it holds the key of the account it is bound to)."""
        if not account.has_box_key():
            self.show_dialog(_("نسيت كلمة المرور"),
                             _("هذا الرسيفر غير مربوط بحساب بعد.\nاستعادة كلمة المرور تعمل فقط على الرسيفر الذي سجّلت الدخول عليه بحسابك من قبل."),
                             ok_label=_("موافق"))
            return
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
        except Exception:
            self.show_toast(_("تعذر فتح لوحة المفاتيح"))
            return

        def got_first(pw):
            if not pw:
                return
            if len(pw) < 8:
                self.show_dialog(_("نسيت كلمة المرور"), _("كلمة المرور يجب أن تكون 8 أحرف على الأقل"), ok_label=_("موافق"))
                return
            self.session.openWithCallback(lambda pw2: got_second(pw, pw2), VirtualKeyBoard,
                                          title=_("أعد كتابة كلمة المرور الجديدة"), text="")

        def got_second(pw, pw2):
            if pw2 is None:
                return
            if pw != pw2:
                self.show_dialog(_("نسيت كلمة المرور"), _("كلمتا المرور غير متطابقتين"), ok_label=_("موافق"))
                return
            self.show_toast(_("جاري تغيير كلمة المرور…"))
            self._run_async(account.reset_password_from_box, done, pw)

        def done(ok, val):
            if ok:
                self.show_dialog(_("تم تغيير كلمة المرور"),
                                 _("حسابك: %s\nتم تسجيل الخروج من باقي الأجهزة. استخدم كلمة المرور الجديدة من الآن.") % val,
                                 ok_label=_("موافق"))
                self._after_login()
            else:
                self.show_dialog(_("نسيت كلمة المرور"), self._err_text(val), ok_label=_("موافق"))

        self.session.openWithCallback(got_first, VirtualKeyBoard,
                                      title=_("كلمة المرور الجديدة (8 أحرف على الأقل)"), text="")

    def _on_login_result(self, ok, val):
        if ok:
            self.show_toast(_("أهلاً %s، تم تسجيل الدخول") % val)
            self._after_login()
        else:
            self.show_dialog(_("تعذر تسجيل الدخول"), self._err_text(val), ok_label=_("موافق"))

    def _do_logout(self):
        def done(ok, v):
            self.show_toast(_("تم تسجيل الخروج"))
            self._show_avatar()
        self._run_async(account.logout, done)

    def _show_avatar(self):
        try:
            self["avatar"].setPixmap(get_cached_pixmap(get_avatar_pixmap(42)))
        except Exception:
            pass

    def _refresh_avatar(self):
        """Fetch the profile picture in the background; repaint when it changed."""
        if not account.is_logged_in():
            return

        def done(ok, changed):
            if ok and changed:
                self._show_avatar()
                if getattr(self, "menu_visible", False):
                    self._render_acc_menu(full=True)
        self._run_async(account.sync_avatar, done)
        self._run_async(account.ensure_box_key, lambda ok, v: None)     # boxes signed in before 1.2.21

    # -----------------------------------------------------------------------
    # PHONE PAIRING (6-digit code + QR, the box polls until confirmed)
    # -----------------------------------------------------------------------
    PAIR_X, PAIR_Y, PAIR_W, PAIR_H = 240, 130, 800, 460

    def _hide_pair_widgets(self):
        for n in ("pair_dim", "pair_box", "pair_qr", "pair_title", "pair_text", "pair_code", "pair_status"):
            self[n].hide()

    def open_pairing(self):
        self.pair_visible = True
        self.pair_expired = False
        self.pair_data = None
        self["focus_ring"].hide()
        self._render_pair_panel(status=_("جاري إنشاء رمز الربط…"))
        self._run_async(account.pair_start, self._on_pair_started)

    # ---- share a plugin: QR to its page on the web store (reuses the pairing panel widgets)
    def share_link(self, item):
        try:
            from urllib.parse import quote as _q
        except ImportError:
            from urllib import quote as _q
        return "%s/?id=%s" % (account.API_BASE, _q(item.key, safe=""))

    def open_share(self, item):
        self.pair_visible = True
        self.pair_expired = False
        self.pair_data = None
        self.share_item = item
        self.share_qr = None
        self["focus_ring"].hide()
        self._render_share_panel()
        code = "share_" + re.sub(r"[^a-z0-9_-]", "_", item.key.lower())[:60]
        self._run_async(self._fetch_qr, self._on_share_qr, self.share_link(item), code)

    def _on_share_qr(self, ok, path):
        if self.pair_visible and getattr(self, "share_item", None) and ok and path:
            self.share_qr = path
            self._render_share_panel()

    def _render_share_panel(self):
        X, Y, W, H = self.PAIR_X, self.PAIR_Y, self.PAIR_W, self.PAIR_H
        item = self.share_item
        self["pair_dim"].setPixmap(get_cached_pixmap(img_path("dim_overlay.png")))
        place(self["pair_dim"], 0, 0, SCREEN_W, SCREEN_H)
        self["pair_dim"].show()
        self["pair_box"].setPixmap(get_cached_pixmap(get_round_box_pixmap(W, H)))
        place(self["pair_box"], px(X), px(Y), px(W), px(H))
        self["pair_box"].show()
        self["pair_title"].setText(_("شارك %s") % one_line(item.name, W - 120, 26))
        place(self["pair_title"], px(X), px(Y + 22), px(W), px(44))
        self["pair_title"].show()
        qr = getattr(self, "share_qr", None)
        if qr and os.path.exists(qr):
            self["pair_qr"].setPixmap(get_cached_pixmap(qr))
            place(self["pair_qr"], px(X + 40), px(Y + 96), px(240), px(240))
            self["pair_qr"].show()
            tx, tw = X + 310, W - 350
        else:
            self["pair_qr"].hide()
            tx, tw = X + 40, W - 80
        link_txt = self.share_link(item).replace("https://", "")
        self["pair_text"].setText(_("امسح الرمز بكاميرا الجوال لتفتح صفحة البلجن، ثم شاركها مع أصحابك على واتساب أو فيسبوك.\n\nأو افتح على الجوال:\n%s") % link_txt)
        place(self["pair_text"], px(tx), px(Y + 96), px(tw), px(230))
        self["pair_text"].show()
        self["pair_code"].hide()
        self["pair_status"].setText(_("رجوع أو OK للإغلاق"))
        place(self["pair_status"], px(X + 20), px(Y + H - 70), px(W - 40), px(40))
        self["pair_status"].show()

    def close_pairing(self):
        self.share_item = None
        self.pair_visible = False
        self.pair_data = None
        if self.pair_timer:
            self.pair_timer.stop()
        self._hide_pair_widgets()
        self._update_focus_ring()

    def _on_pair_started(self, ok, val):
        if not self.pair_visible:
            return
        if not ok:
            self.pair_expired = True
            self._render_pair_panel(status=self._err_text(val) + _("  —  OK لإعادة المحاولة"))
            return
        val["started"] = time.time()
        self.pair_data = val
        self._render_pair_panel()
        # QR code (optional, rendered by a public QR service; the panel works without it)
        link = "%s?code=%s" % (val.get("link") or account.LINK_URL, val["code"])
        self._run_async(self._fetch_qr, self._on_qr_ready, link, val["code"])
        if self.pair_timer:
            self.pair_timer.start(3000, False)

    @staticmethod
    def _fetch_qr(link, code):
        try:
            from urllib.parse import quote as _q
        except ImportError:
            from urllib import quote as _q
        target = "/tmp/enigmaplay/qr_%s.png" % code
        if not os.path.isdir("/tmp/enigmaplay"):
            os.makedirs("/tmp/enigmaplay")
        size = px(240)
        url = "https://api.qrserver.com/v1/create-qr-code/?size=%dx%d&margin=10&data=%s" % (size, size, _q(link, safe=""))
        try:
            try:
                from urllib.request import urlopen
            except ImportError:
                from urllib2 import urlopen
            data = urlopen(url, timeout=10).read()
        except Exception:
            import subprocess
            data = subprocess.Popen(["curl", "-s", "-k", "-m", "10", url], stdout=subprocess.PIPE).communicate()[0]
        if not data or not data.startswith(b"\x89PNG"):
            return None
        with open(target, "wb") as f:
            f.write(data)
        return target

    def _on_qr_ready(self, ok, path):
        if self.pair_visible and ok and path:
            self.pair_qr_path = path
            self._render_pair_panel()

    def _render_pair_panel(self, status=None):
        X, Y, W, H = self.PAIR_X, self.PAIR_Y, self.PAIR_W, self.PAIR_H
        self["pair_dim"].setPixmap(get_cached_pixmap(img_path("dim_overlay.png")))
        place(self["pair_dim"], 0, 0, SCREEN_W, SCREEN_H)
        self["pair_dim"].show()
        self["pair_box"].setPixmap(get_cached_pixmap(get_round_box_pixmap(W, H)))
        place(self["pair_box"], px(X), px(Y), px(W), px(H))
        self["pair_box"].show()

        self["pair_title"].setText(_("ربط الجهاز بحسابك"))
        place(self["pair_title"], px(X), px(Y + 22), px(W), px(44))
        self["pair_title"].show()

        qr = getattr(self, "pair_qr_path", None) if self.pair_data else None
        if qr and self.pair_data and ("_%s." % self.pair_data["code"]) in qr and os.path.exists(qr):
            self["pair_qr"].setPixmap(get_cached_pixmap(qr))
            place(self["pair_qr"], px(X + 40), px(Y + 96), px(240), px(240))
            self["pair_qr"].show()
            tx, tw = X + 310, W - 350
        else:
            self["pair_qr"].hide()
            tx, tw = X + 40, W - 80

        link_txt = (self.pair_data or {}).get("link") or account.LINK_URL
        link_txt = link_txt.replace("https://", "")
        self["pair_text"].setText(_("١. امسح الرمز بكاميرا الجوال، أو افتح على الجوال:\n%s\n\n٢. اكتب هذا الرمز وسجّل الدخول أو أنشئ حساباً:") % link_txt)
        place(self["pair_text"], px(tx), px(Y + 96), px(tw), px(130))
        self["pair_text"].show()

        code = (self.pair_data or {}).get("code", "")
        self["pair_code"].setText("%s %s" % (code[:3], code[3:]) if code else "— — —")
        place(self["pair_code"], px(tx), px(Y + 236), px(tw), px(90))
        self["pair_code"].show()

        if status is None:
            if self.pair_data:
                left = int(self.pair_data.get("expires_in", 600) - (time.time() - self.pair_data["started"]))
                status = _("بانتظار التأكيد من الجوال…  (%d:%02d)   ·   رجوع للإلغاء") % (max(0, left) // 60, max(0, left) % 60)
            else:
                status = ""
        self["pair_status"].setText(status)
        place(self["pair_status"], px(X + 20), px(Y + H - 70), px(W - 40), px(40))
        self["pair_status"].show()

    def _pair_poll_tick(self):
        if not self.pair_visible or not self.pair_data:
            if self.pair_timer:
                self.pair_timer.stop()
            return
        left = self.pair_data.get("expires_in", 600) - (time.time() - self.pair_data["started"])
        if left <= 0:
            self._pair_expired()
            return
        self._render_pair_panel()
        self._run_async(account.pair_poll, self._on_pair_poll, self.pair_data["poll"])

    def _pair_expired(self):
        if self.pair_timer:
            self.pair_timer.stop()
        self.pair_expired = True
        self._render_pair_panel(status=_("انتهت صلاحية الرمز — اضغط OK لرمز جديد"))

    def _on_pair_poll(self, ok, val):
        if not self.pair_visible or not ok:
            return
        status, user = val
        if status == "done":
            self.close_pairing()
            self.show_toast(_("أهلاً %s، تم ربط الجهاز") % user)
            self._after_login()
        elif status == "expired":
            self._pair_expired()

    def _pair_key(self, key):
        if getattr(self, "share_item", None):
            if key in ("cancel", "ok"):
                self.close_pairing()
            return
        if key in ("cancel",):
            self.close_pairing()
        elif key == "ok" and self.pair_expired:
            self.open_pairing()

    # -----------------------------------------------------------------------
    # SYNC & RESTORE
    # -----------------------------------------------------------------------
    def _installed_for_sync(self):
        out = []
        for it in self.catalog.items:
            st, inst_v = installer.get_item_state(it)
            if st != "none":
                out.append({"id": it.key, "name": it.name, "version": inst_v or it.version or ""})
        return out

    def sync_all_plugins(self, announce=False):
        if not account.is_logged_in():
            return
        items = self._installed_for_sync()

        def done(ok, val):
            if announce:
                if ok:
                    self.show_toast(_("تمت مزامنة %d بلجن مع حسابك") % len(items))
                else:
                    self.show_toast(self._err_text(val))
            if ok:
                self.backup_settings(announce=announce, force=announce)
        self._run_async(account.push_plugins, done, items)

    # ---- plugin settings backup / restore ----
    BACKUP_EVERY = 6 * 3600

    def backup_settings(self, announce=False, force=False):
        """Save the settings of installed store plugins to the account (only what changed)."""
        if not account.is_logged_in():
            return
        st = ep_backup.load_state()
        import time
        if not force and time.time() - st.get("_last", 0) < self.BACKUP_EVERY:
            return
        targets = []
        for it in self.catalog.items:
            try:
                if installer.get_item_state(it)[0] != "none":
                    targets.append((it, installer.find_installed_package(it)[0]))
            except Exception:
                continue

        def work(targets):
            st = ep_backup.load_state()
            saved = 0
            for it, pkg in targets:
                data = ep_backup.collect(it, pkg)
                if not data:
                    continue
                h = ep_backup.digest(data)
                if st.get(it.key) == h and not force:
                    continue
                account.put_backup(it.key, data)
                st[it.key] = h
                saved += 1
            st["_last"] = time.time()
            ep_backup.save_state(st)
            return saved

        def done(ok, val):
            if not announce:
                return
            if ok and val:
                self.show_toast(_("تم حفظ إعدادات %d بلجن بحسابك") % val)
            elif not ok:
                self.show_toast(self._err_text(val))
        self._run_async(work, done, targets)

    def restore_settings(self, ids=None, after_install=False):
        """Download saved settings (for `ids`, or all installed plugins) and apply them."""
        def fetch(ids):
            have = set(b.get("id") for b in account.list_backups())
            out = {}
            for k in (ids if ids is not None else have):
                if k in have:
                    try:
                        out[k] = account.get_backup(k)
                    except Exception:
                        continue
            return out

        def done(ok, val):
            n = 0
            if ok:
                for k, data in (val or {}).items():
                    try:
                        if data and ep_backup.apply(data):
                            n += 1
                    except Exception as e:
                        installer.log_debug("restore settings %s failed: %s" % (k, e))
            if n:
                self.show_toast(_("تمت استعادة إعدادات %d بلجن") % n)
                self._maybe_restart(_("يلزم إعادة تشغيل الواجهة لتطبيق الإعدادات المستعادة. إعادة التشغيل الآن؟"))
            elif after_install and getattr(self, "restore_needs_restart", False):
                self._maybe_restart(_("اكتملت العملية. يلزم إعادة تشغيل الواجهة لتفعيل التغييرات. إعادة التشغيل الآن؟"))
            elif not ok:
                self.show_toast(self._err_text(val))
        self._run_async(fetch, done, ids)

    def _offer_settings_restore(self):
        """All saved plugins are installed: offer to bring back their saved settings."""
        installed = set(it.key for it in self.catalog.items if installer.get_item_state(it)[0] != "none")

        def done(ok, val):
            if not ok:
                self.show_toast(self._err_text(val))
                return
            ids = [b.get("id") for b in val or [] if b.get("id") in installed]
            if not ids:
                self.show_toast(_("كل بلجيناتك المحفوظة مثبتة على هذا الجهاز"))
                return
            self.show_dialog(_("استعادة الإعدادات"),
                             _("كل بلجيناتك مثبتة. عندك إعدادات محفوظة لـ %d بلجن، استعادتها الآن؟") % len(ids),
                             ok_label=_("استعادة الإعدادات"), on_ok=lambda: self.restore_settings(ids))
        self._run_async(account.list_backups, done)

    def _sync_one(self, item):
        if not account.is_logged_in() or not settings.get("auto_sync"):
            return
        st, inst_v = installer.get_item_state(item)
        entry = [{"id": item.key, "name": item.name, "version": inst_v or item.version or ""}]
        self._run_async(account.push_plugins, lambda ok, v: None, entry)

    def _missing_from_account(self, server_plugins):
        missing = []
        for p in server_plugins or []:
            it = self.catalog.get(p.get("id"))
            if it is not None and installer.get_item_state(it)[0] == "none":
                missing.append(it)
        return missing

    def _offer_restore(self, missing, quiet_if_none=False):
        if not missing:
            if not quiet_if_none:
                self._offer_settings_restore()
            return
        names = _("، ").join(it.name for it in missing[:4]) + ("…" if len(missing) > 4 else "")
        self.show_dialog(
            _("استعادة بلاجيناتك"),
            _("عندك %d بلجن محفوظ بحسابك وغير مثبت هنا: %s") % (len(missing), names),
            ok_label=_("استعادة الكل"),
            on_ok=lambda: self._start_update_queue([it.key for it in missing], mode="restore")
        )

    def restore_plugins(self):
        if not account.is_logged_in():
            self.open_acc_menu("login")
            return
        self.show_toast(_("جاري قراءة بلجيناتك المحفوظة…"))

        def done(ok, val):
            if not ok:
                self.show_toast(self._err_text(val))
                return
            self._offer_restore(self._missing_from_account(val))
        self._run_async(account.get_plugins, done)

    def _after_login(self):
        """Upload what is installed here, then offer to install what is saved but missing."""
        self._refresh_avatar()
        self._run_async(lambda: account.ensure_box_key(force=True), lambda ok, v: None)
        try:
            from . import remote
            remote.poke(hello=True)          # link this box to the account (install from the phone)
        except Exception:
            pass
        items = self._installed_for_sync()

        def done(ok, val):
            if not ok:
                self.show_toast(self._err_text(val))
                return
            missing = self._missing_from_account(val)
            if missing:
                self._offer_restore(missing)
            else:
                self.show_toast(_("تمت مزامنة بلجيناتك (%d)") % len(val or []))
        self._run_async(account.push_plugins, done, items)

    # -----------------------------------------------------------------------
    # INSTALL HISTORY
    # -----------------------------------------------------------------------
    class _HistEntry(object):
        ACTIONS = {"install": _("تثبيت"), "update": _("تحديث"), "remove": _("إزالة")}

        def __init__(self, rec, cat_item):
            self.rec = rec
            self.item = cat_item
            self.key = rec.get("id", "")
            self.name = rec.get("name") or self.key
            self.version = rec.get("version", "")
            self.updated = None
            self.category = getattr(cat_item, "category", "extensions")
            self.icon_url = getattr(cat_item, "icon_url", None)
            self.status_codes = getattr(cat_item, "status_codes", [])
            self.description = ""
            self.subcode = getattr(cat_item, "subcode", None)

        def meta(self):
            t = datetime.fromtimestamp(self.rec.get("time", 0)).strftime("%d.%m.%Y  %H:%M")
            act = self.ACTIONS.get(self.rec.get("action"), self.rec.get("action", ""))
            ver = format_version_display(self.version, prefix_v=True) if self.version else "—"
            return "%s · %s · %s" % (act, ver, t)

        def ok(self):
            return self.rec.get("rc", 1) == 0

    def open_history(self):
        if not (self.view_state == "search" and self.list_mode == "history"):
            self._push_history()
        self.list_mode = "history"
        self.search_results = [self._HistEntry(r, self.catalog.get(r.get("id"))) for r in installer.load_history()]
        self.search_focused_row_idx = 0
        self.search_list_scroll_y = 0
        self.view_state = "search"
        if self.search_results:
            self.cats_focused_level = "rows"
            self.render_ui()
        else:
            self.render_ui()
            self._focus_top_bar("avatar")

    # -----------------------------------------------------------------------
    # MY PLUGINS (installed from the store)
    # -----------------------------------------------------------------------
    def open_mine(self):
        if not (self.view_state == "search" and self.list_mode == "mine"):
            self._push_history()
        self.list_mode = "mine"
        res = [it for it in self.catalog.items if installer.get_item_state(it)[0] != "none"]
        res.sort(key=lambda it: (it.name or "").lower())
        self.search_results = res
        self.search_focused_row_idx = 0
        self.search_list_scroll_y = 0
        self.view_state = "search"
        if res:
            self.cats_focused_level = "rows"
            self.render_ui()
        else:
            self.render_ui()
            self._focus_top_bar("tab_mine")

    def _sync_categories(self):
        """Rebuild category chips / colours from the catalog (index.json categories)."""
        if not settings.get("show_incompatible"):
            installer.filter_compatible(self.catalog)
        ep_catalog.apply_categories(self.catalog)
        CAT_CHIPS[:] = [("all", _("الكل"))] + list(self.catalog.category_list())
        for c in getattr(self.catalog, "categories", []) or []:
            if c.get("id") and c.get("color"):
                CATEGORY_COLORS[c["id"]] = c["color"]
        if self.cats_selected_cat_valid() is False:
            self.cats_selected_cat = "all"
        if getattr(self, "cats_focused_chip_idx", 0) >= len(CAT_CHIPS):
            self.cats_focused_chip_idx = 0
        self._refresh_bell()

    def cats_selected_cat_valid(self):
        cur = getattr(self, "cats_selected_cat", "all")
        return cur == "all" or any(k == cur for k, _ in CAT_CHIPS)

    def _reload_from_cache(self):
        cat = ep_catalog.load_cached_catalog()
        if cat is not None:
            self.catalog = cat
            self._sync_categories()
            for m in list(sys.modules.values()):
                if m is not None and hasattr(m, "GLOBAL_CATALOG") and hasattr(m, "get_catalog"):
                    m.GLOBAL_CATALOG = cat
            self.render_ui()

    def _on_background_index(self, ok, res):
        """Store opened with a stale cache: swap in the fresh index without blocking the screen."""
        if not ok or not res:
            return
        new_cat, online, _msg = res
        if new_cat is None or not online or getattr(new_cat, "not_modified", False):
            return
        self.catalog = new_cat
        self._sync_categories()
        for m in list(sys.modules.values()):
            if m is not None and hasattr(m, "GLOBAL_CATALOG") and hasattr(m, "get_catalog"):
                m.GLOBAL_CATALOG = new_cat
        busy = getattr(self, "menu_visible", False) or getattr(self, "dialog_visible", False) or \
            getattr(self, "viewer_visible", False)
        if self.view_state == "home" and not busy:
            self.render_ui()
        self.show_toast(_("تم تحديث القائمة (%d عنصر)") % len(new_cat.items))

    def _reload_catalog(self):
        try:
            new_cat, online, msg = ep_catalog.fetch_remote_index()
            if new_cat is None:
                self.show_toast(msg or _("فشل تحديث القائمة"))
                return
            self.catalog = new_cat
            self._sync_categories()
            for m in list(sys.modules.values()):
                if m is not None and hasattr(m, "GLOBAL_CATALOG") and hasattr(m, "get_catalog"):
                    m.GLOBAL_CATALOG = new_cat
            self.render_ui()
            self._focus_top_bar("avatar")
            if online:
                self.show_toast(_("تم تحديث القائمة (%d عنصر)") % len(new_cat.items))
            else:
                self.show_toast(msg)
        except Exception as e:
            installer.log_debug("Reload catalog error: %s" % e)
            self.show_toast(_("فشل تحديث القائمة"))

    def _clear_cache(self):
        import shutil
        removed = 0
        try:
            from . import catalog as ep_catalog
            for d in (ep_catalog.CACHE_DIR, ep_catalog.FALLBACK_CACHE_DIR):
                for f in ("index.json", "cache_meta.json"):
                    fp = os.path.join(d, f)
                    if os.path.isfile(fp):
                        os.remove(fp)
                        removed += 1
                icons = os.path.join(d, "icons")
                if os.path.isdir(icons):
                    shutil.rmtree(icons, ignore_errors=True)
                    removed += 1
        except Exception as e:
            installer.log_debug("Clear cache error: %s" % e)
        self.show_toast(_("تم مسح الكاش") if removed else _("الكاش فارغ"))

    # -----------------------------------------------------------------------
    # SCREENSHOTS: gallery navigation + full-screen viewer
    # -----------------------------------------------------------------------
    def _move_shot(self, step):
        cur = self.current_elements[self.focused_idx]
        idx, total = cur.get("idx", 0), cur.get("total", 1)
        new = idx + step
        if new < 0 or new >= total:
            return
        if new < self.shots_first:
            self.shots_first = new
        elif new > self.shots_first + 2:
            self.shots_first = new - 2
        self.render_ui()
        for i, el in enumerate(self.current_elements):
            if el.get("type") == "shot" and el.get("idx") == new:
                self.focused_idx = i
                break
        self._update_focus_ring()

    def _on_shots_timer(self):
        if self.viewer_visible:
            self._render_viewer()
            if self.shots_timer and self["shot_full"].instance and not self._viewer_has_image():
                self.shots_timer.start(1000, True)
            return
        if self.view_state != "details" or self.dialog_visible:
            self.shots_refresh_left = 0
            return
        self.shots_refresh_left -= 1
        keep = self.focused_idx
        self.render_ui()
        self.focused_idx = min(keep, max(0, len(self.current_elements) - 1))
        self._update_focus_ring()
        still_missing = False
        item = self.details_item
        if item:
            shots = getattr(item, "screenshots", []) or []
            for n in range(self.shots_first, min(len(shots), self.shots_first + 3)):
                if not ep_catalog.get_cached_screenshot(shots[n], item.key, n):
                    still_missing = True
        if still_missing and self.shots_refresh_left > 0 and self.shots_timer:
            self.shots_timer.start(1000, True)
        else:
            self.shots_refresh_left = 0

    def _viewer_has_image(self):
        item = self.details_item
        shots = getattr(item, "screenshots", []) or [] if item else []
        if not shots:
            return True
        return bool(ep_catalog.get_cached_screenshot(shots[self.viewer_idx], item.key, self.viewer_idx))

    def _hide_viewer_widgets(self):
        self["shot_dim"].hide()
        self["shot_full"].hide()
        self["shot_counter"].hide()

    def open_viewer(self, idx):
        item = self.details_item
        if not item or not getattr(item, "screenshots", None):
            return
        self.viewer_visible = True
        self.viewer_idx = idx
        self["focus_ring"].hide()
        self._render_viewer()

    def close_viewer(self):
        self.viewer_visible = False
        self._hide_viewer_widgets()
        self._update_focus_ring()

    def _render_viewer(self):
        item = self.details_item
        shots = getattr(item, "screenshots", []) or []
        total = len(shots)
        self.viewer_idx = max(0, min(self.viewer_idx, total - 1))
        self["shot_dim"].setPixmap(get_cached_pixmap(img_path("dim_overlay.png")))
        place(self["shot_dim"], 0, 0, SCREEN_W, SCREEN_H)
        self["shot_dim"].show()

        BW, BH = 1160, 620
        local = ep_catalog.get_cached_screenshot(shots[self.viewer_idx], item.key, self.viewer_idx)
        full = fit_image_box(local, BW, BH, radius_design=14, bg=None) if local else None
        if full:
            self["shot_full"].setPixmap(get_cached_pixmap(full))
            place(self["shot_full"], px((1280 - BW) // 2), px(30), px(BW), px(BH))
            self["shot_full"].show()
        else:
            self["shot_full"].hide()
        counter = "%d / %d" % (self.viewer_idx + 1, total)
        if total > 1:
            counter = "◀  %s  ▶" % counter
        if not full:
            counter = _("جاري تحميل الصورة…   ") + counter
            if self.shots_timer:
                self.shots_timer.start(1000, True)
        self["shot_counter"].setText(counter)
        place(self["shot_counter"], px(340), px(660), px(600), px(40))
        self["shot_counter"].show()

    def _viewer_key(self, key):
        item = self.details_item
        total = len(getattr(item, "screenshots", []) or []) if item else 0
        if key == "left" and self.viewer_idx + 1 < total:      # RTL: left = next
            self.viewer_idx += 1
            self._render_viewer()
        elif key == "right" and self.viewer_idx > 0:
            self.viewer_idx -= 1
            self._render_viewer()
        elif key in ("ok", "cancel", "up", "down"):
            self.close_viewer()

    def _hide_toast(self):
        self["toast_bg"].hide()
        self["toast_text"].hide()

    def _screen_alive(self):
        """False once the store screen was closed: a download may finish after the user left the store."""
        try:
            return "dlg_overlay" in self and self["dlg_overlay"].instance is not None
        except Exception:
            return False

    def show_dialog(self, title, text, ok_label=_("موافق"), on_ok=None, on_cancel=None, default_focus="ok",
                    cancel_label=None, on_back=None):
        if not self._screen_alive():
            # nobody can answer the question any more: take the safe answer
            installer.log_debug("dialog '%s' skipped: store screen is closed" % title)
            if on_cancel:
                try:
                    on_cancel()
                except Exception as e:
                    installer.log_debug("on_cancel after close failed: %r" % e)
            return
        self.dialog_data = (title, text, ok_label, on_ok, on_cancel)
        self.dialog_cancel_label = cancel_label
        self.dialog_on_back = on_back
        self.dialog_visible = True
        self.dialog_focus = default_focus
        self._render_dialog()

    def show_toast(self, text):
        if not self._screen_alive():
            return
        t_len = len(text)
        bw = max(240, min(560, t_len * 18 + 52))
        bh = 54
        bx = 1246 - bw
        by = 604

        toast_img_path = os.path.join(_theme.GEN_DIR, "toast_%d.png" % bw)
        if not os.path.exists(toast_img_path):
            im = Image.new("RGBA", (px(bw), px(bh)), (0, 0, 0, 0))
            d = ImageDraw.Draw(im)
            d.rounded_rectangle([0, 0, px(bw) - 1, px(bh) - 1], radius=px(10), fill="#323232")
            toast_img_path = save_image(im, toast_img_path)

        self["toast_bg"].setPixmap(get_cached_pixmap(toast_img_path))
        place(self["toast_bg"], px(bx), px(by), px(bw), px(bh))
        self["toast_bg"].show()

        self["toast_text"].setText(text)
        place(self["toast_text"], px(bx), px(by), px(bw), px(bh))
        self["toast_text"].instance.setFont(gFont("TajawalRegular", px(19)))
        self["toast_text"].instance.setForegroundColor(parseColor("#ffffff"))
        self["toast_text"].show()

        if self.toast_timer:
            self.toast_timer.start(2400, True)

    def _render_dialog(self):
        title, text, ok_label, on_ok, on_cancel = (self.dialog_data + (None, None))[:5]
        bw = 520
        bh = 220
        bx = (1280 - bw) // 2
        by = (720 - bh) // 2

        place(self["dlg_overlay"], 0, 0, SCREEN_W, SCREEN_H)
        self["dlg_overlay"].show()

        dlg_img = os.path.join(_theme.GEN_DIR, "dlg_box_520.png")
        if not os.path.exists(dlg_img):
            im = Image.new("RGBA", (px(bw), px(bh)), (0, 0, 0, 0))
            d = ImageDraw.Draw(im)
            d.rounded_rectangle([0, 0, px(bw) - 1, px(bh) - 1], radius=px(28), fill=SURFACE)
            dlg_img = save_image(im, dlg_img)

        self["dlg_box"].setPixmap(get_cached_pixmap(dlg_img))
        place(self["dlg_box"], px(bx), px(by), px(bw), px(bh))
        self["dlg_box"].show()

        tx = bx + 34
        tw = bw - 68
        place(self["dlg_title"], px(tx), px(by + 28), px(tw), px(36))
        self["dlg_title"].setText(title)
        self["dlg_title"].show()

        place(self["dlg_text"], px(tx), px(by + 72), px(tw), px(60))
        self["dlg_text"].setText(text)
        self["dlg_text"].show()

        btn_w = 130
        btn_h = 46
        btn_y = by + bh - 30 - btn_h
        ok_x = bx + 34
        cancel_x = ok_x + btn_w + 12

        place(self["dlg_btn_ok"], px(ok_x), px(btn_y), px(btn_w), px(btn_h))
        self["dlg_btn_ok"].show()

        place(self["dlg_lbl_ok"], px(ok_x), px(btn_y), px(btn_w), px(btn_h))
        self["dlg_lbl_ok"].setText(ok_label)
        self["dlg_lbl_ok"].show()

        place(self["dlg_btn_cancel"], px(cancel_x), px(btn_y), px(btn_w), px(btn_h))
        self["dlg_btn_cancel"].show()

        place(self["dlg_lbl_cancel"], px(cancel_x), px(btn_y), px(btn_w), px(btn_h))
        self["dlg_lbl_cancel"].setText(getattr(self, "dialog_cancel_label", None) or _("إلغاء"))
        self["dlg_lbl_cancel"].show()

        f_x = ok_x if self.dialog_focus == "ok" else cancel_x
        pad = 6
        place(self["dlg_focus_ring"], px(f_x - pad), px(btn_y - pad), px(btn_w + pad * 2), px(btn_h + pad * 2))
        self["dlg_focus_ring"].show()

    # -----------------------------------------------------------------------
    # RENDER UI
    # -----------------------------------------------------------------------
    def render_ui(self):
        if not self._screen_alive():
            return
        return self._render_ui()

    def _render_ui(self):
        if self.dialog_visible:
            self._render_dialog()
            return

        self._hide_dialog_widgets()

        elems = []
        focusable_elements = []

        view_top = 76
        view_bottom = 674

        # Fixed keys bar labels
        if self.view_state == "search":
            self["lbl_green"].setText(_("تثبيت / فتح"))
            self["lbl_red"].setText(_("رجوع"))
            self["lbl_yellow"].setText(_("مسح البحث"))
            self["lbl_blue"].setText(_("بحث جديد"))
        else:
            self["lbl_green"].setText(_("تثبيت / فتح"))
            self["lbl_red"].setText(_("رجوع"))
            self["lbl_yellow"].setText(_("تحديث الكل"))
            self["lbl_blue"].setText(_("مشاركة") if self.view_state == "details" else _("بحث"))

        if self.search_query:
            self["search_text"].setText(self.search_query)
        else:
            self["search_text"].setText(_("ابحث عن بلجنات"))

        # Top Bar Tabs Highlighting & Underline (C1)
        if self.view_state == "home":
            self["tab_home"].instance.setForegroundColor(parseColor("#01875f"))
            self["tab_home"].instance.setFont(gFont("TajawalBold", px(20)))
            self["tab_cats"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_cats"].instance.setFont(gFont("TajawalRegular", px(20)))
            self["tab_mine"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_mine"].instance.setFont(gFont("TajawalRegular", px(20)))
            place(self["tab_line"], px(TABS["tab_home"][0]), px(72), px(TABS["tab_home"][1]), px(4))
            self["tab_line"].setPixmap(get_cached_pixmap(get_tab_line_pixmap(TABS["tab_home"][1])))
            self["tab_line"].show()
            self._build_home_descriptors(elems, focusable_elements, view_top, view_bottom)

        elif self.view_state == "cats":
            self["tab_home"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_home"].instance.setFont(gFont("TajawalRegular", px(20)))
            self["tab_cats"].instance.setForegroundColor(parseColor("#01875f"))
            self["tab_cats"].instance.setFont(gFont("TajawalBold", px(20)))
            self["tab_mine"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_mine"].instance.setFont(gFont("TajawalRegular", px(20)))
            place(self["tab_line"], px(TABS["tab_cats"][0]), px(72), px(TABS["tab_cats"][1]), px(4))
            self["tab_line"].setPixmap(get_cached_pixmap(get_tab_line_pixmap(TABS["tab_cats"][1])))
            self["tab_line"].show()
            self._build_cats_descriptors(elems, focusable_elements, view_top, view_bottom)

        elif self.view_state == "search":
            self["tab_home"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_home"].instance.setFont(gFont("TajawalRegular", px(20)))
            self["tab_cats"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_cats"].instance.setFont(gFont("TajawalRegular", px(20)))
            self["tab_mine"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_mine"].instance.setFont(gFont("TajawalRegular", px(20)))
            self["tab_line"].hide()
            self._build_search_descriptors(elems, focusable_elements, view_top, view_bottom)

        elif self.view_state == "details":
            self["tab_home"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_home"].instance.setFont(gFont("TajawalRegular", px(20)))
            self["tab_cats"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_cats"].instance.setFont(gFont("TajawalRegular", px(20)))
            self["tab_mine"].instance.setForegroundColor(parseColor(C("#5f6368")))
            self["tab_mine"].instance.setFont(gFont("TajawalRegular", px(20)))
            self["tab_line"].hide()
            self._build_details_descriptors(elems, focusable_elements, view_top, view_bottom)

        bg_idx = 0
        img_idx = 0
        lbl_idx = 0

        # Viewport Intersection Filtering
        for el in elems:
            ex = el.get("x", 0)
            ey = el.get("y", 0)
            ew = el.get("w", 1)
            eh = el.get("h", 1)

            if not (ey + eh > view_top and ey < view_bottom and ex + ew > 0 and ex < 1280):
                continue

            layer = el.get("layer", 1)

            # Layer 1: Background shapes
            if layer == 1:
                if bg_idx < POOL_BG:
                    w = self.bg_pool[bg_idx]
                    bg_idx += 1
                    place(w, px(ex), px(ey), px(ew), px(eh))
                    pixmap = get_cached_pixmap(el.get("path"))
                    w.setPixmap(pixmap)
                    w.show()

            # Layer 2: Icons and images
            elif layer == 2:
                if img_idx < POOL_IMG:
                    w = self.img_pool[img_idx]
                    img_idx += 1
                    place(w, px(ex), px(ey), px(ew), px(eh))
                    pixmap = get_cached_pixmap(el.get("path"))
                    w.setPixmap(pixmap)
                    w.show()

            # Layer 3: Text labels
            elif layer == 3:
                if lbl_idx < POOL_LBL:
                    w = self.lbl_pool[lbl_idx]
                    lbl_idx += 1

                    font_size_px = px(el["size"])
                    orig_h_px = px(eh)
                    min_h_px = int(math.ceil(font_size_px * 1.8))

                    align_center = getattr(eLabel, "alignCenter", 1)
                    align_top = getattr(eLabel, "alignTop", 0)
                    align_right = getattr(eLabel, "alignRight", 2)
                    align_left = getattr(eLabel, "alignLeft", 0)

                    is_multiline = el.get("multiline", False)
                    if is_multiline:
                        h_px = max(orig_h_px, min_h_px)
                        y_px = px(ey)
                        valign = align_top
                    else:
                        if orig_h_px < min_h_px:
                            diff = min_h_px - orig_h_px
                            y_px = px(ey) - (diff // 2)
                            h_px = min_h_px
                        else:
                            y_px = px(ey)
                            h_px = orig_h_px
                        valign = align_center

                    if el.get("is_button", False):
                        y_px += px(2)

                    halign_req = el.get("halign", 2)
                    if MIRROR and halign_req == 2:
                        halign_req = 0
                    if halign_req == 1:
                        halign = align_center
                    elif halign_req == 0:
                        halign = align_left
                    else:
                        halign = align_right

                    place(w, px(ex), y_px, px(ew), h_px)
                    w.setText(_i18n.plain(el["text"]))
                    w.instance.setFont(gFont(el.get("font", "TajawalRegular"), font_size_px))
                    w.instance.setForegroundColor(parseColor(el.get("color", C("#202124"))))
                    w.instance.setHAlign(halign)
                    w.instance.setVAlign(valign)
                    w.show()

        # Hide unused widgets in pools
        for i in range(bg_idx, POOL_BG):
            self.bg_pool[i].setPixmap(None)
            self.bg_pool[i].hide()
        for i in range(img_idx, POOL_IMG):
            self.img_pool[i].setPixmap(None)
            self.img_pool[i].hide()
        for i in range(lbl_idx, POOL_LBL):
            self.lbl_pool[i].setText("")
            self.lbl_pool[i].hide()

        self.current_elements = focusable_elements
        self._update_focus_ring()

    # -----------------------------------------------------------------------
    # HOME SCREEN DESCRIPTORS
    # -----------------------------------------------------------------------
    def _build_home_descriptors(self, elems, focusable_elements, view_top, view_bottom):
        # D6: Clamp scroll
        self.scroll_y = max(0, min(self.max_scroll_y if self.max_scroll_y > 0 else 600, self.scroll_y))
        scroll_offset = self.scroll_y
        installed_reg = installer.load_installed_registry()

        # Featured cards (Google Play style): 3 side by side, right to left.
        # Admin's featured plugins first, then the newest ones.
        feats = []
        for it in self.catalog.featured(3) + self.catalog.recent(6):
            if it not in feats:
                feats.append(it)
        feats = feats[:3]
        ban_y = 92 - scroll_offset
        self._feat_waiting = False
        if -FEAT_H < ban_y < view_bottom:
            for n, it in enumerate(feats):
                fx = 1246 - FEAT_W - n * (FEAT_W + FEAT_GAP)
                shots = getattr(it, "screenshots", None) or []
                hero = ep_catalog.get_cached_screenshot(shots[0], it.key, 0) if shots else None
                if shots and not hero:
                    self._feat_waiting = True                 # re-render when it arrives
                icon_src = get_item_icon(it, "128")[0]
                try:
                    st = installer.get_item_state(it)[0]
                except Exception:
                    st = "none"
                state = {"none": "install", "update": "update"}.get(st, "installed")
                card = get_feature_card_pixmap(it.key, hero, icon_src, state)
                if card:
                    elems.append({"layer": 1, "type": "bg", "x": fx, "y": ban_y, "w": FEAT_W, "h": FEAT_H, "path": card})
                # headline over the bottom of the artwork
                head = (it.description or "").strip() or _("أحدث إضافة في قسم %s") % CATEGORIES.get(it.category, it.category)
                elems.append({"layer": 3, "type": "text", "x": fx + 16, "y": ban_y + 140, "w": FEAT_W - 32, "h": 28,
                              "text": one_line(head, FEAT_W - 32, 18), "font": "TajawalBold", "size": 18, "color": "#ffffff", "halign": 2})
                # bottom row: icon + name + meta (right), pill label (left)
                ic = fit_icon(icon_src, 44)
                if ic:
                    elems.append({"layer": 2, "type": "img", "x": fx + FEAT_W - 16 - 44, "y": ban_y + 182, "w": 44, "h": 44, "path": ic})
                tx_w = FEAT_W - 16 - 44 - 10 - 134
                elems.append({"layer": 3, "type": "text", "x": fx + 134, "y": ban_y + 178, "w": tx_w, "h": 26,
                              "text": one_line(it.name, tx_w, 19), "font": "TajawalBold", "size": 19, "color": "#ffffff", "halign": 2})
                stt = self._stat(it)
                # short line (the button sits beside it): downloads + rating; the category only when
                # there is nothing else. Arabic words first keep the line RTL.
                meta = []
                if stt.get("installs"):
                    meta.append(_("%s تنزيل") % format_count(stt.get("installs", 0)))
                if stt.get("votes"):
                    meta.append(_("تقييم %.1f") % stt.get("rating", 0))
                if not meta:
                    meta.append(CATEGORIES.get(it.category, it.category))
                elems.append({"layer": 3, "type": "text", "x": fx + 134, "y": ban_y + 205, "w": tx_w, "h": 22,
                              "text": one_line("  ·  ".join(meta), tx_w, 14), "font": "TajawalRegular", "size": 14, "color": "#aab4b1", "halign": 2})
                if stt.get("verified"):
                    elems.append({"layer": 3, "type": "text", "x": fx + 134, "y": ban_y + 229, "w": tx_w, "h": 22,
                                  "text": _("مطوّر موثّق"), "font": "TajawalMedium", "size": 14, "color": "#1de9b6", "halign": 2})
                lbl = {"install": _("تثبيت"), "update": _("تحديث")}.get(state, _("مثبّت"))
                elems.append({"layer": 3, "type": "text", "x": fx + 16, "y": ban_y + 208, "w": 108, "h": 38,
                              "text": lbl, "font": "TajawalBold", "size": 17,
                              "color": "#ffffff" if state == "installed" else "#06201a", "halign": 1})
                focusable_elements.append({"id": "ban_%d" % (n + 1), "x": fx, "y": ban_y, "w": FEAT_W, "h": FEAT_H, "type": "banner", "item": it})

        home_sections = []
        picks = self.catalog.featured(12)
        if len(picks) > 2:
            home_sections.append(("row_feat", _("مختارات المتجر"), picks))
        home_sections.append(("row1", _("أحدث الإضافات"), self.catalog.recent(12)))
        trending = self.trending_items(12)
        if len(trending) >= 3:
            home_sections.append(("row_trend", _("الرائج هذا الأسبوع"), trending))
        popular = self.popular_items(12)
        if popular:
            home_sections.append(("row_pop", _("الأكثر تحميلاً"), popular))
        for ci, (cat_id, cat_name) in enumerate(self.catalog.category_list()):
            home_sections.append(("row_cat_%s" % cat_id, cat_name, self.catalog.by_category(cat_id)))

        if self._feat_waiting and self.shots_timer is not None:
            if getattr(self, "_feat_tries", 0) < 8 and not getattr(self, "_feat_timer_on", False):
                self._feat_tries = getattr(self, "_feat_tries", 0) + 1
                self._feat_timer_on = True
                self._feat_timer = eTimer()
                self._feat_timer.callback.append(self._on_feat_timer)
                self._feat_timer.start(1500, True)
        cur_y = 92 + FEAT_H + 26 - scroll_offset
        for row_id, title, items in home_sections:
            if not items:
                continue
            self._build_card_row(
                row_id, title, items, cur_y, elems, focusable_elements,
                view_top, view_bottom, installed_reg
            )
            cur_y += 290

        content_bottom = cur_y + scroll_offset - 290 + 210 + 30
        self.max_scroll_y = max(0, content_bottom - 674)

    def _on_feat_timer(self):
        self._feat_timer_on = False
        if self.view_state != "home" or self.dialog_visible or getattr(self, "menu_visible", False) \
                or getattr(self, "pair_visible", False) or getattr(self, "viewer_visible", False):
            return
        keep = self.focused_idx
        self.render_ui()
        self.focused_idx = min(keep, max(0, len(self.current_elements) - 1))
        self._update_focus_ring()

    def _build_card_row(self, row_id, title, items, ry, elems, focusable_elements, view_top, view_bottom, installed_reg):
        if -40 < ry < view_bottom:
            elems.append({
                "layer": 3, "type": "text", "x": 70, "y": ry, "w": 1176, "h": 34,
                "text": title, "font": "TajawalMedium", "size": 26,
                "color": C("#202124"), "halign": 2
            })
            elems.append({
                "layer": 2, "type": "img", "x": 34, "y": ry + 5, "w": 24, "h": 24,
                "path": arrow_icon()
            })

        card_y = ry + 46
        scroll_x = self.row_scrolls.get(row_id, 0)

        for idx, it in enumerate(items):
            cx = 1096 - idx * 172 + scroll_x
            cw = 150
            ch = 210

            card_rect = {
                "id": "%s_%d" % (row_id, idx),
                "x": cx, "y": card_y, "w": cw, "h": ch,
                "type": "card", "item": it,
                "row_id": row_id, "idx": idx, "row_total": len(items)
            }
            focusable_elements.append(card_rect)

            if -cw < cx < 1280 and -ch < card_y < view_bottom:
                icon_path, has_glyph = get_item_icon(it, "card")
                elems.append({"layer": 2, "type": "img", "x": cx, "y": card_y, "w": 150, "h": 150, "path": icon_path})
                if not has_glyph:
                    letter = it.name[0].upper() if it.name else "?"
                    elems.append({"layer": 3, "type": "text", "x": cx, "y": card_y, "w": 150, "h": 150, "text": letter, "font": "TajawalBold", "size": 75, "color": "#ffffff", "halign": 1})
                elems.append({"layer": 3, "type": "text", "x": cx, "y": card_y + 160, "w": 150, "h": 24, "text": it.name, "font": "TajawalMedium", "size": 17, "color": C("#202124"), "halign": 2})

                # D1: Missing Version -> "—" if empty/NA, never "vN/A"
                st, _iv = installer.get_item_state(it)
                if st == "installed":
                    meta_txt = _("مثبّت")
                elif st == "update":
                    meta_txt = _("تحديث متاح")
                else:
                    meta_txt = format_version_display(it.version, prefix_v=True)
                    stt = self._stat(it)
                    if stt.get("votes"):
                        meta_txt = format_rating(stt.get("rating", 0))
                        tw = int(measure_text_width(meta_txt, px(15)) / SCALE_FACTOR) + 1
                        elems.append({"layer": 2, "type": "img", "x": cx + 150 - tw - 18, "y": card_y + 189, "w": 14, "h": 14,
                                      "path": get_star_pixmap(14, True, C("#5f6368"))})

                elems.append({"layer": 3, "type": "text", "x": cx, "y": card_y + 186, "w": 150, "h": 20, "text": meta_txt, "font": "TajawalRegular", "size": 15, "color": C("#5f6368"), "halign": 2})

    # -----------------------------------------------------------------------
    # DETAILS SCREEN DESCRIPTORS (D1, D2, D3, D4, D5, D6)
    # -----------------------------------------------------------------------
    def _build_details_descriptors(self, elems, focusable_elements, view_top, view_bottom):
        item = self.details_item
        if not item:
            return

        # D6: Clamp scroll
        self.scroll_y = max(0, min(self.max_scroll_y if self.max_scroll_y > 0 else 9999, self.scroll_y))
        scroll_offset = self.scroll_y
        cur_y = 100 - scroll_offset
        content_x = 34
        content_w = 1212

        # C1) HEADER (Google Play style): artwork behind, title + developer on the right,
        # then a small icon with the stats beside it
        base = cur_y
        shots0 = list(getattr(item, "screenshots", []) or [])
        hero_src = ep_catalog.get_cached_screenshot(shots0[0], item.key, 0) if shots0 else None
        hero = get_details_hero_pixmap(hero_src) if hero_src else None
        if hero:
            elems.append({"layer": 1, "type": "bg", "x": 34, "y": base - 20, "w": 1212, "h": 240, "path": hero})

        tx, tw = 520, 1246 - 520
        elems.append({"layer": 3, "type": "text", "x": tx, "y": base + 22, "w": tw, "h": 56, "text": one_line(item.name, tw, 42),
                      "font": "TajawalBold", "size": 42, "color": C("#202124"), "halign": 2})
        ar_cat = CATEGORIES.get(item.category, item.category)
        dev_name = (getattr(item, "author", "") or "").strip()
        elems.append({"layer": 3, "type": "text", "x": tx, "y": base + 86, "w": tw, "h": 30, "text": one_line(dev_name or ar_cat, tw, 22),
                      "font": "TajawalMedium", "size": 22, "color": "#01875f", "halign": 2})
        sub_name = SUBCODES.get(item.subcode, "")
        source_str = "GitLab" if "gitlab" in (item.url or "").lower() else "GitHub"
        parts = [ar_cat] if dev_name else []
        if sub_name and sub_name != ar_cat:
            parts.append(sub_name)
        parts.append(source_str)
        if self._stat(item).get("verified"):
            parts.append(_("مطوّر موثّق"))
        elems.append({"layer": 3, "type": "text", "x": tx, "y": base + 120, "w": tw, "h": 24, "text": "  ·  ".join(parts),
                      "font": "TajawalRegular", "size": 16, "color": C("#5f6368"), "halign": 2})

        # small icon + stats (right to left)
        stats_y = base + 166
        icon_path, has_glyph = get_item_icon(item, "128")
        ic = fit_icon(icon_path, 60) or icon_path
        elems.append({"layer": 2, "type": "img", "x": 1246 - 60, "y": stats_y - 4, "w": 60, "h": 60, "path": ic})
        if not has_glyph:
            letter = item.name[0].upper() if item.name else "?"
            elems.append({"layer": 3, "type": "text", "x": 1246 - 60, "y": stats_y - 4, "w": 60, "h": 60, "text": letter, "font": "TajawalBold", "size": 30, "color": "#ffffff", "halign": 1})
        col_w = 150
        ver_stat = format_version_display(item.version, prefix_v=True)
        stt = self._stat(item)
        votes = int(stt.get("votes", 0) or 0)
        if votes:
            rating_col = (format_rating(stt.get("rating", 0)), (_("تقييم واحد") if votes == 1 else _("%d تقييم") % votes))
        else:
            rating_col = ("—", _("لا توجد تقييمات"))
        stats_cols = [
            rating_col,
            (format_count(stt.get("installs", 0)), _("التنزيلات")),
            (ver_stat, _("الإصدار")),
            (item.updated or "—", _("آخر تحديث")),
        ]
        right = 1246 - 60 - 20
        for idx, (val_txt, lbl_txt) in enumerate(stats_cols):
            cx = right - (idx + 1) * col_w
            if idx == 0 and votes:
                tw2 = int(measure_text_width(val_txt, px(20)) / SCALE_FACTOR) + 1
                gx = cx + (col_w - (tw2 + 6 + 18)) // 2
                elems.append({"layer": 2, "type": "img", "x": gx, "y": stats_y + 4, "w": 18, "h": 18, "path": get_star_pixmap(18, True, C("#202124"))})
                elems.append({"layer": 3, "type": "text", "x": gx + 24, "y": stats_y, "w": tw2 + 4, "h": 26, "text": val_txt, "font": "TajawalBold", "size": 20, "color": C("#202124"), "halign": 1})
            else:
                elems.append({"layer": 3, "type": "text", "x": cx, "y": stats_y, "w": col_w, "h": 26, "text": val_txt, "font": "TajawalBold", "size": 20, "color": C("#202124"), "halign": 1})
            elems.append({"layer": 3, "type": "text", "x": cx, "y": stats_y + 28, "w": col_w, "h": 22, "text": lbl_txt, "font": "TajawalRegular", "size": 14, "color": C("#5f6368"), "halign": 1})
            if idx < 3:
                elems.append({"layer": 1, "type": "bg", "x": cx, "y": stats_y + 4, "w": 1, "h": 44, "path": img_path("col_divider_gray.png")})

        cur_y = base + 248

        # "works on my image" (answers from other boxes)
        self._load_works(item)
        wl = self._works_line(item)
        if wl:
            pct = wl[1]
            col = C("#01875f") if pct >= 70 else (C("#e37400") if pct >= 40 else C("#d93025"))
            elems.append({"layer": 3, "type": "text", "x": 100, "y": cur_y - 8, "w": 1146, "h": 28, "text": wl[0], "font": "TajawalMedium", "size": 17, "color": col, "halign": 2})
            cur_y += 30

        # C3) ACTION ROW
        active_job = self.installer_job
        is_job_active = active_job and active_job.item.key == item.key

        if is_job_active and active_job.phase == "download":
            prog_x = 1246 - 420
            elems.append({"layer": 3, "type": "text", "x": prog_x, "y": cur_y, "w": 420, "h": 22, "text": _("جاري التنزيل…"), "font": "TajawalRegular", "size": 15, "color": C("#5f6368"), "halign": 2})
            elems.append({"layer": 1, "type": "bg", "x": prog_x, "y": cur_y + 26, "w": 420, "h": 8, "path": img_path("prog_track_420.png")})
            fill_w = max(10, int(420 * 0.45))
            elems.append({"layer": 1, "type": "bg", "x": prog_x + (420 - fill_w), "y": cur_y + 26, "w": fill_w, "h": 8, "path": img_path("prog_fill_420.png")})
            cancel_x = prog_x - 56
            elems.append({"layer": 1, "type": "bg", "x": cancel_x, "y": cur_y + 8, "w": 44, "h": 44, "path": img_path("btn_cancel_round.png")})
            focusable_elements.append({"id": "btn_cancel", "x": cancel_x, "y": cur_y + 8, "w": 44, "h": 44, "type": "cancel_btn"})
            cur_y += 62

        elif is_job_active and active_job.phase == "install":
            prog_x = 1246 - 420
            elems.append({"layer": 3, "type": "text", "x": prog_x, "y": cur_y, "w": 420, "h": 22, "text": _("جاري الإزالة…") if getattr(active_job, "action", "") == "remove" else _("جاري التثبيت…"), "font": "TajawalRegular", "size": 15, "color": C("#5f6368"), "halign": 2})
            elems.append({"layer": 1, "type": "bg", "x": prog_x, "y": cur_y + 26, "w": 420, "h": 8, "path": img_path("prog_fill_420.png")})
            cur_y += 62

        else:
            st, inst_v = installer.get_item_state(item)
            if st != "none":
                if st == "update":
                    btn_w = 260
                    btn_x = 1246 - btn_w
                    elems.append({"layer": 1, "type": "bg", "x": btn_x, "y": cur_y, "w": btn_w, "h": 52, "path": img_path("btn_amber_260.png")})
                    elems.append({"layer": 3, "type": "text", "x": btn_x, "y": cur_y, "w": btn_w, "h": 52, "text": _("تحديث إلى %s") % item.version, "font": "TajawalBold", "size": 20, "color": "#ffffff", "halign": 1, "is_button": True})
                    focusable_elements.append({"id": "btn_update", "x": btn_x, "y": cur_y, "w": btn_w, "h": 52, "type": "action_btn", "action": "update"})
                else:
                    matched_plugin = installer.find_matching_plugin(item.name, item)
                    if matched_plugin:
                        btn1_w = 150
                        btn1_x = 1246 - btn1_w
                        elems.append({"layer": 1, "type": "bg", "x": btn1_x, "y": cur_y, "w": btn1_w, "h": 52, "path": img_path("btn_open_green.png")})
                        elems.append({"layer": 3, "type": "text", "x": btn1_x, "y": cur_y, "w": btn1_w, "h": 52, "text": _("فتح"), "font": "TajawalBold", "size": 21, "color": "#ffffff", "halign": 1, "is_button": True})
                        focusable_elements.append({"id": "btn_open", "x": btn1_x, "y": cur_y, "w": btn1_w, "h": 52, "type": "action_btn", "action": "open", "plugin": matched_plugin})

                        btn2_w = 180
                        btn2_x = btn1_x - 14 - btn2_w
                        elems.append({"layer": 1, "type": "bg", "x": btn2_x, "y": cur_y, "w": btn2_w, "h": 52, "path": img_path("btn_reinst_outline.png")})
                        elems.append({"layer": 3, "type": "text", "x": btn2_x, "y": cur_y, "w": btn2_w, "h": 52, "text": _("إعادة التثبيت"), "font": "TajawalRegular", "size": 19, "color": C("#202124"), "halign": 1, "is_button": True})
                        focusable_elements.append({"id": "btn_reinstall", "x": btn2_x, "y": cur_y, "w": btn2_w, "h": 52, "type": "action_btn", "action": "install"})
                        self._add_remove_button(item, btn2_x - 14 - 150, cur_y, elems, focusable_elements)
                    else:
                        btn_w = 260
                        btn_x = 1246 - btn_w
                        elems.append({"layer": 1, "type": "bg", "x": btn_x, "y": cur_y, "w": btn_w, "h": 52, "path": img_path("btn_outline_260.png")})
                        elems.append({"layer": 3, "type": "text", "x": btn_x, "y": cur_y, "w": btn_w, "h": 52, "text": _("إعادة التثبيت"), "font": "TajawalRegular", "size": 20, "color": C("#202124"), "halign": 1, "is_button": True})
                        focusable_elements.append({"id": "btn_reinstall", "x": btn_x, "y": cur_y, "w": btn_w, "h": 52, "type": "action_btn", "action": "install"})
                        self._add_remove_button(item, btn_x - 14 - 150, cur_y, elems, focusable_elements)
            else:
                btn_img = "btn_warning_260.png" if item.dangerous else "btn_green_260.png"
                btn_x = 1246 - 260
                elems.append({"layer": 1, "type": "bg", "x": btn_x, "y": cur_y, "w": 260, "h": 52, "path": img_path(btn_img)})
                elems.append({"layer": 3, "type": "text", "x": btn_x, "y": cur_y, "w": 260, "h": 52, "text": _("تثبيت"), "font": "TajawalBold", "size": 21, "color": "#ffffff", "halign": 1, "is_button": True})
                focusable_elements.append({"id": "btn_act", "x": btn_x, "y": cur_y, "w": 260, "h": 52, "type": "action_btn", "action": "install"})

            cur_y += 62

        # C3b) "install on my other receivers" + "share", left of the main buttons
        if not is_job_active:
            row_y = cur_y - 62
            row_btns = [f for f in focusable_elements if f.get("type") == "action_btn" and f.get("y") == row_y]
            left = min([f["x"] for f in row_btns] + [1246]) - 14
            ow = 260
            ox = left - ow
            elems.append({"layer": 1, "type": "bg", "x": ox, "y": row_y, "w": ow, "h": 52,
                          "path": get_card_bg_pixmap(ow, 52, radius_design=26, stroke_color="#5f6368", fill_color=None)})
            elems.append({"layer": 3, "type": "text", "x": ox, "y": row_y, "w": ow, "h": 52, "text": _("التثبيت على أجهزة أخرى"),
                          "font": "TajawalMedium", "size": 18, "color": "#01875f", "halign": 1, "is_button": True})
            focusable_elements.append({"id": "btn_boxes", "x": ox, "y": row_y, "w": ow, "h": 52, "type": "action_btn", "action": "boxes"})
            sw = 130
            sx = ox - 14 - sw
            if sx >= 34:
                elems.append({"layer": 3, "type": "text", "x": sx, "y": row_y, "w": sw, "h": 52, "text": _("مشاركة"),
                              "font": "TajawalMedium", "size": 19, "color": "#01875f", "halign": 1, "is_button": True})
                focusable_elements.append({"id": "btn_share", "x": sx, "y": row_y, "w": sw, "h": 52, "type": "action_btn", "action": "share"})

        # C4) LOG AREA: only while this item is being installed; the finished log stays in /tmp/enigmaplay/
        raw_log = []
        if active_job and active_job.item.key == item.key and not getattr(active_job, "finished", False):
            raw_log = getattr(active_job, "cached_lines", [])

        filtered_lines = [l for l in raw_log if not WGET_NOISE_RE.match(l)]
        log_lines = filtered_lines[-6:] if filtered_lines else []

        if log_lines:
            lg_h = len(log_lines) * 18 + 8
            for l_idx, line in enumerate(log_lines):
                elems.append({"layer": 3, "type": "text", "x": 34, "y": cur_y + l_idx * 18, "w": 1212, "h": 18, "text": line[:110], "font": "Regular", "size": 13, "color": C("#5f6368"), "halign": 0})
            cur_y += lg_h + 12

        # C5) NOTE LINE
        note_y = cur_y
        if item.dangerous:
            note_color = "#d93025"
            note_text = _("تنبيه: هذا الإجراء قد يحذف بيانات أو يغيّر النظام ولا يمكن التراجع عنه.")
        elif item.category == "skins" and item.status_codes:
            note_color = C("#5f6368")
            compatible = []
            if "Satv" in item.status_codes: compatible.append("OpenATV")
            if "Sobh" in item.status_codes: compatible.append("OpenBH")
            if "Spur" in item.status_codes: compatible.append("Pure2")
            if "Segm" in item.status_codes: compatible.append("Egami")
            if "Sopn" in item.status_codes: compatible.append("OpenPli")
            images_str = _("، ").join(compatible) if compatible else _("الصور الحديثة")
            note_text = _("متوافق مع: %s") % images_str
        else:
            note_color = C("#5f6368")
            _dl = installer.select_download(item) or {}
            _t = _dl.get("type", "sh")
            _st, _iv = installer.get_item_state(item)
            if _st == "installed":
                note_text = _("مثبّت على جهازك%s.") % ((_(" — الإصدار %s") % _iv) if _iv else "")
            elif _st == "update":
                note_text = _("المثبّت لديك: %s  ·  الجديد: %s") % (_iv or "—", item.version)
            elif _t == "ipk":
                note_text = _("سيتم تثبيت الحزمة (ipk) المناسبة لجهازك عبر opkg.")
            elif _t == "deb":
                note_text = _("سيتم تثبيت الحزمة (deb) المناسبة لجهازك عبر apt.")
            else:
                note_text = _("سيتم تنزيل سكربت التثبيت وتنفيذه على جهازك.")

        elems.append({"layer": 3, "type": "text", "x": 34, "y": note_y, "w": 1212, "h": 24, "text": note_text, "font": "TajawalRegular", "size": 16, "color": note_color, "halign": 2})
        cur_y += 38

        # C6) SCREENSHOTS (horizontal gallery, 3 visible, RTL; OK = full screen)
        shots = list(getattr(item, "screenshots", []) or [])
        if shots:
            SH_W, SH_H, SH_GAP = 384, 216, 30
            total = len(shots)
            self.shots_first = max(0, min(self.shots_first, max(0, total - 3)))
            missing = False
            for vis in range(min(3, total - self.shots_first)):
                n = self.shots_first + vis
                sx = 1246 - SH_W - vis * (SH_W + SH_GAP)
                local = ep_catalog.get_cached_screenshot(shots[n], item.key, n)
                thumb = fit_image_box(local, SH_W, SH_H, radius_design=12) if local else None
                if thumb:
                    elems.append({"layer": 2, "type": "img", "x": sx, "y": cur_y, "w": SH_W, "h": SH_H, "path": thumb})
                else:
                    missing = True
                    elems.append({"layer": 1, "type": "bg", "x": sx, "y": cur_y, "w": SH_W, "h": SH_H, "path": get_card_bg_pixmap(SH_W, SH_H, radius_design=12, stroke_color=C("#dadce0"), fill_color=C("#f1f3f4"))})
                    elems.append({"layer": 3, "type": "text", "x": sx, "y": cur_y, "w": SH_W, "h": SH_H, "text": _("جاري تحميل الصورة…"), "font": "TajawalRegular", "size": 17, "color": C("#5f6368"), "halign": 1})
                focusable_elements.append({"id": "shot_%d" % n, "x": sx, "y": cur_y, "w": SH_W, "h": SH_H, "type": "shot", "idx": n, "total": total})
            if total > 3:
                more = []
                if self.shots_first > 0:
                    more.append("‹")
                more.append("%d / %d" % (min(total, self.shots_first + 3), total))
                elems.append({"layer": 3, "type": "text", "x": 34, "y": cur_y + SH_H + 4, "w": 1212, "h": 22, "text": "  ".join(more), "font": "TajawalRegular", "size": 15, "color": C("#5f6368"), "halign": 0})
            if missing and self.shots_refresh_left <= 0 and self.shots_timer:
                self.shots_refresh_left = 20
                self.shots_timer.start(1000, True)
            cur_y += SH_H + 34

        # C7) SECTIONS (D5: Focus Ring wraps whole section: header + card/text)
        # Section 1: نبذة عن هذا البلجن
        desc_text = item.description if (item.description and len(item.description.strip()) > 0) else _("لا يتوفر وصف تفصيلي لهذا العنصر حالياً.")
        elems.append({"layer": 3, "type": "text", "x": 70, "y": cur_y, "w": 1176, "h": 32, "text": _("نبذة عن هذا البلجن"), "font": "TajawalMedium", "size": 24, "color": C("#202124"), "halign": 2})
        elems.append({"layer": 2, "type": "img", "x": 34, "y": cur_y + 4, "w": 24, "h": 24, "path": arrow_icon()})
        elems.append({"layer": 3, "type": "text", "x": 34, "y": cur_y + 36, "w": 1212, "h": 50, "text": desc_text, "font": "TajawalRegular", "size": 19, "color": C("#3c4043"), "halign": 2, "multiline": True})
        focusable_elements.append({"id": "sec_desc", "x": 34, "y": cur_y, "w": 1212, "h": 90, "type": "section"})
        cur_y += 104

        # Rate this plugin (only once it is installed)
        if installer.get_item_state(item)[0] != "none":
            mine = int(self.my_ratings.get(item.key, 0) or 0)
            elems.append({"layer": 3, "type": "text", "x": 34, "y": cur_y, "w": 1212, "h": 32, "text": _("قيّم هذا البلجن"), "font": "TajawalMedium", "size": 24, "color": C("#202124"), "halign": 2})
            sub = (_("تقييمك: %d من 5  ·  OK للتعديل") % mine) if mine else _("أخبر الآخرين برأيك")
            elems.append({"layer": 3, "type": "text", "x": 34, "y": cur_y + 34, "w": 1212, "h": 24, "text": sub, "font": "TajawalRegular", "size": 16, "color": C("#5f6368"), "halign": 2})
            st_y = cur_y + 68
            for n in range(1, 6):
                sx = 1246 - 44 - (n - 1) * 70
                filled = n <= mine
                elems.append({"layer": 2, "type": "img", "x": sx + 4, "y": st_y + 4, "w": 36, "h": 36,
                              "path": get_star_pixmap(36, filled, "#01875f" if filled else "#80868b")})
                focusable_elements.append({"id": "star_%d" % n, "x": sx, "y": st_y, "w": 44, "h": 44, "type": "star", "stars": n})
            cur_y += 68 + 44 + 28

        # Section 2: المصدر الأصلي (credit to the developer: name + his repository page)
        src_page = getattr(item, "homepage", "") or ""
        src_dev = getattr(item, "author", "") or ""
        if src_page or src_dev:
            elems.append({"layer": 3, "type": "text", "x": 100, "y": cur_y, "w": 1146, "h": 32, "text": _("المصدر الأصلي"), "font": "TajawalMedium", "size": 24, "color": C("#202124"), "halign": 2})
            card_url_path = get_card_bg_pixmap(1212, 84)
            elems.append({"layer": 1, "type": "bg", "x": 34, "y": cur_y + 36, "w": 1212, "h": 84, "path": card_url_path})
            if src_dev:
                elems.append({"layer": 3, "type": "text", "x": 54, "y": cur_y + 44, "w": 1172, "h": 32, "text": _("المطوّر: %s") % src_dev, "font": "TajawalMedium", "size": 18, "color": C("#202124"), "halign": 2})
            if self._stat(item).get("verified"):
                # the original developer manages this plugin himself (claimed through a developer invite)
                elems.append({"layer": 3, "type": "text", "x": 54, "y": cur_y + 44, "w": 400, "h": 32, "text": _("مطوّر موثّق"), "font": "TajawalBold", "size": 18, "color": C("#01875f"), "halign": 0})
            if src_page:
                elems.append({"layer": 3, "type": "text", "x": 54, "y": cur_y + 80, "w": 1172, "h": 30, "text": src_page.replace("https://", ""), "font": "TajawalRegular", "size": 16, "color": C("#1a73e8"), "halign": 0})
            focusable_elements.append({"id": "sec_src", "x": 34, "y": cur_y, "w": 1212, "h": 124, "type": "section"})
            cur_y += 140

        # Section 3: ما الجديد (D3: format date · version or date ONLY)
        if hasattr(item, "changelog") and item.changelog and len(item.changelog) > 0:
            elems.append({"layer": 3, "type": "text", "x": 100, "y": cur_y, "w": 1146, "h": 32, "text": _("ما الجديد"), "font": "TajawalMedium", "size": 24, "color": C("#202124"), "halign": 2})
            cl_y = cur_y + 36
            displayed_cl = item.changelog[:5]
            for entry in displayed_cl:
                if isinstance(entry, (tuple, list)):
                    c_date = entry[0] if len(entry) > 0 else "—"
                    c_ver = str(entry[1]).strip() if len(entry) > 1 and entry[1] else ""
                elif isinstance(entry, dict):
                    c_date = entry.get("date", "—")
                    c_ver = str(entry.get("version", "")).strip()
                else:
                    c_date = str(entry)
                    c_ver = ""

                # D3: If changelog line has no version, show date ONLY. Never show item name.
                if c_ver and c_ver != "—":
                    cl_text = "%s · %s" % (c_date, c_ver)
                else:
                    cl_text = c_date

                elems.append({"layer": 3, "type": "text", "x": 34, "y": cl_y, "w": 1212, "h": 26, "text": cl_text, "font": "TajawalRegular", "size": 18, "color": C("#3c4043"), "halign": 2})
                cl_y += 28

            total_sec3_h = 36 + len(displayed_cl) * 28 + 6
            focusable_elements.append({"id": "sec_cl", "x": 34, "y": cur_y, "w": 1212, "h": total_sec3_h, "type": "section"})
            cur_y += total_sec3_h + 16

        # Section 4: معلومات إضافية (D4: ONE column right-aligned at fixed x, 180 design px from inner right)
        elems.append({"layer": 3, "type": "text", "x": 100, "y": cur_y, "w": 1146, "h": 32, "text": _("معلومات إضافية"), "font": "TajawalMedium", "size": 24, "color": C("#202124"), "halign": 2})
        info_lines = [
            (_("الإصدار"), format_version_display(item.version, prefix_v=False)),
            (_("آخر تحديث"), item.updated or "—"),
            (_("القسم"), ar_cat),
        ]
        if item.group:
            info_lines.append((_("المجموعة"), item.group))
        info_lines.append((_("المعرّف"), item.key))

        card_h = len(info_lines) * 36 + 28
        # D4: Card background includes all lines + padding, all 4 borders + radius drawn
        bg_card_path = get_card_bg_pixmap(1212, card_h)
        elems.append({"layer": 1, "type": "bg", "x": 34, "y": cur_y + 36, "w": 1212, "h": card_h, "path": bg_card_path})

        # D4: Labels stay at inner right edge (1226). Values right-aligned at 1226 - 180 = 1046!
        label_inner_right = 1226
        values_col_right = label_inner_right - 180 # = 1046
        val_x = 54
        val_w = values_col_right - val_x           # = 992
        lbl_w = 170
        lbl_x = label_inner_right - lbl_w          # = 1056

        row_y = cur_y + 48
        for lbl_txt, val_txt in info_lines:
            elems.append({
                "layer": 3, "type": "text", "x": lbl_x, "y": row_y, "w": lbl_w, "h": 26,
                "text": lbl_txt, "font": "TajawalMedium", "size": 18,
                "color": C("#5f6368"), "halign": 2
            })
            # All values in ONE column right-aligned at fixed x=1046, including LTR KEY
            elems.append({
                "layer": 3, "type": "text", "x": val_x, "y": row_y, "w": val_w, "h": 26,
                "text": val_txt, "font": "TajawalRegular", "size": 18,
                "color": C("#202124"), "halign": 2
            })
            row_y += 36

        sec4_h = card_h + 36 + 8
        focusable_elements.append({"id": "sec_info", "x": 34, "y": cur_y, "w": 1212, "h": sec4_h, "type": "section"})
        cur_y += sec4_h

        # D6: Scroll clamping: content bottom with 30 design px bottom padding
        content_bottom = cur_y + scroll_offset + 30
        self.max_scroll_y = max(0, content_bottom - 674)

    # -----------------------------------------------------------------------
    # CATEGORIES TAB DESCRIPTORS (Part C)
    # -----------------------------------------------------------------------
    def _build_cats_descriptors(self, elems, focusable_elements, view_top, view_bottom):
        # 1. Main Category Chips Row (C2)
        chips_y = 96
        # Horizontal auto-scrolling for main chips row
        cur_x = 1246 + self.cats_chips_scroll_x
        chip_rects = []
        for idx, (cat_key, cat_label) in enumerate(CAT_CHIPS):
            tw = measure_text_width(cat_label, px(19)) / SCALE_FACTOR
            cw = max(70, int(tw + 44))
            cx = cur_x - cw
            chip_rects.append({
                "idx": idx,
                "key": cat_key,
                "label": cat_label,
                "x": cx, "y": chips_y, "w": cw, "h": 38,
                "selected": (self.cats_selected_cat == cat_key)
            })
            cur_x = cx - 10

        # Adjust scroll if focused chip is out of view
        if self.cats_focused_level == "chips" and 0 <= self.cats_focused_chip_idx < len(chip_rects):
            f_chip = chip_rects[self.cats_focused_chip_idx]
            if f_chip["x"] < 34:
                shift = 34 - f_chip["x"]
                self.cats_chips_scroll_x += shift
                for cr in chip_rects:
                    cr["x"] += shift
            elif f_chip["x"] + f_chip["w"] > 1246:
                shift = (f_chip["x"] + f_chip["w"]) - 1246
                self.cats_chips_scroll_x -= shift
                for cr in chip_rects:
                    cr["x"] -= shift

        # Append visual elements for visible chips
        for cr in chip_rects:
            if cr["x"] + cr["w"] > -50 and cr["x"] < 1330:
                bg_p = get_chip_bg_pixmap(cr["w"], selected=cr["selected"])
                elems.append({"layer": 1, "type": "bg", "x": cr["x"], "y": chips_y, "w": cr["w"], "h": 38, "path": bg_p})
                t_color = "#01875f" if cr["selected"] else C("#202124")
                t_font = "TajawalBold" if cr["selected"] else "TajawalRegular"
                elems.append({"layer": 3, "type": "text", "x": cr["x"], "y": chips_y, "w": cr["w"], "h": 38, "text": cr["label"], "font": t_font, "size": 19, "color": t_color, "halign": 1})

        # Register chip elements for spatial navigation
        for cr in chip_rects:
            focusable_elements.append({
                "id": "cat_chip_%s" % cr["key"],
                "x": cr["x"], "y": chips_y, "w": cr["w"], "h": 38,
                "type": "cat_chip", "key": cr["key"], "idx": cr["idx"]
            })

        # 2. Sub-filter Row (C3)
        has_subfilter = False
        subchip_rects = []
        subchips_y = chips_y + 38 + 12
        if self.cats_selected_cat != "all":
            c_items = [it for it in self.catalog.items if it.category == self.cats_selected_cat]
            sub_counts = Counter(it.subcode for it in c_items if it.subcode and it.subcode in SUBCODES)
            if len(sub_counts) >= 2:
                has_subfilter = True
                sub_list = [("all", _("الكل"))] + [(sc, SUBCODES[sc]) for sc, cnt in sub_counts.most_common()]

                cur_sx = 1246 + self.cats_subchips_scroll_x
                for s_idx, (s_code, s_label) in enumerate(sub_list):
                    stw = measure_text_width(s_label, px(19)) / SCALE_FACTOR
                    scw = max(70, int(stw + 44))
                    scx = cur_sx - scw
                    subchip_rects.append({
                        "idx": s_idx,
                        "key": s_code,
                        "label": s_label,
                        "x": scx, "y": subchips_y, "w": scw, "h": 38,
                        "selected": (self.cats_selected_subcode == s_code)
                    })
                    cur_sx = scx - 10

                # Auto scroll subchips
                if self.cats_focused_level == "subchips" and 0 <= self.cats_focused_subchip_idx < len(subchip_rects):
                    f_sub = subchip_rects[self.cats_focused_subchip_idx]
                    if f_sub["x"] < 34:
                        shift = 34 - f_sub["x"]
                        self.cats_subchips_scroll_x += shift
                        for sr in subchip_rects:
                            sr["x"] += shift
                    elif f_sub["x"] + f_sub["w"] > 1246:
                        shift = (f_sub["x"] + f_sub["w"]) - 1246
                        self.cats_subchips_scroll_x -= shift
                        for sr in subchip_rects:
                            sr["x"] -= shift

                # Render subchips
                for sr in subchip_rects:
                    if sr["x"] + sr["w"] > -50 and sr["x"] < 1330:
                        bg_sp = get_chip_bg_pixmap(sr["w"], selected=sr["selected"])
                        elems.append({"layer": 1, "type": "bg", "x": sr["x"], "y": subchips_y, "w": sr["w"], "h": 38, "path": bg_sp})
                        st_color = "#01875f" if sr["selected"] else C("#202124")
                        st_font = "TajawalBold" if sr["selected"] else "TajawalRegular"
                        elems.append({"layer": 3, "type": "text", "x": sr["x"], "y": subchips_y, "w": sr["w"], "h": 38, "text": sr["label"], "font": st_font, "size": 19, "color": st_color, "halign": 1})

                for sr in subchip_rects:
                    focusable_elements.append({
                        "id": "sub_chip_%s" % sr["key"],
                        "x": sr["x"], "y": subchips_y, "w": sr["w"], "h": 38,
                        "type": "sub_chip", "key": sr["key"], "idx": sr["idx"]
                    })

        # 3. Filtered & Sorted Items List (C4)
        if self.cats_selected_cat == "all":
            raw_filtered = list(self.catalog.items)
        else:
            raw_filtered = [it for it in self.catalog.items if it.category == self.cats_selected_cat]

        if has_subfilter and self.cats_selected_subcode != "all":
            raw_filtered = [it for it in raw_filtered if it.subcode == self.cats_selected_subcode]

        # Sort: items with updated date first (newest first), then by name
        filtered_items = sort_catalog_items(raw_filtered)
        # the admin's order (from the store) wins; same order keeps newest-first
        filtered_items = sorted(filtered_items, key=lambda it: getattr(it, "order", 1000))
        self.cats_filtered_items = filtered_items

        list_start_y = (subchips_y + 38 + 16) if has_subfilter else (chips_y + 38 + 20)
        viewport_bottom = 664
        V_H = viewport_bottom - list_start_y

        # Empty result check (C6)
        if not filtered_items:
            elems.append({
                "layer": 3, "type": "text", "x": 34, "y": list_start_y + 40, "w": 1212, "h": 36,
                "text": _("لا توجد عناصر في هذا القسم."), "font": "TajawalRegular", "size": 19,
                "color": C("#5f6368"), "halign": 1
            })
            return

        # Clamp cats_list_scroll_y
        total_list_h = len(filtered_items) * 94
        max_list_scroll = max(0, total_list_h - V_H)
        self.cats_list_scroll_y = max(0, min(max_list_scroll, self.cats_list_scroll_y))

        # Ensure focused row is visible
        if self.cats_focused_level == "rows":
            if self.cats_focused_row_idx >= len(filtered_items):
                self.cats_focused_row_idx = len(filtered_items) - 1
            if self.cats_focused_row_idx < 0:
                self.cats_focused_row_idx = 0

            cur_top = self.cats_focused_row_idx * 94
            cur_bottom = cur_top + 88
            if cur_top < self.cats_list_scroll_y:
                self.cats_list_scroll_y = cur_top
            elif cur_bottom > self.cats_list_scroll_y + V_H:
                self.cats_list_scroll_y = cur_bottom - V_H
            self.cats_list_scroll_y = max(0, min(max_list_scroll, self.cats_list_scroll_y))

        # C5: Viewport Windowing (render ONLY rows inside viewport + 2 above/below)
        first_row = max(0, int((self.cats_list_scroll_y - 2 * 94) // 94))
        last_row = min(len(filtered_items) - 1, int((self.cats_list_scroll_y + V_H + 2 * 94) // 94))

        installed_reg = installer.load_installed_registry()

        for idx in range(first_row, last_row + 1):
            it = filtered_items[idx]
            row_y = list_start_y + idx * 94 - self.cats_list_scroll_y
            if not (-88 < row_y < 674):
                continue

            # Register row element
            row_rect = {
                "id": "list_row_%d" % idx,
                "x": 34, "y": row_y, "w": 1212, "h": 88,
                "type": "list_row", "item": it, "idx": idx
            }
            focusable_elements.append(row_rect)

            # Icon 64 (Layer 2 img, Layer 3 letter only if no glyph)
            icon_path, has_glyph = get_item_icon(it, "64")
            icon_x = 1246 - 14 - 64 # = 1168
            icon_y = row_y + 12
            elems.append({"layer": 2, "type": "img", "x": icon_x, "y": icon_y, "w": 64, "h": 64, "path": icon_path})
            if not has_glyph:
                letter = it.name[0].upper() if it.name else "?"
                elems.append({"layer": 3, "type": "text", "x": icon_x, "y": icon_y, "w": 64, "h": 64, "text": letter, "font": "TajawalBold", "size": 32, "color": "#ffffff", "halign": 1})

            # Title
            title_x = 180
            title_w = icon_x - 18 - title_x # = 970
            elems.append({"layer": 3, "type": "text", "x": title_x, "y": row_y + 16, "w": title_w, "h": 28, "text": it.name, "font": "TajawalMedium", "size": 21, "color": C("#202124"), "halign": 2})

            # Meta Line: <sub-category or category> · <version or —> · <updated or —>
            sub_part = SUBCODES.get(it.subcode) or CATEGORIES.get(it.category, it.category)
            ver_part = format_version_display(it.version, prefix_v=True)
            up_part = it.updated or "—"
            meta_txt = "%s · %s · %s" % (sub_part, ver_part, up_part)
            elems.append({"layer": 3, "type": "text", "x": title_x, "y": row_y + 46, "w": title_w, "h": 24, "text": meta_txt, "font": "TajawalRegular", "size": 15, "color": C("#5f6368"), "halign": 2})

            # Pill on the left
            pill_x = 34 + 14 # = 48
            pill_y = row_y + 24
            pill_w = 110
            pill_h = 40

            st, inst_v = installer.get_item_state(it)
            if st != "none":
                if st == "update":
                    pill_path = img_path("pill_outline.png")
                    pill_txt = _("تحديث")
                    pill_col = "#01875f"
                else:
                    pill_path = img_path("pill_outline.png")
                    pill_txt = _("فتح")
                    pill_col = "#01875f"
            else:
                pill_path = img_path("pill_green_filled.png")
                pill_txt = _("تثبيت")
                pill_col = "#ffffff"

            elems.append({"layer": 1, "type": "bg", "x": pill_x, "y": pill_y, "w": pill_w, "h": pill_h, "path": pill_path})
            elems.append({"layer": 3, "type": "text", "x": pill_x, "y": pill_y, "w": pill_w, "h": pill_h, "text": pill_txt, "font": "TajawalBold", "size": 17, "color": pill_col, "halign": 1})

    # -----------------------------------------------------------------------
    # SEARCH IMPLEMENTATION
    # -----------------------------------------------------------------------
    def open_search(self):
        try:
            from Screens.VirtualKeyBoard import VirtualKeyBoard
            self.session.openWithCallback(
                self._on_search_submitted,
                VirtualKeyBoard,
                title=_("ابحث عن بلجنات"),
                text=self.search_query or ""
            )
        except Exception as e:
            print("[EnigmaPlay] Could not open VirtualKeyBoard:", e)
            self.show_toast(_("تعذر فتح لوحة المفاتيح"))

    def _on_search_submitted(self, text):
        if text is None:
            return
        q = text.strip() if text else ""
        if not q:
            self.clear_search()
            return
        self.perform_search(q)

    def perform_search(self, query):
        if self.view_state not in ("search", "details"):
            self.history_stack.append({
                "view_state": self.view_state,
                "scroll_y": self.scroll_y,
                "row_scrolls": dict(self.row_scrolls),
                "focused_idx": self.focused_idx,
                "details_item": self.details_item,
                "cats_selected_cat": self.cats_selected_cat,
                "cats_selected_subcode": self.cats_selected_subcode,
                "cats_focused_level": self.cats_focused_level,
                "cats_focused_chip_idx": self.cats_focused_chip_idx,
                "cats_focused_subchip_idx": self.cats_focused_subchip_idx,
                "cats_focused_row_idx": self.cats_focused_row_idx,
                "cats_chips_scroll_x": self.cats_chips_scroll_x,
                "cats_subchips_scroll_x": self.cats_subchips_scroll_x,
                "cats_list_scroll_y": self.cats_list_scroll_y,
                "search_query": self.search_query,
                "search_results": list(self.search_results),
                "search_focused_row_idx": self.search_focused_row_idx,
                "search_list_scroll_y": self.search_list_scroll_y,
            })

        self.search_query = query
        self["search_text"].setText(self.search_query)
        try:
            self["search_text"].instance.setForegroundColor(parseColor(C("#202124")))
        except Exception:
            pass

        self.list_mode = "search"
        raw_res = self.catalog.search(query)
        self.search_results = sort_search_results(raw_res, query)
        self.search_focused_row_idx = 0
        self.search_list_scroll_y = 0
        self.view_state = "search"
        self.cats_focused_level = "rows"
        self.render_ui()

    def clear_search(self):
        self.list_mode = "search"
        self.search_query = ""
        self.search_results = []
        self.search_focused_row_idx = 0
        self.search_list_scroll_y = 0
        self["search_text"].setText(_("ابحث عن بلجنات"))
        try:
            self["search_text"].instance.setForegroundColor(parseColor(C("#5f6368")))
        except Exception:
            pass

        if self.view_state == "search":
            if self.history_stack:
                self.key_cancel()
            else:
                self.view_state = "home"
                self.cats_focused_level = "rows"
                self.scroll_y = 0
                self.focused_idx = 0
                self.render_ui()
        else:
            self.render_ui()

    def _build_search_descriptors(self, elems, focusable_elements, view_top, view_bottom):
        # Header section: Results summary
        header_y = 96
        header_h = 42

        res_count = len(self.search_results)
        updates_mode = (self.list_mode == "updates")
        mine_mode = (self.list_mode == "mine")
        history_mode = (self.list_mode == "history")
        if history_mode:
            title_text = _("سجل التثبيت")
        elif mine_mode:
            title_text = _("بلاجيناتي")
        elif updates_mode:
            title_text = _("التحديثات المتوفرة")
        else:
            title_text = _("نتائج البحث عن: \"%s\"") % self.search_query
        elems.append({
            "layer": 3, "type": "text",
            "x": 350, "y": header_y, "w": 896, "h": 36,
            "text": title_text, "font": "TajawalBold", "size": 22,
            "color": C("#202124"), "halign": 2
        })

        if res_count > 0:
            if history_mode:
                count_text = _("%d عملية") % res_count
            elif mine_mode:
                count_text = _("%d بلجن مثبّت") % res_count
            elif updates_mode:
                count_text = _("تحديث واحد") if res_count == 1 else (_("تحديثان") if res_count == 2 else _("%d تحديثات") % res_count)
                count_text += _("  ·  الأصفر: تحديث الكل")
            else:
                count_text = _("%d نتيجة") % res_count if res_count > 2 else (_("نتيجة واحدة") if res_count == 1 else _("نتيجتان"))
            elems.append({
                "layer": 3, "type": "text",
                "x": 34, "y": header_y + 4, "w": 280, "h": 32,
                "text": count_text, "font": "TajawalMedium", "size": 17,
                "color": "#01875f", "halign": 0
            })

        list_start_y = header_y + header_h + 10 # = 148
        viewport_bottom = 664
        V_H = viewport_bottom - list_start_y

        # Empty result
        if not self.search_results:
            elems.append({
                "layer": 3, "type": "text",
                "x": 34, "y": list_start_y + 60, "w": 1212, "h": 40,
                "text": _("لا توجد عمليات بعد") if history_mode else _("لا يوجد بلجنات مثبتة من المتجر بعد") if mine_mode else _("كل بلجيناتك محدّثة") if updates_mode else _("لم يتم العثور على أي بلجن يطابق \"%s\"") % self.search_query,
                "font": "TajawalBold", "size": 22, "color": C("#202124"), "halign": 1
            })
            elems.append({
                "layer": 3, "type": "text",
                "x": 34, "y": list_start_y + 105, "w": 1212, "h": 30,
                "text": _("كل تثبيت أو تحديث أو إزالة سيظهر هنا") if history_mode else _("ثبّت أي بلجن من المتجر وسيظهر هنا") if mine_mode else _("لا توجد تحديثات حالياً لأي بلجن مثبت على جهازك") if updates_mode else _("تأكد من صحة الكلمات أو اضغط الزر الأزرق لتجربة بحث آخر"),
                "font": "TajawalRegular", "size": 17, "color": C("#5f6368"), "halign": 1
            })
            return

        # Clamp search_list_scroll_y
        total_list_h = len(self.search_results) * 94
        max_list_scroll = max(0, total_list_h - V_H)
        self.search_list_scroll_y = max(0, min(max_list_scroll, self.search_list_scroll_y))

        # Ensure focused row is visible
        if self.cats_focused_level == "rows":
            if self.search_focused_row_idx >= len(self.search_results):
                self.search_focused_row_idx = len(self.search_results) - 1
            if self.search_focused_row_idx < 0:
                self.search_focused_row_idx = 0

            cur_top = self.search_focused_row_idx * 94
            cur_bottom = cur_top + 88
            if cur_top < self.search_list_scroll_y:
                self.search_list_scroll_y = cur_top
            elif cur_bottom > self.search_list_scroll_y + V_H:
                self.search_list_scroll_y = cur_bottom - V_H
            self.search_list_scroll_y = max(0, min(max_list_scroll, self.search_list_scroll_y))

        # Viewport Windowing (render ONLY rows inside viewport + 2 above/below)
        first_row = max(0, int((self.search_list_scroll_y - 2 * 94) // 94))
        last_row = min(len(self.search_results) - 1, int((self.search_list_scroll_y + V_H + 2 * 94) // 94))

        installed_reg = installer.load_installed_registry()

        for idx in range(first_row, last_row + 1):
            it = self.search_results[idx]
            row_y = list_start_y + idx * 94 - self.search_list_scroll_y
            if not (-88 < row_y < 674):
                continue

            # Register row element
            row_rect = {
                "id": "list_row_%d" % idx,
                "x": 34, "y": row_y, "w": 1212, "h": 88,
                "type": "list_row", "item": it, "idx": idx
            }
            focusable_elements.append(row_rect)

            # Icon 64 (Layer 2 img, Layer 3 letter only if no glyph)
            is_hist = isinstance(it, self._HistEntry)
            icon_path, has_glyph = get_item_icon(it.item if (is_hist and it.item is not None) else it, "64")
            icon_x = 1246 - 14 - 64 # = 1168
            icon_y = row_y + 12
            elems.append({"layer": 2, "type": "img", "x": icon_x, "y": icon_y, "w": 64, "h": 64, "path": icon_path})
            if not has_glyph:
                letter = it.name[0].upper() if it.name else "?"
                elems.append({"layer": 3, "type": "text", "x": icon_x, "y": icon_y, "w": 64, "h": 64, "text": letter, "font": "TajawalBold", "size": 32, "color": "#ffffff", "halign": 1})

            # Title
            title_x = 180
            title_w = icon_x - 18 - title_x # = 970
            elems.append({"layer": 3, "type": "text", "x": title_x, "y": row_y + 16, "w": title_w, "h": 28, "text": it.name, "font": "TajawalMedium", "size": 21, "color": C("#202124"), "halign": 2})

            # Meta Line: <sub-category or category> · <version or —> · <updated or —>
            sub_part = SUBCODES.get(it.subcode) or CATEGORIES.get(it.category, it.category)
            ver_part = format_version_display(it.version, prefix_v=True)
            up_part = it.updated or "—"
            meta_txt = it.meta() if is_hist else "%s · %s · %s" % (sub_part, ver_part, up_part)
            elems.append({"layer": 3, "type": "text", "x": title_x, "y": row_y + 46, "w": title_w, "h": 24, "text": meta_txt, "font": "TajawalRegular", "size": 15, "color": C("#5f6368"), "halign": 2})

            # Pill on the left
            pill_x = 34 + 14 # = 48
            pill_y = row_y + 24
            pill_w = 110
            pill_h = 40

            if is_hist:
                st = None
                pill_path = img_path("pill_outline.png")
                pill_txt = _("نجح") if it.ok() else _("فشل")
                pill_col = "#01875f" if it.ok() else "#d93025"
            else:
                st, inst_v = installer.get_item_state(it)
            if st is None:
                pass
            elif st != "none":
                if st == "update":
                    pill_path = img_path("pill_outline.png")
                    pill_txt = _("تحديث")
                    pill_col = "#01875f"
                else:
                    pill_path = img_path("pill_outline.png")
                    pill_txt = _("فتح")
                    pill_col = "#01875f"
            else:
                pill_path = img_path("pill_green_filled.png")
                pill_txt = _("تثبيت")
                pill_col = "#ffffff"

            elems.append({"layer": 1, "type": "bg", "x": pill_x, "y": pill_y, "w": pill_w, "h": pill_h, "path": pill_path})
            elems.append({"layer": 3, "type": "text", "x": pill_x, "y": pill_y, "w": pill_w, "h": pill_h, "text": pill_txt, "font": "TajawalBold", "size": 17, "color": pill_col, "halign": 1})

    # -----------------------------------------------------------------------
    # FOCUS & NAVIGATION
    # -----------------------------------------------------------------------
    def _update_focus_ring(self):
        self["top_focus_ring"].hide()
        if self.dialog_visible:
            self["focus_ring"].hide()
            return

        # Top Bar Focus (C1)
        if self.cats_focused_level == "tabs":
            tab_rects = {
                "tab_home": (TABS["tab_home"][0], 14, TABS["tab_home"][1], 48, 10),
                "tab_cats": (TABS["tab_cats"][0], 14, TABS["tab_cats"][1], 48, 10),
                "tab_mine": (TABS["tab_mine"][0], 14, TABS["tab_mine"][1], 48, 10),
                "search_pill": (102, 15, 300, 46, 27),
                "avatar": (34, 17, 42, 42, 21),
                "bell": (BELL_X, BELL_Y, BELL_SZ, BELL_SZ, BELL_SZ // 2),
            }
            tx, ty, tw, th, tr = tab_rects.get(self.top_bar_focus, (TABS["tab_cats"][0], 14, TABS["tab_cats"][1], 48, 10))
            pad = 4
            rx = tx - pad
            ry = ty - pad
            rw = tw + pad * 2
            rh = th + pad * 2
            path = get_focus_ring_pixmap(rw, rh, radius_design=tr + pad)
            self["focus_ring"].hide()
            self["top_focus_ring"].setPixmap(get_cached_pixmap(path))
            place(self["top_focus_ring"], px(rx), px(ry), px(rw), px(rh))
            self["top_focus_ring"].show()
            return

        if self.view_state == "search":
            if self.cats_focused_level == "rows":
                row_el = None
                for el in self.current_elements:
                    if el.get("type") == "list_row" and el.get("idx") == self.search_focused_row_idx:
                        row_el = el
                        break
                if row_el:
                    pad = 4
                    rx = 34 - pad
                    ry = row_el["y"] - pad
                    rw = 1212 + pad * 2
                    rh = 88 + pad * 2
                    path = get_focus_ring_pixmap(rw, rh, radius_design=18)
                    self["focus_ring"].setPixmap(get_cached_pixmap(path))
                    place(self["focus_ring"], px(rx), px(ry), px(rw), px(rh))
                    self["focus_ring"].show()
                    return
            self["focus_ring"].hide()
            return

        if self.view_state == "cats":
            if self.cats_focused_level == "chips":
                # Find focused chip
                chip_el = None
                for el in self.current_elements:
                    if el.get("type") == "cat_chip" and el.get("idx") == self.cats_focused_chip_idx:
                        chip_el = el
                        break
                if chip_el:
                    pad = 4
                    rx = chip_el["x"] - pad
                    ry = chip_el["y"] - pad
                    rw = chip_el["w"] + pad * 2
                    rh = chip_el["h"] + pad * 2
                    path = get_focus_ring_pixmap(rw, rh, radius_design=14)
                    self["focus_ring"].setPixmap(get_cached_pixmap(path))
                    place(self["focus_ring"], px(rx), px(ry), px(rw), px(rh))
                    self["focus_ring"].show()
                    return

            elif self.cats_focused_level == "subchips":
                sub_el = None
                for el in self.current_elements:
                    if el.get("type") == "sub_chip" and el.get("idx") == self.cats_focused_subchip_idx:
                        sub_el = el
                        break
                if sub_el:
                    pad = 4
                    rx = sub_el["x"] - pad
                    ry = sub_el["y"] - pad
                    rw = sub_el["w"] + pad * 2
                    rh = sub_el["h"] + pad * 2
                    path = get_focus_ring_pixmap(rw, rh, radius_design=14)
                    self["focus_ring"].setPixmap(get_cached_pixmap(path))
                    place(self["focus_ring"], px(rx), px(ry), px(rw), px(rh))
                    self["focus_ring"].show()
                    return

            elif self.cats_focused_level == "rows":
                row_el = None
                for el in self.current_elements:
                    if el.get("type") == "list_row" and el.get("idx") == self.cats_focused_row_idx:
                        row_el = el
                        break
                if row_el:
                    pad = 4
                    rx = 34 - pad
                    ry = row_el["y"] - pad
                    rw = 1212 + pad * 2
                    rh = 88 + pad * 2
                    path = get_focus_ring_pixmap(rw, rh, radius_design=18)
                    self["focus_ring"].setPixmap(get_cached_pixmap(path))
                    place(self["focus_ring"], px(rx), px(ry), px(rw), px(rh))
                    self["focus_ring"].show()
                    return

            self["focus_ring"].hide()
            return

        # Details / Home focus ring
        if not self.current_elements:
            self["focus_ring"].hide()
            return

        if self.focused_idx >= len(self.current_elements):
            self.focused_idx = len(self.current_elements) - 1
        if self.focused_idx < 0:
            self.focused_idx = 0

        el = self.current_elements[self.focused_idx]
        el_type = el.get("type")

        if el_type == "section":
            # D5: Wraps WHOLE section: header + card/text, full content width (1212), with 4px offset
            pad = 4
            rx = 34 - pad
            ry = el["y"] - pad
            rw = 1212 + pad * 2
            rh = el["h"] + pad * 2
            path = get_focus_ring_pixmap(rw, rh, radius_design=18)
            pix = get_cached_pixmap(path)
        elif el_type == "banner":
            pad = 6
            rx = el["x"] - pad
            ry = el["y"] - pad
            rw = el["w"] + pad * 2
            rh = el["h"] + pad * 2
            pix = get_cached_pixmap(get_focus_ring_pixmap(rw, rh, radius_design=22, stroke_color="#1de9b6"))
        elif el_type == "action_btn":
            pad = 7
            rx = el["x"] - pad
            ry = el["y"] - pad
            rw = el["w"] + pad * 2
            rh = el["h"] + pad * 2
            if el["w"] == 150:
                pix = get_cached_pixmap(img_path("focus_btn_150.png"))
            elif el["w"] == 180:
                pix = get_cached_pixmap(img_path("focus_btn_180.png"))
            elif el["w"] == 260:
                pix = get_cached_pixmap(img_path("focus_btn_260.png"))
            else:
                pix = get_cached_pixmap(get_focus_ring_pixmap(rw, rh, radius_design=(rh // 2)))
        elif el_type == "cancel_btn":
            pad = 7
            rx = el["x"] - pad
            ry = el["y"] - pad
            rw = el["w"] + pad * 2
            rh = el["h"] + pad * 2
            pix = get_cached_pixmap(img_path("focus_cancel_44.png"))
        elif el_type == "star":
            pad = 3
            rx = el["x"] - pad
            ry = el["y"] - pad
            rw = el["w"] + pad * 2
            rh = el["h"] + pad * 2
            pix = get_cached_pixmap(get_focus_ring_pixmap(rw, rh, radius_design=rw // 2))
        elif el_type == "shot":
            pad = 5
            rx = el["x"] - pad
            ry = el["y"] - pad
            rw = el["w"] + pad * 2
            rh = el["h"] + pad * 2
            pix = get_cached_pixmap(get_focus_ring_pixmap(rw, rh, radius_design=16))
        else: # Card
            pad = 7
            rx = el["x"] - pad
            ry = el["y"] - pad
            rw = el["w"] + pad * 2
            rh = el["h"] + pad * 2
            pix = get_cached_pixmap(img_path("focus_card.png"))

        self["focus_ring"].setPixmap(pix)
        place(self["focus_ring"], px(rx), px(ry), px(rw), px(rh))
        self["focus_ring"].show()

    # -----------------------------------------------------------------------
    # TOP BAR NAVIGATION (free remote navigation between tabs)
    # -----------------------------------------------------------------------
    TOP_BAR_ORDER = ["tab_home", "tab_cats", "tab_mine", "bell", "search_pill", "avatar"]

    def _move_top_bar(self, step):
        """Move focus along the top bar (wraps around). Home/Categories switch live."""
        order = self.TOP_BAR_ORDER
        cur_ix = order.index(self.top_bar_focus) if self.top_bar_focus in order else 0
        self.top_bar_focus = order[(cur_ix + step) % len(order)]
        if self.top_bar_focus == "tab_home" and self.view_state != "home":
            self.history_stack = []
            self.view_state = "home"
            self.scroll_y = 0
            self.focused_idx = 0
            self.render_ui()
        elif self.top_bar_focus == "tab_cats" and self.view_state != "cats":
            self.history_stack = []
            self.view_state = "cats"
            self.render_ui()
        self.cats_focused_level = "tabs"
        self._update_focus_ring()

    def _focus_top_bar(self, tab=None):
        self.cats_focused_level = "tabs"
        if tab:
            self.top_bar_focus = tab
        elif self.view_state == "cats":
            self.top_bar_focus = "tab_cats"
        elif self.view_state == "search":
            self.top_bar_focus = "search_pill"
        else:
            self.top_bar_focus = "tab_home"
        self._update_focus_ring()

    def key_left(self):
        if getattr(self, "pair_visible", False) and not self.dialog_visible:
            self._pair_key("left")
            return
        if getattr(self, "menu_visible", False) and not self.dialog_visible:
            self._acc_menu_key("left")
            return
        if getattr(self, "viewer_visible", False):
            self._viewer_key("left")
            return
        if self.dialog_visible:
            self.dialog_focus = "ok" if self.dialog_focus == "cancel" else "cancel"
            self._render_dialog()
            return

        # Top Bar Left (C1): tab_home -> tab_cats -> tab_mine -> search_pill
        if self.cats_focused_level == "tabs":
            self._move_top_bar(+1)
            return

        if self.view_state == "search":
            return

        if self.view_state == "cats":
            if self.cats_focused_level == "chips":
                # Move left to next chip (higher index in RTL)
                if self.cats_focused_chip_idx + 1 < len(CAT_CHIPS):
                    self.cats_focused_chip_idx += 1
                    self.render_ui()
                return
            elif self.cats_focused_level == "subchips":
                sub_count = 0
                for el in self.current_elements:
                    if el.get("type") == "sub_chip":
                        sub_count += 1
                if self.cats_focused_subchip_idx + 1 < sub_count:
                    self.cats_focused_subchip_idx += 1
                    self.render_ui()
                return
            elif self.cats_focused_level == "rows":
                return

        # Home / Details 2D navigation
        if not self.current_elements:
            return

        cur = self.current_elements[self.focused_idx]
        if cur.get("type") == "shot":
            self._move_shot(+1)
            return
        if cur.get("type") == "card":
            row_id = cur.get("row_id")
            idx = cur.get("idx", 0)
            total = cur.get("row_total", 0)

            if idx + 1 < total:
                next_id = "%s_%d" % (row_id, idx + 1)
                for c_idx, el in enumerate(self.current_elements):
                    if el.get("id") == next_id:
                        self.focused_idx = c_idx
                        break

                target = self.current_elements[self.focused_idx]
                target_idx = target.get("idx", idx + 1)
                unscrolled_x = 1096 - target_idx * 172
                cur_scroll = self.row_scrolls.get(row_id, 0)
                screen_x = unscrolled_x + cur_scroll

                if screen_x < 34:
                    self.row_scrolls[row_id] = 34 - unscrolled_x
                    self.render_ui()
                else:
                    self._update_focus_ring()
                return

        cur_cx = cur["x"] + cur["w"] / 2.0
        cur_cy = cur["y"] + cur["h"] / 2.0

        candidates = []
        for idx, el in enumerate(self.current_elements):
            if idx == self.focused_idx:
                continue
            el_cx = el["x"] + el["w"] / 2.0
            el_cy = el["y"] + el["h"] / 2.0

            if el_cx < cur_cx - 15:
                dx = cur_cx - el_cx
                dy = abs(cur_cy - el_cy)
                score = dx + dy * 2.5
                candidates.append((score, idx))

        if candidates:
            candidates.sort(key=lambda item: item[0])
            self.focused_idx = candidates[0][1]
            self._update_focus_ring()

    def key_right(self):
        if getattr(self, "pair_visible", False) and not self.dialog_visible:
            self._pair_key("right")
            return
        if getattr(self, "menu_visible", False) and not self.dialog_visible:
            self._acc_menu_key("right")
            return
        if getattr(self, "viewer_visible", False):
            self._viewer_key("right")
            return
        if self.dialog_visible:
            self.dialog_focus = "ok" if self.dialog_focus == "cancel" else "cancel"
            self._render_dialog()
            return

        # Top Bar Right (C1): search_pill -> tab_mine -> tab_cats -> tab_home
        if self.cats_focused_level == "tabs":
            self._move_top_bar(-1)
            return

        if self.view_state == "search":
            return

        if self.view_state == "cats":
            if self.cats_focused_level == "chips":
                if self.cats_focused_chip_idx > 0:
                    self.cats_focused_chip_idx -= 1
                    self.render_ui()
                return
            elif self.cats_focused_level == "subchips":
                if self.cats_focused_subchip_idx > 0:
                    self.cats_focused_subchip_idx -= 1
                    self.render_ui()
                return
            elif self.cats_focused_level == "rows":
                return

        if not self.current_elements:
            return

        cur = self.current_elements[self.focused_idx]
        if cur.get("type") == "shot":
            self._move_shot(-1)
            return
        if cur.get("type") == "card":
            row_id = cur.get("row_id")
            idx = cur.get("idx", 0)

            if idx > 0:
                prev_id = "%s_%d" % (row_id, idx - 1)
                for c_idx, el in enumerate(self.current_elements):
                    if el.get("id") == prev_id:
                        self.focused_idx = c_idx
                        break

                target = self.current_elements[self.focused_idx]
                target_idx = target.get("idx", idx - 1)
                unscrolled_x = 1096 - target_idx * 172
                cur_scroll = self.row_scrolls.get(row_id, 0)
                screen_x = unscrolled_x + cur_scroll

                if screen_x + 150 > 1246:
                    self.row_scrolls[row_id] = max(0, 1246 - 150 - unscrolled_x)
                    self.render_ui()
                else:
                    self._update_focus_ring()
                return

        cur_cx = cur["x"] + cur["w"] / 2.0
        cur_cy = cur["y"] + cur["h"] / 2.0

        candidates = []
        for idx, el in enumerate(self.current_elements):
            if idx == self.focused_idx:
                continue
            el_cx = el["x"] + el["w"] / 2.0
            el_cy = el["y"] + el["h"] / 2.0

            if el_cx > cur_cx + 15:
                dx = el_cx - cur_cx
                dy = abs(cur_cy - el_cy)
                score = dx + dy * 2.5
                candidates.append((score, idx))

        if candidates:
            candidates.sort(key=lambda item: item[0])
            self.focused_idx = candidates[0][1]
            self._update_focus_ring()

    def key_down(self):
        if getattr(self, "pair_visible", False) and not self.dialog_visible:
            self._pair_key("down")
            return
        if getattr(self, "menu_visible", False) and not self.dialog_visible:
            self._acc_menu_key("down")
            return
        if getattr(self, "viewer_visible", False):
            self._viewer_key("down")
            return
        if self.dialog_visible:
            return

        # Top Bar -> Down into content (C1)
        if self.cats_focused_level == "tabs":
            if self.view_state == "cats":
                self.cats_focused_level = "chips"
                self.render_ui()
            elif self.view_state == "search":
                if self.search_results:
                    self.cats_focused_level = "rows"
                    self.render_ui()
                else:
                    self._update_focus_ring()
            else:
                if self.view_state == "home" and not self.current_elements:
                    self._update_focus_ring()
                    return
                self.cats_focused_level = "rows"
                self.focused_idx = 0
                self.render_ui()
            return

        if self.view_state == "search":
            if self.cats_focused_level == "rows":
                if self.search_results and self.search_focused_row_idx + 1 < len(self.search_results):
                    self.search_focused_row_idx += 1
                    self.render_ui()
                return

        if self.view_state == "cats":
            has_sub = any(el.get("type") == "sub_chip" for el in self.current_elements)
            if self.cats_focused_level == "chips":
                if has_sub:
                    self.cats_focused_level = "subchips"
                else:
                    self.cats_focused_level = "rows"
                self.render_ui()
                return
            elif self.cats_focused_level == "subchips":
                self.cats_focused_level = "rows"
                self.render_ui()
                return
            elif self.cats_focused_level == "rows":
                if self.cats_filtered_items and self.cats_focused_row_idx + 1 < len(self.cats_filtered_items):
                    self.cats_focused_row_idx += 1
                    self.render_ui()
                return

        if not self.current_elements:
            return

        cur = self.current_elements[self.focused_idx]
        candidates = [
            (idx, el) for idx, el in enumerate(self.current_elements)
            if el["y"] > cur["y"] + 20
        ]
        if candidates:
            candidates.sort(key=lambda item: (item[1]["y"], abs(item[1]["x"] - cur["x"])))
            self.focused_idx = candidates[0][0]
            self._ensure_visible(self.current_elements[self.focused_idx])
            self.render_ui()
        else:
            # D6: Scroll limit clamping
            if self.scroll_y < self.max_scroll_y:
                self.scroll_y = min(self.max_scroll_y, self.scroll_y + 140)
                self.render_ui()

    def key_up(self):
        if getattr(self, "pair_visible", False) and not self.dialog_visible:
            self._pair_key("up")
            return
        if getattr(self, "menu_visible", False) and not self.dialog_visible:
            self._acc_menu_key("up")
            return
        if getattr(self, "viewer_visible", False):
            self._viewer_key("up")
            return
        if self.dialog_visible:
            return

        if self.view_state == "search":
            if self.cats_focused_level == "rows":
                if self.search_focused_row_idx > 0:
                    self.search_focused_row_idx -= 1
                    self.render_ui()
                else:
                    self.cats_focused_level = "tabs"
                    self.top_bar_focus = "search_pill"
                    self._update_focus_ring()
                return

        if self.view_state == "cats":
            has_sub = any(el.get("type") == "sub_chip" for el in self.current_elements)
            if self.cats_focused_level == "rows":
                if self.cats_focused_row_idx > 0:
                    self.cats_focused_row_idx -= 1
                    self.render_ui()
                else:
                    if has_sub:
                        self.cats_focused_level = "subchips"
                    else:
                        self.cats_focused_level = "chips"
                    self.render_ui()
                return
            elif self.cats_focused_level == "subchips":
                self.cats_focused_level = "chips"
                self.render_ui()
                return
            elif self.cats_focused_level == "chips":
                # C1: UP from chips moves to top bar
                self.cats_focused_level = "tabs"
                self.top_bar_focus = "tab_cats"
                self._update_focus_ring()
                return

        if not self.current_elements:
            self._focus_top_bar()
            return

        cur = self.current_elements[self.focused_idx]
        candidates = [
            (idx, el) for idx, el in enumerate(self.current_elements)
            if el["y"] < cur["y"] - 20
        ]
        if candidates:
            candidates.sort(key=lambda item: (-item[1]["y"], abs(item[1]["x"] - cur["x"])))
            self.focused_idx = candidates[0][0]
            self._ensure_visible(self.current_elements[self.focused_idx])
            self.render_ui()
        else:
            if self.view_state == "home" and self.scroll_y <= 0:
                # C1: UP from top banner/cards moves to top bar
                self.cats_focused_level = "tabs"
                self.top_bar_focus = "tab_home"
                self._update_focus_ring()
                return

            if self.scroll_y > 0:
                self.scroll_y = max(0, self.scroll_y - 140)
                self.render_ui()

    def key_page_up(self):
        if self.dialog_visible:
            return
        if self.view_state == "search" and self.cats_focused_level == "rows":
            if self.search_focused_row_idx > 0:
                self.search_focused_row_idx = max(0, self.search_focused_row_idx - 5)
                self.render_ui()
        elif self.view_state == "cats" and self.cats_focused_level == "rows":
            if self.cats_focused_row_idx > 0:
                self.cats_focused_row_idx = max(0, self.cats_focused_row_idx - 5)
                self.render_ui()
        else:
            if self.scroll_y > 0:
                self.scroll_y = max(0, self.scroll_y - 280)
                self.render_ui()

    def key_page_down(self):
        if self.dialog_visible:
            return
        if self.view_state == "search" and self.cats_focused_level == "rows":
            if self.search_results and self.search_focused_row_idx + 1 < len(self.search_results):
                self.search_focused_row_idx = min(len(self.search_results) - 1, self.search_focused_row_idx + 5)
                self.render_ui()
        elif self.view_state == "cats" and self.cats_focused_level == "rows":
            if self.cats_filtered_items and self.cats_focused_row_idx + 1 < len(self.cats_filtered_items):
                self.cats_focused_row_idx = min(len(self.cats_filtered_items) - 1, self.cats_focused_row_idx + 5)
                self.render_ui()
        else:
            if self.scroll_y < self.max_scroll_y:
                self.scroll_y = min(self.max_scroll_y, self.scroll_y + 280)
                self.render_ui()

    def _ensure_visible(self, el):
        el_top = el["y"] + self.scroll_y
        el_bottom = el_top + el["h"]

        if el_top < self.scroll_y + 90:
            self.scroll_y = max(0, el_top - 95)
        elif el_bottom > self.scroll_y + 660:
            self.scroll_y = el_bottom - 650
        # D6: Clamp
        if self.max_scroll_y > 0:
            self.scroll_y = max(0, min(self.max_scroll_y, self.scroll_y))

    def key_ok(self):
        if getattr(self, "pair_visible", False) and not self.dialog_visible:
            self._pair_key("ok")
            return
        if getattr(self, "menu_visible", False) and not self.dialog_visible:
            self._acc_menu_key("ok")
            return
        if getattr(self, "viewer_visible", False):
            self._viewer_key("ok")
            return
        if self.dialog_visible:
            title, text, ok_label, on_ok, on_cancel = (self.dialog_data + (None, None))[:5]
            if self.dialog_focus == "ok":
                self.dialog_visible = False
                self._hide_dialog_widgets()
                if on_ok:
                    on_ok()
                else:
                    self.render_ui()
            else:
                self.dialog_visible = False
                self._hide_dialog_widgets()
                if on_cancel:
                    on_cancel()
                else:
                    self.render_ui()
            return

        # C1: Top Bar tabs OK switches tab & clears history stack
        if self.cats_focused_level == "tabs":
            if self.top_bar_focus == "tab_home":
                self.history_stack = []
                self.view_state = "home"
                self.cats_focused_level = "rows"
                self.scroll_y = 0
                self.focused_idx = 0
                self.render_ui()
            elif self.top_bar_focus == "tab_cats":
                self.history_stack = []
                self.view_state = "cats"
                self.cats_focused_level = "chips"
                self.render_ui()
            elif self.top_bar_focus == "tab_mine":
                self.open_mine()
            elif self.top_bar_focus == "search_pill":
                self.open_search()
            elif self.top_bar_focus == "avatar":
                self.open_acc_menu()
            elif self.top_bar_focus == "bell":
                self.open_acc_menu("notif")
            return

        if self.view_state == "search":
            if self.cats_focused_level == "rows":
                if self.search_results and 0 <= self.search_focused_row_idx < len(self.search_results):
                    selected_item = self.search_results[self.search_focused_row_idx]
                    if isinstance(selected_item, self._HistEntry):
                        if selected_item.item is None:
                            self.show_toast(_("هذا البلجن لم يعد موجوداً في المتجر"))
                            return
                        selected_item = selected_item.item
                    self.open_details(selected_item)
                return

        if self.view_state == "cats":
            if self.cats_focused_level == "chips":
                # C2: OK on a chip selects it, refreshes list, and KEEPS focus on that chip
                selected_cat = CAT_CHIPS[self.cats_focused_chip_idx][0]
                self.cats_selected_cat = selected_cat
                self.cats_selected_subcode = "all"
                self.cats_list_scroll_y = 0
                self.cats_focused_row_idx = 0
                self.render_ui()
                return

            elif self.cats_focused_level == "subchips":
                # C3: OK on sub-chip selects it, refreshes list, keeps focus on that sub-chip
                sub_el = None
                for el in self.current_elements:
                    if el.get("type") == "sub_chip" and el.get("idx") == self.cats_focused_subchip_idx:
                        sub_el = el
                        break
                if sub_el:
                    self.cats_selected_subcode = sub_el["key"]
                    self.cats_list_scroll_y = 0
                    self.cats_focused_row_idx = 0
                    self.render_ui()
                return

            elif self.cats_focused_level == "rows":
                if self.cats_filtered_items and 0 <= self.cats_focused_row_idx < len(self.cats_filtered_items):
                    selected_item = self.cats_filtered_items[self.cats_focused_row_idx]
                    self.open_details(selected_item)
                return

        if not self.current_elements:
            return

        el = self.current_elements[self.focused_idx]
        el_type = el.get("type")

        if el_type in ("card", "banner"):
            it = el.get("item")
            if it:
                self.open_details(it)

        elif el_type == "action_btn":
            self._handle_action_button(el)

        elif el_type == "shot":
            self.open_viewer(el.get("idx", 0))

        elif el_type == "star":
            self._rate_item(self.details_item, el.get("stars", 5))

        elif el_type == "cancel_btn":
            if self.installer_job and self.installer_job.phase == "download":
                self.installer_job.cancel_download()
                self.show_toast(_("تم إلغاء التنزيل"))
                self.render_ui()

    def _add_remove_button(self, item, x, y, elems, focusable_elements):
        pkg, _v = installer.find_installed_package(item)
        if not pkg:
            return
        bg = get_card_bg_pixmap(150, 52, radius_design=26, stroke_color="#d93025", fill_color=None)
        elems.append({"layer": 1, "type": "bg", "x": x, "y": y, "w": 150, "h": 52, "path": bg})
        elems.append({"layer": 3, "type": "text", "x": x, "y": y, "w": 150, "h": 52, "text": _("إزالة"), "font": "TajawalMedium", "size": 19, "color": "#d93025", "halign": 1, "is_button": True})
        focusable_elements.append({"id": "btn_remove", "x": x, "y": y, "w": 150, "h": 52, "type": "action_btn", "action": "remove"})

    def _handle_action_button(self, el):
        action = el.get("action", "install")
        item = self.details_item
        if not item:
            return

        if action == "share":
            self.open_share(item)
            return

        if action == "boxes":
            self._install_on_other_boxes(item)
            return

        if action == "remove":
            self.show_dialog(
                _("إزالة %s") % item.name,
                _("سيتم حذف البلجن من جهازك%s.") % (_("، ومن قائمة حسابك") if account.is_logged_in() and settings.get("auto_sync") else ""),
                ok_label=_("إزالة"),
                on_ok=lambda: self._start_installation(item, action="remove"),
                default_focus="cancel"
            )
            return

        if action == "open":
            plugin_obj = el.get("plugin")
            if plugin_obj:
                try:
                    plugin_obj(self.session)
                except Exception as e:
                    self.show_toast(_("خطأ في تشغيل البلجن"))
            else:
                self.show_toast(_("فتح %s") % item.name)

        elif action == "update":
            self._start_installation(item)

        elif action == "install":
            if item.dangerous:
                self.show_dialog(
                    _("تأكيد التثبيت"),
                    _("هذا البلجن مصنف كعنصر متقدم وقد يقوم بتعديل ملفات النظام الحساسة. هل أنت متأكد من المتابعة؟"),
                    ok_label=_("متابعة التثبيت"),
                    on_ok=lambda: self._start_installation(item)
                )
            else:
                self._start_installation(item)

    def _start_installation(self, item, action=None):
        if action is None:
            action = "update" if installer.get_item_state(item)[0] == "update" else "install"
        # Installing / updating needs an account (EnigmaPlay itself and removals are always allowed,
        # so a box can never get stuck on an old store version)
        if action != "remove" and item.key != "enigmaplay" and not account.is_logged_in():
            self.update_queue = []
            self._save_update_queue()
            self.show_dialog(
                _("سجّل الدخول للتثبيت"),
                _("لتثبيت البلجنات وتحديثها سجّل الدخول بحسابك أو أنشئ حساباً مجانياً. حسابك يحفظ بلجيناتك ويستعيدها على أي صورة."),
                ok_label=_("تسجيل الدخول"),
                on_ok=lambda: self.open_acc_menu("login"))
            return
        self.installer_job = installer.InstallJob(
            item,
            action=action,
            on_log_update=self._on_installer_log,
            on_finish=self._on_installer_finish,
            on_unverified=self._on_unverified_script
        )
        self.installer_job.start()
        self.render_ui()

    def _on_unverified_script(self, job, on_confirm, on_cancel):
        self.show_dialog(
            _("تحذير أمان"),
            _("هذا السكربت غير موثق بتوقيع رقمي (SHA-256). هل تريد المتابعة وتثبيته على مسؤوليتك؟"),
            ok_label=_("متابعة التثبيت"),
            on_ok=on_confirm,
            on_cancel=on_cancel,
            default_focus="cancel"
        )
        self.render_ui()

    def _on_installer_log(self, lines):
        item = getattr(self, "details_item", None)
        if item is not None and hasattr(self, "last_logs_by_item"):
            self.last_logs_by_item[item.key] = lines
        if getattr(self, "view_state", None) == "details":
            self.render_ui()

    def _on_installer_finish(self, job, rc, msg):
        self.installer_job = None
        self._refresh_bell()
        if getattr(job, "action", "install") == "remove":
            if rc == 0:
                self.show_toast(_("تمت إزالة %s") % job.item.name)
                if account.is_logged_in() and settings.get("auto_sync"):
                    self._run_async(account.remove_plugin, lambda ok, v: None, job.item.key)
                self._maybe_restart(_("تمت إزالة %s. أعد تشغيل الواجهة ليختفي من القوائم. إعادة التشغيل الآن؟") % job.item.name)
            else:
                self.show_toast(msg or _("فشلت إزالة %s") % job.item.name)
            self.render_ui()
            return
        if rc == 0:
            self._sync_one(job.item)
            if getattr(job, "action", "install") == "install" and not self.update_queue_total:
                try:
                    account.works_remember(job.item.key, job.item.version or "")
                except Exception:
                    pass
            if self.update_queue_total and getattr(self, "queue_mode", "") == "restore":
                self.restored_ids = getattr(self, "restored_ids", []) + [job.item.key]
            self._run_async(lambda k: (account.report_install(k), account.fetch_stats())[1], self._on_stats, job.item.key)
        if self.update_queue_total:
            # update-all in progress: no per-item dialogs, continue with the next one
            if rc == 0:
                if getattr(job.item, "restart", False) or (job.item.category in ("skins", "softcams")):
                    self.update_queue_restart = True
            else:
                self.show_toast(_("فشل تحديث %s") % job.item.name)
            if self.queue_timer:
                self.queue_timer.start(1500, True)
            else:
                self._run_next_update()
            return
        if rc == 0:
            self.show_toast(_("تم تثبيت %s بنجاح") % job.item.name)
            needs_restart = getattr(job.item, "restart", False) or (job.item.category in ("skins", "softcams"))
            if needs_restart:
                self._maybe_restart(_("تم تثبيت %s بنجاح. يلزم إعادة تشغيل واجهة إنيجما لتفعيل التغييرات. هل تريد إعادة التشغيل الآن؟") % job.item.name)
        else:
            self.show_toast(_("فشل تثبيت %s: %s") % (job.item.name, msg))
        self.render_ui()

    def _maybe_restart(self, text):
        mode = settings.get("restart_after_install")
        if mode == "auto":
            self.show_toast(_("جاري إعادة تشغيل الواجهة…"))
            self._do_restart_gui()
        elif mode == "never":
            self.show_toast(_("أعد تشغيل الواجهة لاحقاً لتفعيل التغييرات"))
        else:
            self.show_dialog(_("إعادة تشغيل الواجهة"), text, ok_label=_("إعادة التشغيل الآن"), on_ok=self._do_restart_gui)

    def _do_restart_gui(self):
        if HAS_E2:
            try:
                self.session.open(TryQuitMainloop, 3)
            except Exception:
                pass

    # -----------------------------------------------------------------------
    # UPDATES (list of installed plugins with a newer version + update-all queue)
    # -----------------------------------------------------------------------
    UPDATE_QUEUE_FILE = os.path.join(installer.REGISTRY_DIR, "update_queue.json")

    def get_available_updates(self):
        out = []
        for it in self.catalog.items:
            try:
                if installer.get_item_state(it)[0] == "update":
                    out.append(it)
            except Exception:
                continue
        out.sort(key=lambda it: (it.name or "").lower())
        return out

    def _push_history(self):
        self.history_stack.append({
            "view_state": self.view_state,
            "scroll_y": self.scroll_y,
            "row_scrolls": dict(self.row_scrolls),
            "focused_idx": self.focused_idx,
            "details_item": self.details_item,
            "cats_selected_cat": self.cats_selected_cat,
            "cats_selected_subcode": self.cats_selected_subcode,
            "cats_focused_level": self.cats_focused_level,
            "cats_focused_chip_idx": self.cats_focused_chip_idx,
            "cats_focused_subchip_idx": self.cats_focused_subchip_idx,
            "cats_focused_row_idx": self.cats_focused_row_idx,
            "cats_chips_scroll_x": self.cats_chips_scroll_x,
            "cats_subchips_scroll_x": self.cats_subchips_scroll_x,
            "cats_list_scroll_y": self.cats_list_scroll_y,
            "search_query": self.search_query,
            "search_results": list(self.search_results),
            "search_focused_row_idx": self.search_focused_row_idx,
            "search_list_scroll_y": self.search_list_scroll_y,
            "list_mode": self.list_mode,
        })

    def open_updates(self):
        if not (self.view_state == "search" and self.list_mode == "updates"):
            self._push_history()
        self.list_mode = "updates"
        self.search_results = self.get_available_updates()
        self.search_focused_row_idx = 0
        self.search_list_scroll_y = 0
        self.view_state = "search"
        if self.search_results:
            self.cats_focused_level = "rows"
            self.render_ui()
        else:
            self.render_ui()
            self._focus_top_bar("avatar")

    def update_all(self):
        if self.installer_job or self.update_queue:
            self.show_toast(_("يوجد تثبيت قيد التنفيذ"))
            return
        updates = self.get_available_updates()
        if not updates:
            self.show_toast(_("كل بلجيناتك محدّثة"))
            return
        names = _("، ").join(it.name for it in updates[:4]) + ("…" if len(updates) > 4 else "")
        self.show_dialog(
            _("تحديث الكل"),
            _("يوجد %d تحديث: %s") % (len(updates), names),
            ok_label=_("تحديث الكل"),
            on_ok=lambda: self._start_update_queue([it.key for it in updates])
        )

    def _save_update_queue(self):
        try:
            if self.update_queue:
                if not os.path.isdir(installer.REGISTRY_DIR):
                    os.makedirs(installer.REGISTRY_DIR)
                with open(self.UPDATE_QUEUE_FILE, "w") as f:
                    f.write(json_dumps({"ids": self.update_queue, "total": self.update_queue_total,
                                        "mode": getattr(self, "queue_mode", "update")}))
            elif os.path.exists(self.UPDATE_QUEUE_FILE):
                os.remove(self.UPDATE_QUEUE_FILE)
        except Exception as e:
            installer.log_debug("update queue save error: %s" % e)

    def _start_update_queue(self, ids, total=None, mode="update"):
        self.queue_mode = mode
        self.restored_ids = []
        self.update_queue = list(ids)
        self.update_queue_total = total or len(ids)
        self.update_queue_restart = False
        self._run_next_update()

    def _run_next_update(self):
        if self.installer_job:
            return
        while self.update_queue:
            key = self.update_queue.pop(0)
            item = self.catalog.get(key)
            want = "none" if getattr(self, "queue_mode", "update") == "restore" else "update"
            if item is None or installer.get_item_state(item)[0] != want:
                continue
            self._save_update_queue_with(item.key)
            done = self.update_queue_total - len(self.update_queue)
            verb = _("تثبيت") if want == "none" else _("تحديث")
            self.show_toast("%s %s (%d/%d)" % (verb, item.name, done, self.update_queue_total))
            self._start_installation(item)
            return
        # queue finished
        self._save_update_queue()
        self.update_queue_total = 0
        if self.list_mode == "updates" and self.view_state == "search":
            self.search_results = self.get_available_updates()
            self.search_focused_row_idx = 0
        self.render_ui()
        if getattr(self, "queue_mode", "") == "restore" and getattr(self, "restored_ids", None) and account.is_logged_in():
            # bring back the saved settings of the plugins just installed, then ask for the restart
            self.restore_needs_restart = self.update_queue_restart
            self.update_queue_restart = False
            ids, self.restored_ids = self.restored_ids, []
            self.show_toast(_("اكتملت الاستعادة"))
            self.restore_settings(ids, after_install=True)
            return
        if self.update_queue_restart:
            self.update_queue_restart = False
            self._maybe_restart(_("اكتملت العملية. يلزم إعادة تشغيل الواجهة لتفعيل التغييرات. إعادة التشغيل الآن؟"))
        else:
            self.show_toast(_("اكتملت الاستعادة") if getattr(self, "queue_mode", "update") == "restore" else _("اكتمل تحديث البلجنات"))

    def _save_update_queue_with(self, current_key):
        # Keep the running item in the saved queue: if its installer restarts Enigma2,
        # we resume from it next time (it is skipped automatically once up to date).
        saved = self.update_queue
        self.update_queue = [current_key] + saved
        self._save_update_queue()
        self.update_queue = saved

    def _check_pending_update_queue(self):
        try:
            if not os.path.exists(self.UPDATE_QUEUE_FILE):
                return
            with open(self.UPDATE_QUEUE_FILE) as f:
                data = json_loads(f.read())
            q_mode = data.get("mode", "update")
            want = "none" if q_mode == "restore" else "update"
            ids = [k for k in data.get("ids", []) if self.catalog.get(k) is not None
                   and installer.get_item_state(self.catalog.get(k))[0] == want]
            if not ids:
                os.remove(self.UPDATE_QUEUE_FILE)
                return
            def _cancel():
                try:
                    os.remove(self.UPDATE_QUEUE_FILE)
                except Exception:
                    pass
                self.render_ui()
            self.show_dialog(
                _("متابعة التحديث"),
                _("توقف تحديث الكل قبل اكتماله. متبقٍ %d بلجن. هل تريد المتابعة؟") % len(ids),
                ok_label=_("متابعة"),
                on_ok=lambda: self._start_update_queue(ids, data.get("total") or len(ids), mode=q_mode),
                on_cancel=_cancel
            )
        except Exception as e:
            installer.log_debug("pending update queue error: %s" % e)

    def open_details(self, item):
        self.history_stack.append({
            "view_state": self.view_state,
            "scroll_y": self.scroll_y,
            "row_scrolls": dict(self.row_scrolls),
            "focused_idx": self.focused_idx,
            "details_item": self.details_item,
            "cats_selected_cat": self.cats_selected_cat,
            "cats_selected_subcode": self.cats_selected_subcode,
            "cats_focused_level": self.cats_focused_level,
            "cats_focused_chip_idx": self.cats_focused_chip_idx,
            "cats_focused_subchip_idx": self.cats_focused_subchip_idx,
            "cats_focused_row_idx": self.cats_focused_row_idx,
            "cats_chips_scroll_x": self.cats_chips_scroll_x,
            "cats_subchips_scroll_x": self.cats_subchips_scroll_x,
            "cats_list_scroll_y": self.cats_list_scroll_y,
            "search_query": self.search_query,
            "search_results": list(self.search_results),
            "search_focused_row_idx": self.search_focused_row_idx,
            "search_list_scroll_y": self.search_list_scroll_y,
        })

        self.view_state = "details"
        self.details_item = item
        self.shots_first = 0
        self.shots_refresh_left = 0
        self.scroll_y = 0
        self.focused_idx = 0
        self.render_ui()

    def key_cancel(self):
        if getattr(self, "pair_visible", False) and not self.dialog_visible:
            self._pair_key("cancel")
            return
        if getattr(self, "menu_visible", False) and not self.dialog_visible:
            self._acc_menu_key("cancel")
            return
        if getattr(self, "viewer_visible", False):
            self._viewer_key("cancel")
            return
        if self.dialog_visible:
            title, text, ok_label, on_ok, on_cancel = (self.dialog_data + (None, None))[:5]
            on_back = getattr(self, "dialog_on_back", None)
            if on_back:
                on_cancel = on_back             # BACK = "skip", not the second button's answer
            self.dialog_visible = False
            self._hide_dialog_widgets()
            if on_cancel:
                on_cancel()
            else:
                self.render_ui()
            return

        if self.history_stack:
            prev = self.history_stack.pop()
            self.view_state = prev["view_state"]
            self.scroll_y = prev["scroll_y"]
            self.row_scrolls = prev.get("row_scrolls", {})
            self.focused_idx = prev["focused_idx"]
            self.details_item = prev["details_item"]
            self.cats_selected_cat = prev.get("cats_selected_cat", "all")
            self.cats_selected_subcode = prev.get("cats_selected_subcode", "all")
            self.cats_focused_level = prev.get("cats_focused_level", "rows")
            self.cats_focused_chip_idx = prev.get("cats_focused_chip_idx", 0)
            self.cats_focused_subchip_idx = prev.get("cats_focused_subchip_idx", 0)
            self.cats_focused_row_idx = prev.get("cats_focused_row_idx", 0)
            self.cats_chips_scroll_x = prev.get("cats_chips_scroll_x", 0)
            self.cats_subchips_scroll_x = prev.get("cats_subchips_scroll_x", 0)
            self.cats_list_scroll_y = prev.get("cats_list_scroll_y", 0)
            self.search_query = prev.get("search_query", "")
            self.search_results = prev.get("search_results", [])
            self.search_focused_row_idx = prev.get("search_focused_row_idx", 0)
            self.search_list_scroll_y = prev.get("search_list_scroll_y", 0)
            self.list_mode = prev.get("list_mode", "search")
            if self.search_query:
                self["search_text"].setText(self.search_query)
            else:
                self["search_text"].setText(_("ابحث عن بلجنات"))
            self.render_ui()
        else:
            if self.view_state == "cats":
                self.view_state = "home"
                self.cats_focused_level = "rows"
                self.scroll_y = 0
                self.focused_idx = 0
                self.render_ui()
            elif self.view_state == "search":
                self.view_state = "home"
                self.cats_focused_level = "rows"
                self.scroll_y = 0
                self.focused_idx = 0
                self.search_query = ""
                self["search_text"].setText(_("ابحث عن بلجنات"))
                self.render_ui()
            else:
                self.close()

    def key_red(self):
        self.key_cancel()

    def key_green(self):
        if getattr(self, "menu_visible", False) or getattr(self, "pair_visible", False):
            return
        if getattr(self, "viewer_visible", False):
            return
        if self.view_state == "details":
            for el in self.current_elements:
                if el.get("type") == "action_btn":
                    self._handle_action_button(el)
                    return
        elif self.view_state in ("cats", "search", "home"):
            self.key_ok()

    def key_yellow(self):
        if getattr(self, "menu_visible", False) or getattr(self, "pair_visible", False):
            return
        if getattr(self, "viewer_visible", False):
            return
        if self.dialog_visible:
            return
        self.update_all()

    def key_blue(self):
        if getattr(self, "menu_visible", False) or getattr(self, "pair_visible", False):
            return
        if getattr(self, "viewer_visible", False):
            return
        if self.view_state == "details":
            if self.details_item:
                self.open_share(self.details_item)
            return
        self.open_search()

